#' # About New Edition {-}
#' 

#' 
#' Since the first edition of this book in 2017, m
#'   
#' However, the format of the book has changed sig
#' 
#' Three new chapters were added to this book, inc
#' 
#' For all R teachers in the world, this and all f
#' 
#' I hope you enjoy reading this book and, based o
#' 
#' 
#' ## Revision 2021 {-}
#' 
#' The book was revised in march 2021, with the fo
#' 
#' - Improved and consistent css template across d
#' - Over 100 end of chapter exercises. The exerci
#' - To help the reader with topics that don't qui
#' - New hardcover format is available at Amazon.
#' 
#' All changes are fully reflected in Amazon. Thos