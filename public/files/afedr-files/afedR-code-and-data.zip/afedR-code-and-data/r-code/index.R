#' --- 
#' title: "Analyzing Financial and Economic Data w
#' author: "Marcelo S. Perlin (marcelo.perlin@ufrg
#' date: "Second Edition Revised - `r as.Date('202
#' site: bookdown::bookdown_site
#' cover-image: "figs/CAPAdigital-AnalyzinDataR.jp
#' output: bookdown::pdf_book
#' documentclass: book
#' bibliography: ["bib-files/book.bib", "bib-files
#' biblio-style: apalike
#' fontsize: 12pt
#' geometry: margin=1in, paperwidth=7in, paperheig
#' link-citations: yes         
#' description: "Analyzing Financial and Economic 
#' ---
#' 

#' 
#' 
## ----test-main, include=identical(my.engine , 'html'), results='asis'-----------------------------------------------
my_str <- paste(readLines('_Welcome.Rmd'), collapse = '\n')

my_str <- stringr::str_replace_all(my_str, '`r book_title`', book_title)
my_str <- stringr::str_replace_all(my_str, '`r link_amazon_ebook`', link_amazon_ebook)
my_str <- stringr::str_replace_all(my_str, '`r link_amazon_print`', link_amazon_print)
my_str <- stringr::str_replace_all(my_str, '`r blog_site`', blog_site)

cat(my_str)

#' 