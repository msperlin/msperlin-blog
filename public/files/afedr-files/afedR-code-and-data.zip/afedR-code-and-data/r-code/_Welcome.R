#' # Welcome! {-}
#' 
#' <p>
#' <a href="https://www.amazon.com/dp/B084LSNXMN">
#' </p>
#' 
#' The book is available for purchase in Amazon as
#' 
#' If you liked the material and are using the boo
#' 
#' 
#' ## License {-}
#' 
#' This work is licensed by <a rel="license" href=
#' 
#' Perlin, M. S. Analizing Financial and Economic 
#' 
#' 
#' ## About the Author {-}
#' 
#' I'm an associate professor at the post-graduate
#' 
#' 
#' ## Books from the Author {-}
#' 
#' - [Poupando e Investindo em Renda Fixa](https:/
#' 
#' - [Análise de Dados Financeiro e Econômico com 