#' # Importação e Exportação de Dados Locais {#imp
#' 

#' 
#' Sem dúvida, a primeira etapa de um _script_ de 
#' 
#' Aqui iremos traçar uma lista abrangente com os 
#' 
#' - Dados delimitados em texto (_csv_);
#' - Microsoft Excel (_xls_, _xlsx_);
#' - Arquivos de dados nativos do R (_RData_ e _rd
#' - Formato `fst` (_fst_)
#' - SQLite (_SQLITE_)
#' - Texto não estruturado (_txt_).
#' 
#' A primeira lição na importação de dados para o 
#' 
## ------------------------------------------------------------------------------------------------------------
my_file <- 'C:/Data/MyData.csv'

#' 
#' Note o uso de barras (`/`) para designar o dire
#' 
## ------------------------------------------------------------------------------------------------------------
my_file <- 'Data/MyData.csv'

#' 
#' Neste caso, assume-se que na pasta atual de tra
#' 
## Aqui novamente reforço o uso do _tab_ e _autocomplete_ do RStudio. É muito mais fácil e prático encontrar arquivos do disco rígido do computador usando a navegação via _tab_ do que copiar e colar o endereço do seu explorador de arquivos. Para usar, abra aspas no RStudio, coloque o cursor do _mouse_ entre as aspas e aperte _tab_.

#' 
#' Um ponto importante aqui é que os **dados serão
#' 
#' Cada coluna do `dataframe` importado terá a sua
#' 
#' 
#' ## Pacote `adfeR`
#' 
#' Nas seções futuras iremos utilizar o pacote do 
#' 
## ---- eval = FALSE-------------------------------------------------------------------------------------------
## # install devtools (if not installed)
## if (!require(devtools)) install.packages ('devtools')
## 
## # install book package
## devtools::install_github ('msperlin/adfeR')

#' 
#' Uma vez que você instalou o pacote `adfeR`, tod
#' 
## ------------------------------------------------------------------------------------------------------------
# list available data files
print(adfeR::list_available_data()[1:5])

#' 
#' Os arquivos anteriores estão salvos na pasta de
#' 
## ---- eval = FALSE-------------------------------------------------------------------------------------------
## # get location of file
## my_f <- adfeR::get_data_file('grunfeld.csv')
## 
## # print it
## print(my_f)

#' 
#' A partir de agora iremos usar a função `adfeR::
#' 
#' 
#' ## Arquivos _csv_
#' 
#' Considere o arquivo de dados no formato `csv` c
#' 
## ---- eval = TRUE--------------------------------------------------------------------------------------------
# get location of file
my_f <- adfeR::get_data_file('Ibov.csv')

# copy to ~
file.copy(from = my_f, 
          to = '~' )

#' 

#' 
#' Caso seja a primeira vez trabalhando com arquiv
#' 

#' 
## Quando trabalhando com dados brasileiros, a notação internacional pode gerar uma confusão desnecessária. Dados locais tendem a usar a vírgula para indicar valores decimais em números. Assim, é comum que dados locais do Brasil sejam exportados usando a semi-vírgula (`;`) como separador de colunas e a própria vírgula como símbolo de decimais. Como regra de bolso, **nunca mude o formato no arquivo de texto original**. Deixe esse serviço para o próprio R e seus pacotes.

#' 
#' O conteúdo de `r basename(my_f)` é bastante con
#' 
#' 1) Verifique a existência de texto antes dos da
#' 
#' 2) Verifique a existência ou não dos nomes das 
#' 
#' 3) Verifique qual o símbolo de separador de col
#' 
#' 4) Para dados numéricos, verifique o símbolo de
#' 
#' 5) Verifique a codificação do arquivo de texto.
#' 
## Sempre que você encontrar uma estrutura de texto inesperada em um arquivo _.csv_, use os argumentos da função de leitura _csv_ para importar as informações corretamente. Repetindo,  **nunca modifique dados brutos manualmente**. É muito mais eficiente usar o código R para lidar com diferentes estruturas de arquivos em _.csv_. Pode parecer mais trabalhoso, mas essa política vai economizar muito tempo no futuro, pois, em algumas semanas, você provavelmente esquecerá como limpou manualmente aquele arquivo _.csv_ utilizado em pesquisa passada. Com o uso de código para a adaptação da importação de dados, sempre que você precisar atualizar o arquivo de dados, o código irá resolver todos os problemas, automatizando o processo.

#' 
#' 
#' ### Importação de Dados
#' 
#' O R possui uma função nativa chamada `base::rea
#' 
#' Este é a primeira vez que usamos um pacote do `
#' 
## ---- eval = FALSE-------------------------------------------------------------------------------------------
## install.packages('tidyverse')

#' 
#' Após executar o código anterior, todos os pacot
#' 
## ------------------------------------------------------------------------------------------------------------
# load library
library(tidyverse)

#' 
#' De volta à importação de dados de arquivos _.cs
#' 
## ---- message=TRUE-------------------------------------------------------------------------------------------
# set file to read
my_f <- adfeR::get_data_file('Ibov.csv')

# read data
my_df_ibov <- read_csv(my_f)

#' 
#' O conteúdo do arquivo importado é convertido pa
#' 
## ------------------------------------------------------------------------------------------------------------
# check content
glimpse(my_df_ibov)

#' 
#' Observe que a coluna de datas (`ref.date`) foi 
#' 
#' Observe também como o código anterior apresento
#' 
## ------------------------------------------------------------------------------------------------------------
# set cols from readr import message
my_cols <- cols(
  price.close = col_double(),
  ref.date = col_date(format = "")
)

# read file with readr::read_csv
my_df_ibov <- read_csv(my_f,
                       col_types = my_cols)

#' 
#' Como um exercício, vamos importar os mesmos dad
#' 
## ------------------------------------------------------------------------------------------------------------
# set cols from readr import message
my_cols <- cols(
  price.close = col_double(),
  ref.date = col_character()
)

# read file with readr::read_csv
my_df_ibov <- read_csv(my_f,
                       col_types = my_cols)

# check content
glimpse(my_df_ibov)

#' 
#' 
#' Como esperado, a coluna de datas -- `ref.date` 
#' 
#' Uma alternativa mais prática no uso do `read_cs
#' 
## ------------------------------------------------------------------------------------------------------------
# read file with readr::read_csv
my_df_ibov <- read_csv(my_f,
                       col_types = cols())

#' 
#' Agora, vamos estudar um caso mais anormal de ar
#' 
#' - o cabeçalho possui texto com informações dos 
#' - o arquivo usará a vírgula como decimal;
#' - o texto do arquivo conterá caracteres latinos
#' 
#' As primeiras 10 linhas dos arquivos contém o se
#' 
## ---- echo=FALSE---------------------------------------------------------------------------------------------
my_f <- adfeR::get_data_file('funky_csv_file.csv')

message(paste0(read_lines(my_f, 
                          n_max = 10), 
               collapse = '\n'))

#' 
#' Note a existência do cabeçalho até linha de núm
#' 
#' Ao importar os dados com opções padrões (e erra
#' 
## ------------------------------------------------------------------------------------------------------------
my_f <- adfeR::get_data_file('funky_csv_file.csv')

df_funky <- read_csv(my_f, 
                     col_types = cols())

glimpse(df_funky)

#' 
#' Claramente a importação deu errado, com a emiss
#' 
## ------------------------------------------------------------------------------------------------------------
df_not_funky <- read_delim(file = my_f, 
                           skip = 7, # how many lines do skip
                           delim = ';', # column separator
                           col_types = cols(), # column types
                           locale = locale(decimal_mark = ',')# locale
)

glimpse(df_not_funky)

#' 
#' Veja que agora os dados foram corretamente impo
#' 
#' 
#' ### Exportação de Dados
#' 
#' Para exportar tabelas em um arquivo _.csv_, bas
#' 
#' 
## ------------------------------------------------------------------------------------------------------------
library(readr)

# set number of observations
N <- 100

# create dataframe with random data
my_df <- data.frame(y = runif(N),
                    z = rep('a', N))

# write to file
f_out <- tempfile(fileext = '.csv')
write_csv(x = my_df, file = f_out)

#' 
#' No exemplo anterior, salvamos o `dataframe` cha
#' 
## ------------------------------------------------------------------------------------------------------------
my_df <- read_csv(f_out,
                  col_types = cols(y = col_double(),
                                   z = col_character() ) )
print(head(my_df))

#' 
#' O resultado está conforme o esperado, um datafr
#' 
#' Note que toda exportação com função `write_csv`
#' 
#' 
#' ## Arquivos _Excel_ (_xls_ e _xlsx_)
#' 
#' Em Finanças e Economia, é bastante comum encont
#' 
#' A desvantagem de usar arquivos do Excel para ar
#' 
#' 
#' ### Importação de Dados
#' 
#' O R não possui uma função nativa para importar 
#' 
#' Apesar de os pacotes anteriores terem objetivos
#' 
#' Nesta seção, daremos prioridade para funções do
#' 
## ----eval=FALSE----------------------------------------------------------------------------------------------
## install.packages('readxl')

#' 
#' Imagine agora a existência de um arquivo chamad
#' 
## ------------------------------------------------------------------------------------------------------------
library(readxl)
library(dplyr)

# set file
my_f <- '00-text-resources/data/Ibov_xlsx.xlsx'

# read xlsx into dataframe
my_df <- read_excel(my_f, sheet = 'Sheet1')

# glimpse contents
glimpse(my_df)

#' 
#' Observe que, nesse caso, as datas já foram impo
#' 
#' 
#' ### Exportação de Dados
#' 
#' A exportação para arquivo Excel também é fácil.
#' 
#' Vamos começar com um exemplo para `xlsx`
#' 
## ------------------------------------------------------------------------------------------------------------
library(xlsx)

# set number of rows
N <- 50

# create random dataframe
my_df <- data.frame(y = seq(1,N),
                    z = rep('a',N))

# write to xlsx
f_out <- tempfile(fileext = '.xlsx')
write.xlsx(x = my_df,
           file = f_out,
           sheetName = "my df")

#' 
#' \index{xlsx!write.xlsx}
#' 
#' Note que uma diferença nos argumentos da função
#' 
## ------------------------------------------------------------------------------------------------------------
# set number of rows
N <- 25

# create random dfs
my_df_A <- data.frame(y = seq(1,N),
                      z = rep('a',N))

my_df_B <- data.frame(z = rep('b',N))

# write both df to single file
f_out <- tempfile(fileext = '.xlsx')
write.xlsx(x = my_df_A,
           file = f_out,
           sheetName = "Tabela A")

write.xlsx(x = my_df_B,
           file = f_out,
           sheetName = "Tabela B",
           append = TRUE )

#' 
#' Após a exportação, podes verificar as abas disp
#' 
## ------------------------------------------------------------------------------------------------------------
readxl::excel_sheets(f_out)

#' 
#' O diferencial do pacote `writexl` em relação a 
#' 
## ---- eval=FALSE---------------------------------------------------------------------------------------------
## library(writexl)
## # set number of rows
## N <- 25
## 
## # create random dfs
## my_df_A <- data.frame(y = seq(1,N),
##                       z = rep('a',N))
## 
## write_xlsx(x = my_df_A,
##            file = f_out)

#' 
#' Para comparar o desempenho, vamos verificar a d
#' 
## ------------------------------------------------------------------------------------------------------------
library(writexl)
library(readxl)
library(xlsx)

# set number of rows
N <- 2500

# create random dfs
my_df_A <- data.frame(y = seq(1,N),
                      z = rep('a',N))

# set files
my_file_1 <- '00-text-resources/data/temp_writexl.xlsx'
my_file_2 <- '00-text-resources/data/temp_xlsx.xlsx'

# test export
time_write_writexl <- system.time(write_xlsx(x = my_df_A,
                                             path = my_file_1))

time_write_xlsx <- system.time(write.xlsx(x = my_df_A,
                                          file = my_file_2))

# test read
time_read_readxl <- system.time(read_xlsx(path = my_file_1 ))
time_read_xlsx <- system.time(read.xlsx(file = my_file_2,
                                        sheetIndex = 1 ))

#' 
#' Após a execução, vamos verificar a diferença de
#' 
## ---- results='hold'-----------------------------------------------------------------------------------------
# results
my_formats <- c('xlsx', 'readxl')
results_read <- c(time_read_xlsx[3], time_read_readxl[3])
results_write<- c(time_write_xlsx[3], time_write_writexl[3])

# print text
my_text <- paste0('\nTime to WRITE dataframe with ',
                  my_formats, ': ',
                  format(results_write, digits = 4),
                  ' seconds', collapse = '')
message(my_text)

my_text <- paste0('\nTime to READ dataframe with ',
                  my_formats, ': ',
                  format(results_read, digits = 4),
                  ' seconds', collapse = '')
message(my_text)

#' 
#' Como podemos ver, mesmo para dados de pouco vol
#' 
#' 
#' ## Formato _.RData_ e _.rds_
#' 
#' O R possui dois formatos nativos para salvar ob
#' 
#' 
#' ### Importação de Dados
#' 
#' Para carregar os dados de um aquivo `RData`, ut
#' 
## ------------------------------------------------------------------------------------------------------------
# set a object
my_x <- 1:100

# set temp name of RData file
my_file <- adfeR::get_data_file('temp.RData')

# load it
load(file = my_file)

#' 
#' O arquivo `r basename(my_file)` possui dois obj
#' 
#' O processo de importação para arquivos _.rds_ é
#' 
## ------------------------------------------------------------------------------------------------------------
# set file path
my_file <- adfeR::get_data_file('temp.rds')

# load content into workspace
my_x <- readr::read_rds(file = my_file)

#' 
#' Comparando o código entre o uso de arquivos `.R
#' 
## Como sugestão, dê preferência ao uso do formato _.rds_, o qual é mais prático no dia a dia, deixando o código mais claro. A diferença de velocidade de acesso e gravação entre um e outro é mínima. O benefício de importar vários objetos em um mesmo arquivo com o formato `RData` torna-se irrelevante quando no uso de objetos do tipo lista, os quais podem incorporar outros objetos no seu conteúdo. Veremos mais detalhes sobre este tipo de objeto no capítulo \@ref(classe-estrutura)

#' 
#' 
#' ### Exportação de Dados
#' 
#' Para criar um novo arquivo _RData_, utilizamos 
#' 
## ------------------------------------------------------------------------------------------------------------
# set vars
my_x <- 1:100
my_y <- 1:100

# write to RData
my_file <- tempfile(fileext = '.RData')
save(list = c('my_x', 'my_y'),
     file = my_file)

#' 
#' Podemos verificar a existência do arquivo com a
#' 
## ------------------------------------------------------------------------------------------------------------
file.exists(my_file)

#' 
#' Observe que o arquivo `r basename(my_file)` est
#' 
#' Já para arquivos _.rds_, salvamos o objeto com 
#' 
## ------------------------------------------------------------------------------------------------------------
# set data and file
my_x <- 1:100
my_file <- '00-text-resources/data/temp.rds'

# save as .rds
saveRDS(object = my_x,
        file = my_file)

# read it
my_x2 <- readRDS(file = my_file)

# test equality
print(identical(my_x, my_x2))

#' 
#' O comando `identical` testa a igualdade entre o
#' 
#' 
#' ## Arquivos _fst_ (pacote `fst`)
#' 
#' O formato [_fst_](http://www.fstpackage.org/) f
#' 
#' 
#' ### Importação de Dados
#' 
#' O uso do formato _fst_ é bastante simples. Util
#' 
## ------------------------------------------------------------------------------------------------------------
library(fst)

my_file <- adfeR::get_data_file('temp.fst')
my_df <- read_fst(my_file)

glimpse(my_df)

#' 
#' Assim como para os demais casos, os dados estão
#' 
#' 
#' ### Exportação de Dados
#' 
#' Utilizamos a função `write_fst` para gravar arq
#' 
## ------------------------------------------------------------------------------------------------------------
library(fst)

# create dataframe
N <- 1000
my_file <- tempfile(fileext = '.fst')
my_df <- data.frame(x = runif(N))

# write to fst
write_fst(x = my_df, path = my_file)

#' 
#' ### Testando o Tempo de Execução do formato _fs
#' 
#' Como um teste do potencial do pacote `fst`, a s
#' 
## ------------------------------------------------------------------------------------------------------------
library(fst)

# set number of rows
N <- 5000000

# create random dfs
my_df <- data.frame(y = seq(1,N),
                    z = rep('a',N))

# set files
my_file_1 <- '00-text-resources/data/temp_rds.rds'
my_file_2 <- '00-text-resources/data/temp_fst.fst'

# test write
time_write_rds <- system.time(write_rds(my_df, my_file_1 ))
time_write_fst <- system.time(write_fst(my_df, my_file_2 ))

# test read
time_read_rds <- system.time(readRDS(my_file_1))
time_read_fst <- system.time(read_fst(my_file_2))

# test file size (MB)
file_size_rds <- file.size(my_file_1)/1000000
file_size_fst <- file.size(my_file_2)/1000000

#' 
#' Após a execução, vamos verificar o resultado:
#' 
## ---- results='hold'-----------------------------------------------------------------------------------------
# results
my_formats <- c('.rds', '.fst')
results_read <- c(time_read_rds[3], time_read_fst[3])
results_write<- c(time_write_rds[3], time_write_fst[3])
results_file_size <- c(file_size_rds , file_size_fst)

# print text
my_text <- paste0('\nTime to WRITE dataframe with ',
                  my_formats, ': ',
                  results_write, ' seconds', collapse = '')
message(my_text)

my_text <- paste0('\nTime to READ dataframe with ',
                  my_formats, ': ',
                  results_read, ' seconds', collapse = '')
message(my_text)

my_text <- paste0('\nResulting FILE SIZE for ',
                  my_formats, ': ',
                  results_file_size, ' MBs', collapse = '')
message(my_text)

#' 
#' A diferença é gritante! O formato `fst` não som
#' 
## Devido ao uso de todos os núcleos do computador, o formato _fst_ é altamente recomendado quando estiver trabalhando com dados volumosos em um computador potente. Não somente os arquivos resultantes serão menores, mas o processo de gravação e leitura será consideravelmente mais rápido.

#' 
#' 
#' ## Arquivos _SQLite_
#' 
#' O uso de arquivos _csv_, _rds_ e _fst_ para arm
#' 
#' Isso nos leva ao tópico de programas de armazen
#' 
#' Antes de irmos para os exemplos, precisamos ent
#' 
#' 
#' ### Importação de Dados
#' 
#' Assumindo a existência de um arquivo com format
#' 
## ------------------------------------------------------------------------------------------------------------
library(RSQLite)

# set name of SQLITE file
f_sqlite <- adfeR::get_data_file('SQLite_db.SQLITE')

# open connection
my_con <- dbConnect(drv = SQLite(), f_sqlite)

# read table
my_df <- dbReadTable(conn = my_con,
                     name = 'MyTable1') # name of table in sqlite

# print with str
glimpse(my_df)

#' 
#' Outro exemplo do uso do SQLITE é com instruções
#' 
## ------------------------------------------------------------------------------------------------------------
# set sql statement
my_SQL_statement <- "select * from myTable2 where G='A'"

# get query
my_df_A <- dbGetQuery(conn = my_con, 
                      statement = my_SQL_statement)

# disconnect from db
dbDisconnect(my_con)

# print with str
print(str(my_df_A))

#' 
#' Nesse exemplo simples podemos ver como é fácil 
#' 
#' 
#' ### Exportação de Dados
#' 
#' Como exemplo, vamos criar dois dataframes com d
#' 
## ---- tidy=FALSE---------------------------------------------------------------------------------------------
library(RSQLite)

# set number of rows in df
N = 10^6 

# create simulated dataframe
my_large_df_1 <- data.frame(x=runif(N), 
                            G= sample(c('A','B'),
                                      size = N,
                                      replace = TRUE))

my_large_df_2 <- data.frame(x=runif(N), 
                            G = sample(c('A','B'),
                                       size = N,
                                       replace = TRUE))

# set name of SQLITE file
f_sqlite <- tempfile(fileext = '.SQLITE')

# open connection
my_con <- dbConnect(drv = SQLite(), f_sqlite)

# write df to sqlite
dbWriteTable(conn = my_con, name = 'MyTable1', 
             value = my_large_df_1)
dbWriteTable(conn = my_con, name = 'MyTable2', 
             value = my_large_df_2)

# disconnect
dbDisconnect(my_con)

#' 
#' A saída `TRUE` de `dbWriteTable` indica que tud
#' 
#' 
#' ## Dados Não-Estruturados e Outros Formatos
#' 
#' Os pacotes e formatos anteriores são suficiente
#' 
#' Em alguns casos nos deparamos com dados armazen
#' 
## ------------------------------------------------------------------------------------------------------------
# set file to read
my_f <- afedR::afedR_get_data_file('pride_and_prejudice.txt')

# read file line by line
my_txt <- read_lines(my_f)

# print 50 characters of first fifteen lines
print(str_sub(string = my_txt[1:15], 
              start = 1, 
              end = 50))

#' 
#' Neste exemplo, arquivo `r basename(my_f)` conté
#' 
## ------------------------------------------------------------------------------------------------------------
# count number of lines
n_lines <- length(my_txt)

# set target text
name_to_search <- 'Bennet'

# set function for counting words
fct_count_bennet <- function(str_in, target_text) {
  
  require(stringr)
  
  
  n_words <- length(str_locate_all(string = str_in, 
                                   pattern = target_text)[[1]])
  
  return(n_words)
}

# use fct for all lines of Pride and Prejudice
n_times <- sum(sapply(X = my_txt, 
                      FUN = fct_count_bennet, 
                      target_text = name_to_search))

# print results
my_msg <- paste0('The number of lines found in the file is ', 
                 n_lines, '.\n',
                 'The word "', name_to_search, '" appears ', 
                 n_times, ' times in the book.')
message(my_msg)

#' 
#' No exemplo, mais uma vez usamos `sapply`. Neste
#' 
#' 
#' ### Exportando de Dados Não-Estruturados
#' 
#' Em algumas situações, é necessário exportar alg
#' 
## ------------------------------------------------------------------------------------------------------------
# set file
my_f <- tempfile(fileext = '.txt')

# set some string
my_text <- paste0('Today is ', Sys.Date(), '\n', 
                  'Tomorrow is ', Sys.Date()+1)

# save string to file
write_lines(x = my_text, file = my_f, append = FALSE)

#' 
#' No exemplo, criamos um objeto de texto com uma 
#' 
## ------------------------------------------------------------------------------------------------------------
print(read_lines(my_f))

#' 
#' 
#' ## Selecionando o Formato
#' 
#' Após entendermos a forma de salvar e carregar d
#' 
#' - velocidade de importação e exportação;
#' - tamanho do arquivo resultante;
#' - compatibilidade com outros programas e sistem
#' 
#' Na grande maioria das situações, o uso de arqui
#' 
#' Existem casos, porém, onde a velocidade de impo
#' 
#' 
#' ## Exercícios {#exerc-importacao-exportacao}
#' 
## ---- echo=FALSE, results='asis'-----------------------------------------------------------------------------
f_in <- list.files('../02-EOCE-Rmd//Cap04-Import-Local/', 
                   full.names = TRUE)

build_exercises(f_in, type_doc = my_engine)
