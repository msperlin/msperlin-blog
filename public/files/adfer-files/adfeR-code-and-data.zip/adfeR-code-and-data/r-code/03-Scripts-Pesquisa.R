#' # Desenvolvendo Rotinas de Pesquisa {#scripts-p
#' 

#' 
#' No capítulo anterior aprendemos a utilizar o R 
#' 
#' Neste capítulo iremos tratar das etapas de pesq
#' 
#' 
#' ## Etapas de uma Pesquisa
#' 
#' Um _script_ de pesquisa pode ser organizado em 
#' 
#' 1. **Importação dos dados**: Dados crus (origin
#' 
#' 2. **Limpeza e estruturação dos dados**: Dados 
#' 
#' 3. **Visualização de dados e teste de hipóteses
#' 
#' 4. **Reportando os resultados**: A última etapa
#' 
#' Cada uma das etapas anteriores pode ser estrutu
#' 
#' Um caso prático seria a análise de dados volumo
#' 
#' Caso você for trabalhar com diversos arquivos, 
#' 
#' 
#' ## A Estrutura de Diretórios {#diretorios}
#' 
#' Uma estrutura de organização de diretórios tamb
#' 
#' Uma estrutura de diretórios que considero efici
#' 
#' 	/Capital Markets and Inflation/
#' 		/data/
#' 			stock_indices.csv
#' 			inflation_data.csv
#' 		/figs/
#' 			SP500_and_inflation.png
#' 		/tables/
#' 			Table1_descriptive_table.tex
#' 			Table2_model_results.tex
#' 		/R-Fcts/
#' 			fct_models.R
#' 			fct_clean_data.R
#' 		0-run-it-all.R
#' 		1-import-and-clean-data.R
#' 		2-run-research.R
#' 
#' 
#' O código de pesquisa também deve ser independen
#' 
#' Os benefícios deste formato de diretório são os
#' 
#' Seguindo a sugestão de um _script_ mestre, um e
#' 
## ----eval=FALSE----------------------------------------------------------------------------------------------
## # clean up workspace
## rm(list=ls())
## 
## # close all figure windows created with x11()
## graphics.off()
## 
## # load packages
## library(pkg1)
## library(pkg2)
## library(pkg3)
## 
## # change directory
## my_dir <- dirname(rstudioapi::getActiveDocumentContext()$path)
## setwd(my.d)
## 
## # list  functions in 'R-Fcts'
## my_R_files <- list.files(path='R-Fcts',
##                          pattern = '*.R',
##                          full.names=TRUE)
## 
## # Load all functions in R
## sapply(my_R_files,source)
## 
## # Import data script
## source('01-import-and-clean-data.R')
## 
## # run models and report results
## source('02-run-research.R')

#' 
#' Essa é a primeira vez que usamos as funções `gr
#' 
#' Note que, assumindo que todos os pacotes já est
#' 
#' 
#' ## Pontos Importantes em uma Pesquisa
#' 
#' Aproveitando o tópico de execução de pesquisa, 
#' 
#' **Em primeiro lugar, conheça os seus dados!** E
#' 
#' - Como os dados foram coletados? Para que fim?
#' - Como estes dados se comparam com dados já uti
#' - Existe alguma possibilidade de viés na forma 
#' 
#' Lembre-se que o propósito final de qualquer pes
#' 
#' Portanto, **seja muito cauteloso sobre os dados
#' 
#' O segundo ponto é o código. Após terminar de le
#' 
#' Lembre que analisar dados é a sua profissão e a
#' 
#' - As estatísticas descritivas das variáveis rel
#' - Existe alguma relação entre as variáveis que 
#' - Os resultados encontrados fazem sentido para 
#' - É possível que um _bug_ no código tenha produ
#' 
#' Ainda me surpreendo como pesquisas submetidas a
#' 
#' Todo o trabalho de pesquisa é, de certa forma, 
#' 
#' Deixo claro que é possível sim que resultados d
#' 
#' 
#' ## Exercícios {#exerc-scripts-pesquisa}
#' 
## ---- echo=FALSE, results='asis'-----------------------------------------------------------------------------
f_in <- list.files('../02-EOCE-Rmd//Cap03-Scripts-Pesquisa/', 
                   full.names = TRUE)

build_exercises(f_in, type_doc = my_engine)
