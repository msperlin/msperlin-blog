#' # Dataframes e outros Objetos {#classe-estrutur
#' 

#' 
#' **No R, tudo é um objeto**. Sempre que chamamos
#' 
#' As classes básicas de objetos no R inclui valor
#' 
#' Uma maneira mais simples de organizar os nossos
#' 
#' 
#' ## `Dataframes`
#' 
#' Traduzindo para o português, `dataframe` signif
#' 
#' Note que o formato tabular força a sincronizaçã
#' 
#' Um dos pontos positivos na utilização do datafr
#' 
#' O objeto dataframe é uma das classes nativas do
#' 
#' 
#' ### Criando `dataframes`
#' 
#' A criação de um dataframe do tipo `tibble` ocor
#' 
## ------------------------------------------------------------------------------------------------------------
library(tibble)

# set tickers
ticker <- c(rep('ABEV3',4),
            rep('BBAS3', 4),
            rep('BBDC3', 4))

# set dates
ref_date <- as.Date(rep(c('2010-01-01', '2010-01-04',
                          '2010-01-05', '2010-01-06'),
                        3) )

# set prices
price <- c(736.67, 764.14, 768.63, 776.47,
           59.4  , 59.8  , 59.2  , 59.28,
           29.81 , 30.82 , 30.38 , 30.20)

# create tibble/dataframe
my_df <- tibble(ticker, ref_date , price)

# print it
print(my_df)

#' 
#' Observe que utilizamos a função `rep` para repl
#' 
## O conteúdo de `dataframes` também pode ser visualizado no próprio RStudio. Para isso, basta clicar no nome do objeto na aba _environment_, canto superior direito da tela. Após isso, um visualizador aparecerá na tela principal do programa. Essa operação é nada mais que uma chamada a função  `utils::View`. Portanto, poderíamos visualizar o `dataframe` anterior executando o comando `View(my_df)`.

#' 
#' \index{utils!View}
#' 
#' 
#' 
#' ### Inspecionando um `dataframe`
#' 
#' Após a criação do `dataframe`, o segundo passo 
#' 
#' Número de linhas e colunas
#' : O número de linhas e colunas da tabela result
#' 
#' Nomes das colunas
#' : É importante que a tabela importada tenha nom
#' 
#' Classes das colunas
#' : Cada coluna de um `dataframe` tem sua própria
#' 
#' Existência de dados omissos (`NA`)
#' : Devemos também verificar o número de valores 
#' 
#' Uma das funções mais recomendadas para se famil
#' 
## ------------------------------------------------------------------------------------------------------------
library(dplyr)

# check content of my_df
glimpse(my_df)

#' 
#' Em muitas situações, o uso de `glimpse` é sufic
#' 
## ------------------------------------------------------------------------------------------------------------
# check variation my_df
summary(my_df)

#' 
#' Note que `summary` interpreta cada coluna de fo
#' 
#' 
## Toda vez que se deparar com um novo `dataframe` no R, pegue o hábito de verificar o seu conteúdo com funções `dplyr::glimpse` e `base::summary`. Assim, poderá perceber problemas de importação e/ou conteúdo dos arquivos lidos. Com experiência irás perceber que muitos erros futuros em código podem ser sanados por uma simples inspeção das tabelas importadas.

#' 
#' 
#' ### Operador de _pipeline_ (`%>%`)
#' 
#' Uma característica importante do universo `tidy
#' 
#' Imagine uma situação onde temos três funções pa
#' 
## ---- eval=FALSE---------------------------------------------------------------------------------------------
## my_tab <- my_df %>%
##   fct1(arg1) %>%
##   fct2(arg2) %>%
##   fct3(arg3)

#' 
#' Usamos símbolo `%>%` no final de cada linha par
#' 
## ---- eval=FALSE---------------------------------------------------------------------------------------------
## # version 1
## my_tab <- fct3(fct2(fct1(my_df,
##                          arg1),
##                     arg2),
##                arg1)
## 
## # version 2
## temp1 <- fct1(my_df, arg1)
## temp2 <- fct2(temp1, arg2)
## my_tab <- fct3(temp1, arg3)

#' 
#' Observe como as alternativas formam um código c
#' 
#' 
#' ### Acessando Colunas
#' 
#' Um objeto do tipo `dataframe` utiliza-se de div
#' 
## ------------------------------------------------------------------------------------------------------------
# check names of df
names(my_df)
colnames(my_df)

#' 
#' Ambas também podem ser usadas para modificar os
#' 
## ------------------------------------------------------------------------------------------------------------
# set temp df
temp_df <- my_df

# check names
names(temp_df)

# change names
names(temp_df) <- paste0('Col', 1:ncol(temp_df))

# check names
names(temp_df)

#' 
#' Destaca-se que a forma de usar `names` é bastan
#' 
#' Para acessar uma determinada coluna, podemos ut
#' 
## ------------------------------------------------------------------------------------------------------------
# isolate columns of df
my_ticker <- my_df$ticker
my_prices <- my_df[['price']]

# print contents
print(my_ticker)
print(my_prices)

#' 
#' Note o uso do duplo colchetes (`[[]]`) para sel
#' 
## ------------------------------------------------------------------------------------------------------------
print(my_df[[2]])

#' 
#' Para acessar linhas e colunas específicas de um
#' 
## ------------------------------------------------------------------------------------------------------------
print(my_df[1:5,2])

#' 
## ------------------------------------------------------------------------------------------------------------
print(my_df[1:5,c(1,2)])

#' 
## ------------------------------------------------------------------------------------------------------------
print(my_df[1:5, ])

#' 
#' Essa seleção de colunas também pode ser realiza
#' 
## ------------------------------------------------------------------------------------------------------------
print(my_df[1:3, c('ticker','price')])

#' 
#' ou, pelo operador de _pipeline_ e a função `dpl
#' 
## ------------------------------------------------------------------------------------------------------------
library(dplyr)

my.temp <- my_df %>%
  select(ticker, price) %>%
  glimpse()

#' 
#' 
#' ### Modificando um `dataframe`
#' 
#' Para criar novas colunas em um `dataframe`, bas
#' 
## ------------------------------------------------------------------------------------------------------------
library(dplyr)

# add columns with mutate
my_df <- my_df %>%
  mutate(ret = price/lag(price) -1,
         my_seq1 = 1:nrow(my_df),
         my_seq2 =  my_seq1 +9) %>%
  glimpse()


#' 
#' Note que precisamos indicar o `dataframe` de or
#' 
#' A maneira mais tradicional, e comumente encontr
#' 
## ------------------------------------------------------------------------------------------------------------
# add new column with base R
my_df$my_seq3 <- 1:nrow(my_df)

# check it
glimpse(my_df)

#' 
#' Portanto, o operador `$` vale tanto para acessa
#' 
#' Para remover colunas de um `dataframe`, basta u
#' 
## ------------------------------------------------------------------------------------------------------------
# removing columns
my_df_temp <- my_df %>%
  select(-my_seq1, -my_seq2, -my_seq3) %>%
  glimpse()

#' 
#' No uso de funções nativas do R, a maneira tradi
#' 
## ------------------------------------------------------------------------------------------------------------
# set temp df
temp_df <- my_df

# remove cols
temp_df$price <- NULL
temp_df$ref_date  <- NULL

# check it
glimpse(temp_df)

#' 
#' 
#' ### Filtrando um `dataframe`
#' 
#' Uma operação bastante comum no R é filtrar linh
#' 
## ------------------------------------------------------------------------------------------------------------
library(dplyr)

# filter df for single stock
my_df_temp <- my_df %>%
  filter(ticker == 'ABEV3') %>%
  glimpse()

#' 
#' A função também aceita mais de uma condição. Ve
#' 
## ------------------------------------------------------------------------------------------------------------
library(dplyr)
# filter df for single stock and date
my_df_temp <- my_df %>%
  filter(ticker == 'ABEV3',
         ref_date >= as.Date('2010-01-05')) %>%
  glimpse()

#' 
#' Aqui utilizamos o símbolo `==` para testar uma 
#' 
#' 
#' ### Ordenando um `dataframe`
#' 
#' Após a criação ou importação de um `dataframe`,
#' 
#' Como exemplo, considere a criação de um `datafr
#' 
## ------------------------------------------------------------------------------------------------------------
library(tidyverse)

# set df
my_df <- tibble(col1 = c(4,1,2),
                col2 = c(1,1,3),
                col3 = c('a','b','c'))

# print it
print(my_df)

#' 
#' A função `order` retorna os índices relativos à
#' 
## ------------------------------------------------------------------------------------------------------------
idx <- order(my_df$col1)
print(idx)

#' 
#' Portanto, ao utilizar a saída da função `order`
#' 
## ------------------------------------------------------------------------------------------------------------
my_df_2 <- my_df[order(my_df$col1), ]
print(my_df_2)

#' 
#' Essa operação de ordenamento também pode ser re
#' 
## ------------------------------------------------------------------------------------------------------------
idx <- order(my_df$col2, my_df$col1)
my_df_3 <- my_df[idx, ]
print(my_df_3)

#' 
#' No `tidyverse`, a forma de ordenar `dataframes`
#' 
## ------------------------------------------------------------------------------------------------------------
# sort ascending, by col1 and col2
my_df <- my_df %>%
  arrange(col1, col2) %>%
  print()

# sort descending, col1 and col2
my_df <- my_df %>%
  arrange(desc(col1), desc(col2)) %>%
  print()

#' 
#' O resultado prático no uso de `arrange` é o mes
#' 
#' 
#' ### Combinando e Agregando `dataframes`
#' 
#' Em muitas situações de análise de dados será ne
#' 
## ------------------------------------------------------------------------------------------------------------
library(dplyr)

# set dfs
my_df_1 <- tibble(col1 = 1:5,
                  col2 = rep('a', 5))

my_df_2 <- tibble(col1 = 6:10,
                  col2 = rep('b', 5),
                  col3 = rep('c', 5))

# bind by row
my_df <- bind_rows(my_df_1, my_df_2) %>%
  glimpse()

#' 
#' Note que, no exemplo anterior, os nomes das col
#' 
## ------------------------------------------------------------------------------------------------------------
# set dfs
my_df_1 <- tibble(col1 = 1:5, col2 = rep('a', 5))
my_df_2 <- tibble(col3 = 6:10, col4 = rep('b', 5))

# bind by column
my_df <- bind_cols(my_df_1, my_df_2) %>%
  glimpse()

#' 
#' Para casos mais complexos, onde a junção deve s
#' 
## ------------------------------------------------------------------------------------------------------------
# set df
my_df_1 <- tibble(date = as.Date('2016-01-01')+0:10,
                  x = 1:11)

my_df_2 <- tibble(date = as.Date('2016-01-05')+0:10,
                  y = seq(20,30, length.out = 11))


#' 
#' Note que os `dataframes` criados possuem uma co
#' 
## ------------------------------------------------------------------------------------------------------------
# aggregate tables
my_df <- inner_join(my_df_1, my_df_2)

glimpse(my_df)

#' 
#' O R automaticamente verifica a existência de co
#' 
## ------------------------------------------------------------------------------------------------------------
# set df
my_df_3 <- tibble(ref_date = as.Date('2016-01-01')+0:10,
                  x = 1:11)

my_df_4 <- tibble(my_date = as.Date('2016-01-05')+0:10,
                  y = seq(20,30, length.out = 11))

# join by my_df_3$ref_date and my_df_4$my_date
my_df <- inner_join(my_df_3, my_df_4,
                    by = c('ref_date' = 'my_date'))

glimpse(my_df)

#' 
#' Para o caso de uso da função nativa de agregaçã
#' 
## ------------------------------------------------------------------------------------------------------------
# aggregation with base R
my_df <- merge(my_df_1, my_df_2, by = 'date')

glimpse(my_df)

#' 
#' Note que, nesse caso, o `dataframe` resultante 
#' 
#' As demais funções de agregação de tabelas -- `l
#' 
## ------------------------------------------------------------------------------------------------------------
# set df
my_df_5 <- tibble(ref_date = as.Date('2016-01-01')+0:10,
                  x = 1:11)

my_df_6 <- tibble(ref_date = as.Date('2016-01-05')+0:10,
                  y = seq(20,30, length.out = 11))

# combine with full_join
my_df <- full_join(my_df_5, my_df_6)

# print it
print(my_df)

#' 
#' 
#' ### Extensões ao `dataframe`
#' 
#' Como já foi relatado nos capítulos anteriores, 
#' 
#' Por exemplo, é muito comum trabalharmos com dad
#' 
#' Veja um caso a seguir, onde carregamos os dados
#' 
## ------------------------------------------------------------------------------------------------------------
library(xts)

# set data
ticker <- c('ABEV3', 'BBAS3','BBDC3')

date <- as.Date(c('2010-01-01', '2010-01-04',
                  '2010-01-05', '2010-01-06'))

price_ABEV3 <- c(736.67, 764.14, 768.63, 776.47)
price_BBAS3 <- c(59.4, 59.8, 59.2, 59.28)
price_BBDC3 <- c(29.81, 30.82, 30.38, 30.20)

# build matrix
my_mat <- matrix(c(price_BBDC3, price_BBAS3, price_ABEV3),
                 nrow = length(date) )

# set xts object
my_xts <- xts(my_mat,
              order.by = date)

# set correct colnames
colnames(my_xts) <- ticker

# check it!
print(my_xts)

#' 
#' O código anterior pode dar a impressão de que o
#' 
## ------------------------------------------------------------------------------------------------------------
N <- 500

my_mat <- matrix(c(seq(1, N), seq(N, 1)), nrow=N)

my_xts <- xts(my_mat, order.by = as.Date('2016-01-01')+1:N)

my_xts.weekly.mean <- apply.weekly(my_xts, mean)

print(head(my_xts.weekly.mean))

#' 
#' Em Finanças e Economia, as agregações com objet
#' 
#' Indo além, existem diversos outros tipos de `da
#' 
#' 
#' ### Outras Funções Úteis
#' 
#' **head** - Retorna os primeiros `n` elementos d
#' 
## ------------------------------------------------------------------------------------------------------------
my_df <- tibble(col1 = 1:5000, col2 = rep('a', 5000))
head(my_df, 5)

#' 
#' **tail** - Retorna os últimos `n` elementos de 
#' 
## ------------------------------------------------------------------------------------------------------------
tail(my_df, 5)

#' 
#' **complete.cases** - Retorna um vetor lógico qu
#' 
## ------------------------------------------------------------------------------------------------------------
my_x <- c(1:5, NA, 10)
my_y <- c(5:10, NA)
my_df <- tibble(my_x, my_y)

print(my_df)
print(complete.cases(my_df))
print(which(!complete.cases(my_df)))

#' 
#' **na.omit** - Retorna um `dataframe` sem as lin
#' 
## ------------------------------------------------------------------------------------------------------------
print(na.omit(my_df))

#' 
#' **unique** - Retorna um `dataframe` onde todas 
#' 
## ------------------------------------------------------------------------------------------------------------
my_df <- tibble(col1 = c(1,1,2,3,3,4,5),
                col2 = c('A','A','A','C','C','B','D'))

print(my_df)
print(unique(my_df))

#' 
#' 
#' ## Listas
#' 
#' Uma lista (`list`) é uma classe de objeto extre
#' 
#' 
#' ### Criando Listas
#' 
#' Uma lista pode ser criada através do comando `b
#' 
## ------------------------------------------------------------------------------------------------------------
library(dplyr)

# create list
my_l <- list(c(1, 2, 3),
             c('a', 'b'),
             factor('A', 'B', 'C'),
             tibble(col1 = 1:5))

# use base::print
print(my_l)

# use dplyr::glimpse
glimpse(my_l)

#' 
#' Note que juntamos no mesmo objeto um vetor atôm
#' 
#' Assim como para os demais tipos de objeto, os e
#' 
## ------------------------------------------------------------------------------------------------------------
# set named list
my_named_l <- list(ticker = 'TICK4',
                   market = 'Bovespa',
                   df_prices = tibble(P = c(1,1.5,2,2.3),
                                      ref_date = Sys.Date()+0:3))

# check content
glimpse(my_named_l)

#' 
## Toda vez que for trabalhar com listas, facilite a sua vida ao  nomear todos os elementos de forma intuitiva. Isso facilita o acesso e evito possíveis erros no código.

#' 
#' 
#' ### Acessando os Elementos de uma Lista
#' 
#' Os elementos de uma lista podem ser acessados a
#' 
## ------------------------------------------------------------------------------------------------------------
# accessing elements from list
print(my_named_l[[2]])
print(my_named_l[[3]])

#' 
#' Também é possível acessar os elementos com um c
#' 
## ------------------------------------------------------------------------------------------------------------
# set list
my_l <- list('a',
             c(1,2,3),
             factor('a','b'))

# check classes
class(my_l[[2]])
class(my_l[2])

#' 
#' Caso tentarmos somar um elemento a `my_l[2]`, t
#' 
## ----error=TRUE----------------------------------------------------------------------------------------------
my_l[2] + 1

#' 
#' Esse erro ocorre devido ao fato de que uma list
#' 
## ------------------------------------------------------------------------------------------------------------
# set new list
my_new_l <- my_l[c(1,2)]

# check contents
print(my_new_l)
class(my_new_l)

#' 
#' No caso de listas com elementos nomeados, os me
#' 
## Saiba que a ferramenta de _autocomplete_ do RStudio também funciona para listas. Para usar, digite o nome da lista seguido de `$` e aperte _tab_. Uma caixa de diálogo com todos os elementos disponíveis na lista irá aparecer. A partir disso, basta selecionar apertando _enter_.

#' 
#' Veja os exemplos a seguir, onde são apresentada
#' 
## ---- eval=FALSE---------------------------------------------------------------------------------------------
## # different ways to access a list
## my_named_l$ticker
## my_named_l$price
## my_named_l[['ticker']]
## my_named_l[['price']]

#' 
#' Vale salientar que também é possível acessar di
#' 
## ------------------------------------------------------------------------------------------------------------
# accessing elements of a vector in a list
my_l <- list(c(1,2,3),
             c('a', 'b'))

print(my_l[[1]][2])
print(my_l[[2]][1])

#' 
#' Tal operação é bastante útil quando interessa a
#' 
#' 
#' ### Adicionando e Removendo Elementos de uma Li
#' 
#' A remoção, adição e substituição de elementos d
#' 
## ------------------------------------------------------------------------------------------------------------
# set list
my_l <- list('a', 1, 3)
glimpse(my_l)

# add new elements to list
my_l[[4]] <- c(1:5)
my_l[[2]] <- c('b')

# print result
glimpse(my_l)

#' 
#' A operação também é possível com o uso de nomes
#' 
## ------------------------------------------------------------------------------------------------------------
# set list
my_l <- list(elem1 = 'a', name1=5)

# set new element
my_l$name2 <- 10
glimpse(my_l)

#' 
#' Para remover elementos de uma lista, basta defi
#' 
## ------------------------------------------------------------------------------------------------------------
# set list
my_l <- list(text = 'b', num1 = 2, num2 = 4)
glimpse(my_l)

# remove elements
my_l[[3]] <- NULL
glimpse(my_l)

my_l$num1 <- NULL
glimpse(my_l)

#' 
#' Outra maneira de retirar elementos de uma lista
#' 
## ------------------------------------------------------------------------------------------------------------
# set list
my_l <- list(a = 1, b = 'texto')

# remove second element
glimpse(my_l[[-2]])

#' 
#' Assim como no caso de vetores atômicos, essa re
#' 
## ------------------------------------------------------------------------------------------------------------
# set list
my_l <- list(1, 2, 3, 4)

# remove elements by condition
my_l[my_l > 2] <- NULL
glimpse(my_l)

#' 
#' Porém, note que esse atalho só funciona porque 
#' 
#' 
#' ### Processando os Elementos de uma Lista
#' 
#' Um ponto importante a ser destacado a respeito 
#' 
#' Por exemplo, imagine uma lista com vetores numé
#' 
## ------------------------------------------------------------------------------------------------------------
# set list
my_l_num <- list(c(1, 2, 3),
                 seq(1:50),
                 seq(-5, 5, by = 0.5))

#' 
#' Caso quiséssemos calcular a média de cada eleme
#' 
## ------------------------------------------------------------------------------------------------------------
# calculate mean of vectors
mean_1 <- mean(my_l_num[[1]])
mean_2 <- mean(my_l_num[[2]])
mean_3 <- mean(my_l_num[[3]])

# print it
print(c(mean_1, mean_2, mean_3))

#' 
#' O código anterior funciona, porém não é recomen
#' 
#' Uma maneira mais fácil, elegante e inteligente 
#' 
## ------------------------------------------------------------------------------------------------------------
# using sapply
my_mean <- sapply(my_l_num, mean)

# print result
print(my_mean)

#' 
#' O uso da função `sapply` é preferível por ser m
#' 
#' Essa visão e implementação de código voltado a 
#' 
#' 
#' ### Outras Funções Úteis
#' 
#' **unlist** - Retorna os elementos de uma lista 
#' 
## ------------------------------------------------------------------------------------------------------------
my_named_l <- list(ticker = 'XXXX4',
                   price = c(1,1.5,2,3),
                   market = 'Bovespa')
my_unlisted <- unlist(my_named_l)
print(my_unlisted)
class(my_unlisted)

#' 
#' **as.list** - Converte um objeto para uma lista
#' 
## ------------------------------------------------------------------------------------------------------------
my_x <- 10:13
my_x_as_list <- as.list(my_x)
print(my_x_as_list)

#' 
#' **names** - Retorna ou define os nomes dos elem
#' 
## ------------------------------------------------------------------------------------------------------------
my_l <- list(value1 = 1, value2 = 2, value3 = 3)
print(names(my_l))
my_l <- list(1,2,3)
names(my_l) <- c('num1', 'num2', 'num3')
print(my_l)

#' 
#' 
#' ## Matrizes
#' 
#' Como você deve lembrar das aulas de matemática,
#' 
#' No R, matrizes são objetos com duas dimensões, 
#' 
#' Um claro exemplo do uso de matrizes em Finanças
#' 
#' | Data       | ABEV3  | BBAS3 | BBDC3 |
#' |------------|--------|-------|-------|
#' | 2010-01-01 | 736.67 | 59.4  | 29.81 |
#' | 2010-01-04 | 764.14 | 59.8  | 30.82 |
#' | 2010-01-05 | 768.63 | 59.2  | 30.38 |
#' | 2010-01-06 | 776.47 | 59.28 | 30.20 |
#' 
#' A matriz anterior poderia ser criada da seguint
#' 
## ------------------------------------------------------------------------------------------------------------
# create matrix
data <- c(736.67, 764.14, 768.63, 776.47,
          59.4, 59.8, 59.2, 59.28,
          29.81, 30.82, 30.38, 30.20)

my_mat <- matrix(data, nrow = 4, ncol = 3)

# set names of cols and rows
colnames(my_mat) <- c('ABEV3', 'BBAS3', 'BBDC3')
rownames(my_mat) <- c('2010-01-01', '2010-01-04',
                      '2010-01-05', '2010-01-06')

print(my_mat)

#' 
#' Observe que, na construção da matriz, definimos
#' 
## ------------------------------------------------------------------------------------------------------------
colnames(my_mat)
rownames(my_mat)

#' 
#' No momento em que temos essa nossa matriz criad
#' 
## ----fig.align='center', echo=FALSE, out.width = '25%', include=identical(knitr:::pandoc_to(), 'epub3')------
knitr::include_graphics("00-text-resources/eqs/PortValue.png")

#' 

#' 
#' Onde _Ni_ é o número de ações compradas para at
#' 
## ------------------------------------------------------------------------------------------------------------
my.w <- as.matrix(c(200, 300, 100), nrow = 3)
my_port <- my_mat %*% my.w
print(my_port)

#' 
#' Nesse último exemplo, utilizamos o símbolo `%*%
#' 
#' Um ponto importante a ressaltar é que uma matri
#' 
## ------------------------------------------------------------------------------------------------------------
my_mat_char <- matrix(rep(c('a','b','c'), 3) ,
                      nrow = 3,
                      ncol = 3)
print(my_mat_char)

#' 
#' Essa flexibilidade dos objetos matriciais possi
#' 
#' 
#' ### Selecionando Valores de uma Matriz
#' 
#' Tal como no caso dos vetores atômicos, também é
#' 
#' [^1]: Para evitar confusão, vale salientar que,
#' 
## ------------------------------------------------------------------------------------------------------------
my_mat <- matrix(1:9, nrow = 3)
print(my_mat)
print(my_mat[1,2])

#' 
#' Para selecionar colunas ou linhas inteiras, bas
#' 
## ------------------------------------------------------------------------------------------------------------
print(my_mat[ , 2])
print(my_mat[1, ])

#' 
#' Observe que a indexação retorna um vetor atômic
#' 
## ------------------------------------------------------------------------------------------------------------
print(as.matrix(my_mat[ ,2]))
print(matrix(my_mat[1, ], nrow=1))

#' 
#' Pedaços da matriz também podem ser selecionados
#' 
## ------------------------------------------------------------------------------------------------------------
print(my_mat[2:3,1:2])

#' 
#' Por fim, o uso de testes lógicos para seleciona
#' 
## ------------------------------------------------------------------------------------------------------------
my_mat <- matrix(1:9, nrow = 3)
print(my_mat >5)
print(my_mat[my_mat >5])

#' 
#' 
#' ### Outras Funções Úteis
#' 
#' **as.matrix** - Transforma dados para a classe 
#' 
## ------------------------------------------------------------------------------------------------------------
my_mat <- as.matrix(1:5)
print(my_mat)

#' 
#' **t** - Retorna a transposta da matriz.
#' 
## ------------------------------------------------------------------------------------------------------------
my_mat <- matrix(seq(10,20, length.out = 6), nrow = 3)
print(my_mat)
print(t(my_mat))

#' 
#' **rbind** - Retorna a junção (cola) vertical de
#' 
## ------------------------------------------------------------------------------------------------------------
my_mat_1 <- matrix(1:5, nrow = 1)
print(my_mat_1)
my_mat_2 <- matrix(10:14, nrow = 1)
print(my_mat_2)

my.rbind.mat <- rbind(my_mat_1, my_mat_2)
print(my.rbind.mat)

#' 
#' **cbind** - Retorna a junção (cola) horizontal 
#' 
## ------------------------------------------------------------------------------------------------------------
my_mat_1 <- matrix(1:4, nrow = 2)
print(my_mat_1)
my_mat_2 <- matrix(10:13, nrow = 2)
print(my_mat_2)

my_cbind_mat <- cbind(my_mat_1, my_mat_2)
print(my_cbind_mat)

#' 
#' 
#' ## Exercícios {#exerc-classe-estrutura}
#' 
## ---- echo=FALSE, results='asis'-----------------------------------------------------------------------------
f_in <- fs::dir_ls('../02-EOCE-Rmd//Cap06-Objetos-Armazenamento/', 
                   type = 'file')

build_exercises(f_in, type_doc = my_engine)

#' 