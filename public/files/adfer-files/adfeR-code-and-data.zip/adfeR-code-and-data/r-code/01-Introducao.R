#' # Introdução {#introducao}
#' 

#' 
#' **Na era digital, informação é abundante e de f
#' 
#' Em particular, a área de Economia e Finanças of
#' 
#' Os métodos de processamento também avançaram em
#' 
#' É nesse ambiente que se destaca o papel do R, u
#' 
#' 
#' ## O que é o R
#' 
#' O R é uma linguagem de programação voltada para
#' 
#' Hoje, R é sinônimo de programação voltada à aná
#' 
#' E o mais importante: **o R é totalmente livre**
#' 
#' 
#' ## Por que Escolher o R
#' 
#' O processo de aprendizado de uma nova linguagem
#' 
#' Em primeiro lugar, **o R é uma plataforma madur
#' 
#' **Aprender a linguagem do R é fácil.** A experi
#' 
#' **A interface do R e RStudio torna o uso da fer
#' 
#' **Os pacotes do R permitem as mais diversas fun
#' 
#' **O R tem compatibilidade com diferentes lingua
#' 
#' **O R é totalmente gratuito!** O programa e tod
#' 
#' 
#' ## Usos do R
#' 
#' O R é uma linguagem de programação completa e q
#' 
#' * Substituir e melhorar tarefas intensivas e re
#' 
#' * Desenvolvimento de rotinas para administrar p
#' 
#' * Criação de ferramentas para controle, avaliaç
#' 
#' * Execução de diversas possibilidades de pesqui
#' 
#' * Criação e manutenção de _websites_ dinâmicos 
#' 
#' * Organização de um processo automatizado de cr
#' 
#' Além dos usos destacados anteriormente, o acess
#' 
#' 
#' ## Como Instalar o R {#instalacao}
#' 
#' O R é instalado no seu sistema operacional como
#' 

#' 
#' A próxima tela apresenta a escolha do espelho p
#' 
#' 

#' 
#' O próximo passo é selecionar o sistema operacio
#' 

#' 
#' Após clicar no link _Download R for Windows_, a
#' 
#' O último link, _RTools_, serve para instalar de
#' 

#' 
#' Após clicar no link _base_, a próxima tela most
#' 

#' 
#' Após baixar o arquivo, abra-o e siga os passos 
#' 
## A cada quatro meses uma nova versão do R é lançada, corrigindo _bugs_ e implementando novas soluções. Temos dois tipos principais de versões, _major_ e _minor_. Por exemplo, hoje, 05/02/2021, a última versão do R é 4.0.3. O primeiro dígito ("4") indica a versão _major_ e todos os demais são do tipo _minor_. Geralmente, as  mudanças _minor_ são bem específicas e, possivelmente, terão pouco impacto no seu trabalho.

## 
## Porém, ao contrário de mudanças _minor, mudanças do tipo _major_ refletem totalmente no ecossistema de pacotes do R. Toda vez que instalar uma nova versão _major_ do R, terás que reinstalar todos os pacotes utilizados. O problema é que não é incomum problemas de incompatibilidade de pacotes com a nova versão.

## 
## Minha dica é: toda vez que uma nova versão _major_ do R sair, espere alguns meses antes de instalar na sua máquina. Assim, o autores dos pacotes terão mais tempo para atualizar os seus códigos, minimizando a possibilidade de problemas de compatibilidade.

#' 
#' ## Instalando o RStudio
#' 
#' A instalação do R inclui a sua própria interfac
#' 
#' A instalação do RStudio é mais simples do que a
#' 
#' Destaco que o uso do RStudio não é essencial pa
#' 
#' 
#' ## Recursos na Internet
#' 
#' **A comunidade R é viva e envolvente**. Na inte
#' 
#' Recentemente, uma lista de blogs locais sobre o
#' 
#' Aprender e usar R pode ser uma experiência soci
#' 
#' 
#' ## Organização e Material do Livro
#' 
#' Este livro tem uma abordagem prática no uso do 
#' 
#' Sugiro também o uso da versão [web do livro](`r
#' 
#' Aprender a programar em uma nova linguagem é co
#' 
#' No decorrer da obra, toda demonstração de códig
#' 
## ------------------------------------------------------------------------------------------------------------
# create a list
L <- list(var1 = 'abc', var2 = 1:5)

# print to prompt
print(L)

#' 
#' No caso anterior, os textos `L <- list(var1 = '
#' 
#' Note que faço uso da língua inglesa no código, 
#' 
#' O código também pode ser espacialmente organiza
#' 
## ------------------------------------------------------------------------------------------------------------
# create a list
L <- list(var1 = 'abc',
          var2 = 1:5)

# print to prompt
print(L)

#' 
#' O código também segue uma estrutura bem definid
#' 
#' 
#' ## Exercícios
#' 
## ----exerc, echo=FALSE, results='asis'-----------------------------------------------------------------------
f_in <- list.files('../02-EOCE-Rmd//Cap01-Introdução/', 
                   full.names = TRUE)

build_exercises(f_in, type_doc = my_engine)

#' 