#' ---
#' title: "Análise de Dados Financeiros e Econômic
#' author: "Marcelo S. Perlin (marcelo.perlin@ufrg
#' date: "`r '2021-03-01'`"
#' site: bookdown::bookdown_site
#' cover-image: "00-text-resources/cover/CAPAdigit
#' output: bookdown::pdf_book
#' documentclass: book
#' bibliography: ["00-text-resources/bib-files/boo
#'                "00-text-resources/bib-files/pac
#'                "00-text-resources/bib-files/pro
#' biblio-style: apalike
#' fontsize: 11pt
#' geometry: margin=1.5in, textwidth=6in, textheig
#' link-citations: yes
#' description: "Análise de Dados Financeiros e Ec
#' favicon: "00-text-resources/figs/Favicon/favico
#' ---
#' 

#' 
#' 
## ----test-main, include=identical(my.engine , 'html'), results='asis'----------------------------------------
my_str <- paste(readLines('_BemVindo.Rmd'), collapse = '\n')

my_str <- stringr::str_replace_all(my_str, '`r book_title`', book_title)
my_str <- stringr::str_replace_all(my_str, '`r link_amazon_ebook`', link_amazon_ebook)
my_str <- stringr::str_replace_all(my_str, '`r link_amazon_print`', link_amazon_print)
my_str <- stringr::str_replace_all(my_str, '`r blog_site`', blog_site)

cat(my_str)
