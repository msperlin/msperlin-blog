#' # Importação de Dados via Pacotes {#importacao-
#' 

#' 
#' Uma das grandes vantagens de se utilizar o R é 
#' 
#' Neste capítulo vou descrever e dar exemplos de 
#' 
#' `GetQuandlData` [@R-GetQuandlData]
#' :  Importa dados econômicos e financeiros do va
#' 
#' `BatchGetSymbols` [@R-BatchGetSymbols]
#' : Importa dados de preços diários de ações e ín
#' 
#' `GetTDData` [@R-GetTDData]
#' : Importa dados de títulos de dívida pública do
#' 
#' `GetBCBData` [@R-GetBCBData]
#' : Importa dados do grande repositório de séries
#' 
#' `GetDFPData2` [@R-GetDFPData2]
#' : Importa dados do sistema DFP -- Demonstrativo
#' 
#' `GetFREData` [@R-GetFREData]
#' : Importa dados do sistema FRE -- Formulário de
#' 
#' 
#' ## Pacote `GetQuandlData` {#quandl}
#' 
#' _Quandl_ é um repositório de dados abrangente, 
#' 
#' Pacote `Quandl` [@R-Quandl] é a extensão oficia
#' 
#' A **primeira e obrigatória** etapa no uso de `G
#' 

#' 
## ---- eval = FALSE-------------------------------------------------------------------------------------------
## # set FAKE api key to quandl
## my_api_key <- 'Asv8Ac7zuZzJSCGxynfG'

#' 
#' Essa chave API é exclusiva para cada usuário e 
#' 
#' Como exemplo, usaremos dados do  [preço do ouro
#' 
#' Agora, com a chave API e o identificador da tab
#' 
## ------------------------------------------------------------------------------------------------------------
library(GetQuandlData)
library(tidyverse)

# set symbol and dates
my_symbol <- c('GOLD' = 'LBMA/GOLD')
first_date <- '1980-01-01'
last_date <- '2021-01-01'

# get data!
df_quandl <- get_Quandl_series(id_in = my_symbol,
                               api_key = my_api_key, 
                               first_date = first_date,
                               last_date = last_date)

# check it
glimpse(df_quandl)

#' 
#' Observe como definimos o nome da série temporal
#' 
#' Para verificar os dados, vamos criar um gráfico
#' 
## ---- echo=FALSE---------------------------------------------------------------------------------------------
library(ggplot2)

# plot prices with ggplot2
p <- ggplot(df_quandl, aes(x = ref_date, y = as.numeric(`USD (AM)`))) + 
  geom_line() + 
  labs(title = 'Gold Price: London Fixing - USD',
       y = 'Prices of one ounce of Gold', 
       x = '',
       subtitle = paste0(first_date, ' to ', last_date),
       caption = 'Data from Quandl -- London Bullion Market Association') + 
  theme_bw()

# print it
print(p)

#' 
#' De modo geral, os preços do ouro permaneceram r
#' 
## ------------------------------------------------------------------------------------------------------------
# sort the rows
df_quandl <- df_quandl %>%
  mutate(USD = as.numeric(`USD (AM)`)) %>%
  arrange(ref_date)

total_ret <- last(df_quandl$USD)/first(df_quandl$USD) - 1
total_years <- as.numeric(max(df_quandl$ref_date) - 
                            min(df_quandl$ref_date) )/365

comp_ret_per_year <- (1 + total_ret)^(1/total_years) - 1

print(comp_ret_per_year)

#' 
## ---- include=FALSE------------------------------------------------------------------------------------------
# set symbol and dates
my_symbol <- c('US Inflation' = 'RATEINF/INFLATION_USA')
first_date <- as.Date('1980-01-01')
last_date <- as.Date('2019-01-01')

# get data!
df_inflation <- get_Quandl_series(id_in = my_symbol,
                                  api_key = my_api_key,
                                  first_date = first_date,
                                  last_date = last_date)

# check it
df_inflation <- df_inflation %>%
  arrange(ref_date) %>%
  mutate(infl_by_month = (1+value/100)^(1/12) - 1,
         idx_infl = cumprod(1+infl_by_month))

total_infl_ret <- last(df_inflation$idx_infl)/first(df_inflation$idx_infl) - 1
total_infl_years <- as.numeric(max(df_inflation$ref_date) - min(df_inflation$ref_date) )/365

inflation_comp_ret <- (1 + total_infl_ret)^(1/total_infl_years) - 1

#' 
#' Encontramos o resultado de que os preços do our
#' 
#' 
#' ### Importando Múltiplas Séries 
#' 
#' Ao solicitar várias séries temporais do Quandl,
#' 
## ------------------------------------------------------------------------------------------------------------
library(GetQuandlData)
library(tidyverse)

# databse to get info
db_id <- 'RATEINF'

# get info 
df_db <- get_database_info(db_id, my_api_key)

glimpse(df_db)

#' 
#' Coluna `name` contém a descrição das tabelas co
#' 
## ------------------------------------------------------------------------------------------------------------
print(unique(df_db$name))

#' 
#' O que estamos buscando são as séries `'Inflatio
#' 
## ------------------------------------------------------------------------------------------------------------
selected_series <- c('Inflation YOY - USA',
                     'Inflation YOY - Canada',
                     'Inflation YOY - Euro Area',
                     'Inflation YOY - Australia')

# filter selected countries
idx <- df_db$name %in% selected_series
df_db <- df_db[idx, ]

#' 
#' Agora importamos as séries usando `get_Quandl_s
#' 
## ------------------------------------------------------------------------------------------------------------
my_id <- df_db$quandl_code
names(my_id) <- df_db$name
first_date <- '2010-01-01'
last_date <- '2021-01-01'

df_inflation <- get_Quandl_series(id_in = my_id, 
                                  api_key = my_api_key,
                                  first_date = first_date,
                                  last_date = last_date)

glimpse(df_inflation)

#' 
#' Por fim, construimos um gráfico para vizualizar
#' 
## ---- echo=FALSE---------------------------------------------------------------------------------------------
p <- ggplot(df_inflation, aes(x = ref_date, y = value/100)) + 
  geom_col() + 
  labs(y = 'Inflation YOY (%)', 
       x = '',
       title = 'Inflation in the World',
       subtitle = paste0(first_date, ' to ', last_date),
       caption = 'Data from Quandl') + 
  scale_y_continuous(labels = scales::percent) + 
  facet_wrap(~series_name) + 
  theme_bw()

print(p)

#' 
#' Como podemos ver, com algumas linhas de código 
#' 
#' 
#' ## Pacote `BatchGetSymbols`
#' 
#' \index{BatchGetSymbols}
#' 
#' Pacote `BatchGetSymbols` faz a comunicação do R
#' 
#' Os diferenciais do `BatchGetSymbols` são:
#' 
#' **Limpeza e organização**: todos os dados finan
#' 
#' **Controle de erros de importação**: todos erro
#' 
#' **Comparação de datas a um _benchmark_**: os da
#' 
#' **Uso de sistema de cache**: no momento de aces
#' 
## Desde versão 2.6 (2020-11-22) de `BatchGetSymbols` a pasta _default_ de cache do `BatchGetSymbols` se localiza no diretório temporário da sessão do R. Assim, o cache é persistente apenas para a sessão do usuário. Esta mudança foi motivada por quebras estruturais nos dados do _Yahoo Finance_, onde os dados passados registrados em cache não mais estavam corretos devido a eventos coporativos. O usuário, porém, pode trocar a pasta de cache usando a entrada `cache.folder`.

#' 
#' **Acesso a _tickers_ em índices de mercado**: O
#' 
#' **Processamento paralelo**: Caso o usuário esti
#' 
#' **Flexibilidade de formato**: O pacote também o
#' 
#' Como exemplo de uso, vamos baixar dados finance
#' 
#' Na chamada da função `BatchGetSymbols`, utiliza
#' 
#' \index{BatchGetSymbols!BatchGetSymbols}
#' \index{base!Sys.Date}
#' 
## ---- message=FALSE------------------------------------------------------------------------------------------
library(BatchGetSymbols)
library(dplyr)

# set tickers
my_tickers <- c('PETR4.SA', 'CIEL3.SA',
                'GGBR4.SA', 'GOAU4.SA')

# set dates and other inputs
first_date <- Sys.Date()-360
last_date <- Sys.Date()
thresh_bad_data <- 0.95   # sets percent threshold for bad data
bench_ticker <- '^BVSP'   # set benchmark as ibovespa

l_out <- BatchGetSymbols(tickers = my_tickers,
                         first.date = first_date,
                         last.date = last_date,
                         bench.ticker = bench_ticker,
                         thresh.bad.data = thresh_bad_data)

#' 
#' A saída de `BatchGetSymbols` é um objeto do tip
#' 
## Note que as entradas da função `BatchGetSymbols::BatchGetSymbols` usam o "." em seus nomes, tal como `thresh.bad.data`, e `bench.ticker`, enquanto o livro está escrito usando o traço baixo (`_`), tal como `thresh_bad_data`, e `bench_ticker`. Esta diferença pode resultar em problemas se, na falta de atenção, o usuário trocar um pelo outro. Como regra, procure dar prioridade para o uso de traço baixo nos nomes de objetos. Infelizmente algumas funções escritas no passado acabaram ficando com a estrutura antiga e, para não prejudicar os usuários, os nomes das entradas foram mantidos.

#' 
#' Voltando ao nosso exemplo, função `BatchGetSymb
#' 
## ------------------------------------------------------------------------------------------------------------
# print result of download process
print(l_out$df.control)

#' 
#' Objeto `df.control` mostra que todos _tickers_ 
#' 
#' Quanto aos dados financeiros, esses estão conti
#' 
## ------------------------------------------------------------------------------------------------------------
# print df_tickers
glimpse(l_out$df.tickers)

#' 
#' Como esperado, a informação sobre preços, retor
#' 
#' 
#' ### Baixando Dados da Composição do Ibovespa
#' 
#' Outra função útil do pacote é `BatchGetSymbols:
#' 
## ---- eval=FALSE---------------------------------------------------------------------------------------------
## library(BatchGetSymbols)
## 
## # set tickers
## df_ibov <- GetIbovStocks()
## my_tickers <- paste0(df_ibov$tickers,'.SA')
## 
## 
## # set dates and other inputs
## first_date <- Sys.Date()-30
## last_date <- Sys.Date()
## thresh_bad_data <- 0.95   # sets percent threshold for bad data
## bench_ticker <- '^BVSP'   # set benchmark as ibovespa
## cache_folder <- 'data/BGS_Cache' # set folder for cache
## 
## 
## l_out <- BatchGetSymbols(tickers = my_tickers,
##                          first.date = first_date,
##                          last.date = last_date,
##                          bench.ticker = bench_ticker,
##                          thresh.bad.data = thresh_bad_data,
##                          cache.folder = cache_folder)
## 

#' 
#' Note que utilizamos a função `paste0` para adic
#' 
## Saiba que **os preços do Yahoo Finance não são ajustados a dividendos**. O ajuste realizado pelo sistema é apenas para desdobramentos das ações. Isso significa que, ao olhar séries de preços em um longo período, existe um viés de retorno para baixo. Ao comparar com outro software que faça o ajustamento dos preços por dividendos, verás uma grande diferença na rentabilidade total das ações. Como regra, em uma pesquisa formal, **evite usar dados de ações individuais no Yahoo Finance para períodos longos**. A excessão é para índices financeiros, tal como o Ibovespa, onde os dados do Yahoo Finance são bastante confiáveis uma vez que índices não sofrem os mesmos ajustamentos que ações individuais.

#' 
#' 
#' ## Pacote `GetTDData`
#' 
#' Arquivos com informações sobre preços e retorno
#' 
#' Pacote `GetTDData` importa os dados das planilh
#' 
#' \index{GetTDData} \index{GetTDData!download.TD.
#' 
## ---- results='hide'-----------------------------------------------------------------------------------------
library(GetTDData)

asset_codes <- 'LTN'   # Identifier of assets
maturity <- '010121'  # Maturity date as string (ddmmyy)

# download
my_flag <- download.TD.data(asset.codes = asset_codes)

# read files
df_TD <- read.TD.files(asset.codes = asset_codes,
                       maturity = maturity)

#' 
#' Vamos checar o conteúdo do dataframe:
#' 
## ------------------------------------------------------------------------------------------------------------
# check content
glimpse(df_TD)

#' 
#' Temos informações sobre data de referência (`re
#' 
## ---- echo = FALSE-------------------------------------------------------------------------------------------
library(ggplot2)

p <- ggplot(data = df_TD, aes(x = as.Date(ref.date), 
                              y = price.bid, 
                              color = asset.code)) + 
  geom_line(size = 1) + 
  labs(title = '', x = 'Dates') + 
  theme_bw()

print(p)

#' 
#' Como esperado de um título de dívida pré-fixado
#' 
## ---- echo=FALSE---------------------------------------------------------------------------------------------
p <- ggplot(data = df_TD, 
            aes(x = as.Date(ref.date), 
                y = yield.bid, 
                color = asset.code)) + 
  geom_line(size = 1) + 
  labs(title = '', x = 'Dates' ) + 
  theme_bw()

print(p)

#' 
#' Os retornos do título tiveram forte queda ao lo
#' 
#' As funções do `GetTDData` também funcionam com 
#' 
## ---- results='hide'-----------------------------------------------------------------------------------------
library(GetTDData)

asset_codes <- 'LTN'   # Name of asset
maturity <- NULL      # = NULL, downloads all maturities

# download data
my_flag <- download.TD.data(asset.codes = asset_codes,
                            do.clean.up = F)

# reads data
df_TD <- read.TD.files(asset.codes = asset_codes,
                       maturity = maturity)

# remove data prior to 2010
df_TD <- dplyr::filter(df_TD,
                       ref.date >= as.Date('2010-01-01'))

#' 
#' Após a importação das informações, plotamos os 
#' 
## ---- echo=FALSE---------------------------------------------------------------------------------------------
# plot data (prices)
p <- ggplot(data = df_TD, 
            aes(x = as.Date(ref.date), 
                y = price.bid, 
                color = asset.code)) + 
  geom_line() + 
  labs(title = '', x = 'Dates', y = 'Prices' ) + 
  theme_bw()

print(p)

#' 
#' Note como todos contratos do tipo LTN terminam 
#' 
#' Outra funcionalidade do pacote `GetTDData` é o 
#' 
#' \index{GetTDData!get.yield.curve}
#' 
## ------------------------------------------------------------------------------------------------------------
library(GetTDData)

# get yield curve
df_yield <- get.yield.curve()

# check result
dplyr::glimpse(df_yield)

#' 
#' Os dados incluem a curva de juros nominal, juro
#' 
## ---- echo=FALSE---------------------------------------------------------------------------------------------
library(ggplot2)

p <- ggplot(df_yield, aes(x=ref.date, y = value) ) +
  geom_line(size=1) + geom_point() + facet_grid(~type, scales = 'free') +
  labs(title = paste0('The current Brazilian Yield Curve - ', df_yield$current.date[1])) + 
  theme_bw()

print(p)

#' 
#' A curva de juros é uma ferramente utilizada no 
#' 
#' 
#' ## Pacote `GetBCBData`
#' 
#' O Banco Central Brasileiro (BCB) disponibiliza 
#' 
#' Como um exemplo, vamos usar o pacote para estud
#' 
#' No código, basta indicar a série de interesse e
#' 
## ------------------------------------------------------------------------------------------------------------
library(GetBCBData)
library(dplyr)

# set ids and dates
id_series <- c(perc_default = 21082)
first_date = '2010-01-01'

# get series from bcb
df_cred <- gbcbd_get_series(id = id_series,
                            first.date = first_date,
                            last.date = Sys.Date(), 
                            use.memoise = FALSE)

# check it
glimpse(df_cred)

#' 
#' Note que indicamos o nome da coluna na própria 
#' 
## ---- echo=FALSE---------------------------------------------------------------------------------------------
library(ggplot2)

p <- ggplot(df_cred, aes(x=ref.date, y = value)) +
  geom_line() + 
  labs(y = 'Percentage of credit default',
       x = '',
       title = 'Credit Default in Brazil',
       caption = 'Source: SGS - BCB (by GetBCBData)') + 
  theme_bw()

print(p)

#' 
#' Como podemos ver, a percentagem de inadimplênci
#' 
## ------------------------------------------------------------------------------------------------------------
# set ids
id.series <- c(credit_default_people = 21083,
               credit_default_companies = 21084)
first.date = '2010-01-01'

# get series from bcb
df_cred <- gbcbd_get_series(id = id.series,
                            first.date = first.date,
                            last.date = Sys.Date(), 
                            use.memoise = FALSE)

# check output
glimpse(df_cred)

#' 
#' A diferença na saída do código anterior é que a
#' 
## ---- echo=FALSE---------------------------------------------------------------------------------------------
p <- ggplot(df_cred, aes(x =ref.date, y = value, linetype = series.name)) +
  geom_line() + labs(y = 'Percentage of Credit Default',
                     x = '') + 
  labs(y = 'Percentage of credit default',
       x = '',
       title = 'Credit Default in Brazil',
       caption = 'Source: SGS - BCB (by GetBCBData)') + 
  theme_bw()

print(p)

#' 
#' Como podemos ver, a inadimplência de crédito pa
#' 
## O sistema BCB-SGS é local obrigatório para qualquer economista sério. A quantidade e variedade de dados é imensa. Podes usar os dados do sistema para automatizar qualquer tipo de relatório econômico.

#' 
#' ## Pacote `GetDFPData2`
#' 
#' Pacote `GetDFPData2` [@R-GetDFPData2] é uma evo
#' 
## Uma versão web de `GetDFPData2` foi desenvolvida e publicada na internet como um aplicativo _shiny_ em [http://www.msperlin.com/shiny/GetDFPData/](http://www.msperlin.com/shiny/GetDFPData/). Esse fornece uma interface gráfica direta e simples para as principais funcionalidade do pacote. Usuários podem selecionar as empresas disponíveis, o intervalo de datas e baixar os dados como uma planilha do Excel ou um arquivo compactado com vários arquivos _csv_.

## 
## Saiba também que dados históricos completos e atualizados a partir de 2010 do DFP e ITR estão disponibilizados na seção [Data](https://www.msperlin.com/blog/data/) do meu site pessoal.

#' 
#' O ponto de partida no uso de `GetDFPData2` é ba
#' 
## ------------------------------------------------------------------------------------------------------------
library(GetDFPData2)

# get info for companies in B3
df_info <- get_info_companies()

# check it
names(df_info)

#' 

#' 
#' Essa tabela disponibiliza os identificadores nu
#' 
#' Toda empresa no banco de dados é identificada p
#' 
## ---- message=FALSE------------------------------------------------------------------------------------------
df_search <- search_company('grendene')

print(df_search)

#' 
#' Vemos que existe um registro para a Grendene: "
#' 
#' Com o identificador da empresa disponível, usam
#' 
#' \index{GetDFPData2!get\_dfp\_data}
#' 
## ---- warning=FALSE, message=FALSE---------------------------------------------------------------------------
library(GetDFPData2)
library(dplyr)

# set options
id_companies <- 19615
first_year <- 2017
last_year  <- 2018

# download data
l_dfp <- get_dfp_data(companies_cvm_codes = id_companies,
                      type_docs = '*', # get all docs  
                      type_format = 'con', # consolidated
                      first_year = first_year,
                      last_year = last_year)

#' 
#' As mensagens de `GetDFPData2::get_dfp_data` rel
#' 
#' Explicando as demais entradas da função `GetDFP
#' 
#' companies_cvm_codes
#' : Código numérico das empresas (encontrado via 
#' 
#' type_docs
#' : Símbolo do tipo de documento financeiro a ser
#' 
#' type_format	
#' : Tipo de formato dos documentos: consolidado (
#' 
#' first_year
#' : Primeiro ano para os dados
#' 
#' last_year
#' : Último ano para os dados
#' 
#' O objeto resultante de `get_dfp_data` é uma `li
#' 
## ------------------------------------------------------------------------------------------------------------
stringr::str_sub(names(l_dfp), 1, 40)

#' 
#' Como podemos ver, os dados retornados são vasto
#' 
## ------------------------------------------------------------------------------------------------------------
# save assets in df
fr_assets <- l_dfp$`DF Consolidado - Balanço Patrimonial Ativo`

# check it
dplyr::glimpse(fr_assets)

#' 
#' 
#' A exportação dos dados para o Excel também é fá
#' 
## ---- message=FALSE------------------------------------------------------------------------------------------
temp_xlsx <- tempfile(fileext = '.xlsx')

export_xlsx(l_dfp = l_dfp, f_xlsx = temp_xlsx)

#' 
#' O arquivo Excel resultante conterá cada tabela 
#' 
## ------------------------------------------------------------------------------------------------------------
readxl::excel_sheets(temp_xlsx)

#' 
#' 
#' ## Pacote `GetFREData`
#' 
#' O pacote `GetFREData` importa dados do sistema 
#' 
#' A estrutura de uso e a saída das funções de `Ge
#' 
## ---- message=FALSE------------------------------------------------------------------------------------------
library(GetFREData)

# set options
id_companies <- 23264
first_year <- 2017
last_year  <- 2018

# download data
l_fre <- get_fre_data(companies_cvm_codes = id_companies,
                      first_year = first_year,
                      last_year = last_year)

#' 
#' Note que o tempo de execução de `get_fre_data` 
#' 
## ------------------------------------------------------------------------------------------------------------
names(l_fre)

#' 
#' Por exemplo, vamos verificar conteúdo da tabela
#' 
## ------------------------------------------------------------------------------------------------------------
glimpse(l_fre$df_board_composition)

#' 
#' Como podemos ver, para um pesquisador de finanç
#' 
## Note que a importação dos dados do FRE inclui uma versão dos arquivos. Toda vez que uma empresa modifica as informações oficiais no sistema da B3, uma nova versão do FRE é criada. Devido a isso, é bastante comum que os dados de um ano para uma empresa possua diferentes versões. Para resolver este problema, o código do `GetFREData`, por _default_, importa a versão mais antiga para cada ano. Caso o usuário queira mudar, basta utilizar a entrada `fre_to_read`.

#' 
#' 
#' ## Outros Pacotes
#' 
#' Nas seções anteriores destacamos os principais 
#' 
#' 
#' ### Pacotes de Acesso Gratuito
#' 
#' `BETS` [@R-BETS]
#' : Pacote construído e mantido pela equipe da [F
#' 
#' `simfinR` [@R-simfinR]
#' : Pacote para acesso ao projeto [simfin](https:
#' 
#' `TFX` [@R-TFX]
#' : Permite acesso aos dados do mercado de câmbio
#' 
#' 
#' ### Pacotes Comerciais
#' 
#' `Rblpapi` [@R-Rblpapi]
#' : Permite acesso aos dados da [Bloomberg](https
#' 
#' `IBrokers` [@R-IBrokers]
#' : API para o acesso aos dados da [Interactive B
#' 
#' No CRAN você encontrará muitos outros. A interf
#' 
#' 
#' ## Acessando Dados de Páginas na Internet (_Web
#' 
#' Os pacotes destacados anteriormente são muito ú
#' 
#' 
#' ### Raspando Dados do Wikipedia
#' 
#' Em seu site, a Wikipedia oferece uma [seção](ht
#' 
## ----SP500-wikipedia, echo = FALSE, out.width = '75%', fig.cap = 'Imagem da página do Wikipedia'-------------
knitr::include_graphics('00-text-resources/figs/SP500-Wikipedia.png')

#' 
#' As informações desta página são constantemente 
#' 
#' A primeira etapa do processo de raspagem de dad
#' 
## ----SP500-Wikipedia-webscraping, echo = FALSE, out.width = '75%', fig.cap = 'Encontrando o xpath da tabela'----
knitr::include_graphics('00-text-resources/figs/SP500-Wikipedia_webscraping.png')

#' 
#' Aqui, o texto copiado é:
#' 
## ---- eval=FALSE---------------------------------------------------------------------------------------------
## '//*[@id="mw-content-text"]/table[1]/thead/tr/th[2]'

#' 
#' Este é o endereço do cabeçalho da tabela. Para 
#' 
#' Agora que temos a localização do que queremos, 
#' 
## ---- tidy=FALSE, cache=TRUE---------------------------------------------------------------------------------
library(rvest)

# set url and xpath
my_url <- 'https://en.wikipedia.org/wiki/List_of_S%26P_500_companies'
my_xpath <- '//*[@id="mw-content-text"]/div/table[1]'

# get nodes from html
out_nodes <- html_nodes(read_html(my_url),
                        xpath = my_xpath)

# get table from nodes (each element in 
# list is a table)
df_SP500_comp <- html_table(out_nodes)

# isolate it 
df_SP500_comp <- df_SP500_comp[[1]]

# change column names (remove space)
names(df_SP500_comp) <- make.names(names(df_SP500_comp))

# print it
glimpse(df_SP500_comp)

#' 
#' O objeto `df_SP500_comp` contém um espelho dos 
#' 
#' 
#' ## Exercícios {#exerc-importacao-pacotes}
#' 
## ---- echo=FALSE, results='asis'-----------------------------------------------------------------------------
f_in <- fs::dir_ls('../02-EOCE-Rmd//Cap05-Import-Internet/', 
                   type = 'file')

build_exercises(f_in, type_doc = my_engine)

#' 