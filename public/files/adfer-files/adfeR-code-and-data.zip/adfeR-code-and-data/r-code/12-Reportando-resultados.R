#' # Reportando Resultados e Criando Relatórios {#
#' 

#' 
#' Nos capítulos anteriores aprendemos a utilizar 
#' 
#' A qualidade refere-se a atratividade visual do 
#' 
#' A facilidade de alteração de tabelas relaciona-
#' 
#' Caso o trabalho de montagem de tabelas for dema
#' 
#' Existem duas estratégias para reportar resultad
#' 
#' 
#' ## Reportando Tabelas
#' 
#' Tabelas simples, tal como estatísticas que desc
#' 
## ---- message=FALSE------------------------------------------------------------------------------------------
library(dplyr)
library(BatchGetSymbols)
library(DistributionUtils) # Kurtosis() and Assimetry()

# set number of rows in table
my_tickers <- c('PETR4.SA', 'GGBR4.SA',
                'USIM5.SA', 'MDIA3.SA')

first_date = '2015-01-01'
last_date = '2018-01-01'

df_stocks <- BatchGetSymbols(tickers = my_tickers,
                             first.date = first_date,
                             last.date = last_date,
                             bench.ticker = '^BVSP')[[2]]

# create descriptive table
my_desc_table <- df_stocks %>%
  group_by(Ticker = ticker ) %>%
  summarise('Mean Ret' = mean(ret.adjusted.prices, na.rm = TRUE),
            'StDev Ret' = sd(ret.adjusted.prices, na.rm = TRUE),
            'Max Ret' = max(ret.adjusted.prices, na.rm = TRUE),
            'Min Ret' = min(ret.adjusted.prices, na.rm = TRUE),
            'Assimetry' = skewness(ret.adjusted.prices, na.rm = TRUE),
            'Kurtosis' = kurtosis(ret.adjusted.prices, na.rm = TRUE))

print(my_desc_table)

#' 
#' Na criação do `dataframe`, observe como definim
#' 
## ---- message=FALSE------------------------------------------------------------------------------------------
library(xtable)

# set xtable object
my_xtable <- xtable(x = my_desc_table,
                    label = 'tab:DescRetStats',
                    caption = 'Descriptive Statistics for Returns',
                    digits = 4)

# check if folder exists
if (!dir.exists('tabs')) {
	dir.create('tabs')
}

# print output to _LaTeX_ file
my_f_tex <- 'tabs/MyTable.tex'

# save it
print(my_xtable,
      include.rownames = FALSE,
      file = my_f_tex,
      type='latex')

#' 
#' Na função `xtable`, usamos apenas entradas `lab
#' 

#' 
#' Quanto à exportação de tabelas para arquivos do
#' 
## ------------------------------------------------------------------------------------------------------------
# set html file for output
my_f_html <- '00-text-resources/tabs/MyTable.html'

# write it!
print(x = my_xtable,
      file = my_f_html,
      type = 'html',
      include.rownames = FALSE )

#' 
#' Uma vez que o arquivo está disponível, podemos 
#' 

#' 
#' Indo além, se você lida com muitas figuras e ta
#' 
#' 
#' ## Reportando Modelos {#reporting-models}
#' 
#' Um tipo especial de tabela refere-se a estimaçã
#' 
#' Como exemplo, vamos usar o pacote `texreg` para
#' 
## ---- tidy=FALSE, message=FALSE------------------------------------------------------------------------------
library(texreg)
library(dplyr)

# get Ibov data
my_tickers <- c('^BVSP')

first_date = '2015-01-01'
last_date = '2018-01-01'

df_ibov <- BatchGetSymbols(tickers = my_tickers,
                             first.date = first_date,
                             last.date = last_date,
                             bench.ticker = '^BVSP')[[2]]

# set ibov ret column
idx <- match(df_stocks$ref.date, df_ibov$ref.date)
df_stocks$ret.ibov <- df_ibov$ret.adjusted.prices[idx]

# estimate betas
beta_tab <- df_stocks %>%
  group_by(ticker) %>%
  do(beta_model = lm(data=., ret.adjusted.prices ~ ret.ibov))

# report result
est_table <- screenreg(l = beta_tab$beta_model,
                       custom.model.names = beta_tab$ticker,
                       custom.coef.names = c('Alpha', 'Beta'),
                       digits = 2)

# print it
print(est_table)

#' 
#' No código anterior, coluna `beta_model` de `bet
#' 
#' O pacote `texreg` também oferece diversas outra
#' 
#' A seguir apresentamos um exemplo de uso de `tex
#' 
## ---- tidy=FALSE, message=FALSE------------------------------------------------------------------------------
# report result
est_table <- texreg(l = beta_tab$beta_model,
                    file = '00-text-resources/tabs/Example_texreg.tex',
                    custom.model.names = beta_tab$ticker,
                    custom.coef.names = c('Alpha', 'Beta'),
                    digits = 2)

#' 
#' O resultado em um arquivo _LaTeX_ compilado par
#' 

#' 
#' 
#' ## Criando Relatórios com o _RMarkdown_
#' 
#' A estratégia mais comum para a produção de rela
#' 
#' A estrutura de texto do _Rmarkdown_ baseia-se n
#' 
#' Vamos explicar o funcionamento do `Rmarkdown` c
#' 
#' Indo em frente, vamos editar o título do relató
#' 

#' 
#' As próximas escolhas referem-se ao tipo de arqu
#' 
#' Após dar o _OK_, um arquivo aparecerá na tela d
#' 

#' 
#' O cabeçalho do documento é identificado pelo us
#' 
#' Avançando, o próximo pedaço é identificado na F
#' 
#' O item `include=FALSE` é uma opção particular a
#' 

#' 
#' Para o primeiro pedaço de código, a linha `knit
#' 
## Um ponto importante na compilação de arquivos RMarkdown é que o o diretório de trabalho sempre será o local do arquivo de origem. Portanto, ao contrário do desenvolvimento de _scripts_ do R, **não é necessário trocar de diretório** no código _.Rmd_ com a função `setwd`.

#' 
#' Seguindo em frente, o texto `## R Markdown` na 
#' 

#' 
#' A segunda parte em \@ref(fig:rmarkdown-text) é 
#' 
#' Um ponto importante aqui é o uso de código em t
#' 
#' > "O valor do test T foi X."
#' 
#' onde _X*_ é o resultado da estatística, calcula
#' 
#' 

#' 
#' O R irá avaliar o valor de `result.ttest` no mo
#' 
#' A última parte em \@ref(fig:rmarkdown-text) apr
#' 
#'  Na Figura \@ref(fig:rmarkdown-figures) apresen
#' 

#' 
#' Agora que já entendemos os componentes que form
#' 

#' 
#' Vale destacar que os procedimentos de exportaçã
#' 
#' Essa seção mostrou uma pequena porção do univer
#' 
#' 
#' ## Exercícios {#exerc-reportando-resultados}
#' 
## ---- echo=FALSE, results='asis'-----------------------------------------------------------------------------
f_in <- fs::dir_ls('../02-EOCE-Rmd//Cap12-Reportando/', 
                   type = 'file')

build_exercises(f_in, type_doc = my_engine)
