#' # Otimização de Código {#otimizacao}
#' 

#' 
#' Neste capítulo estudaremos como ser mais eficie
#' 
#' 
#' ## Otimizando Código em R
#' 
#' O primeiro tópico que você deve considerar ao p
#' 
#' DRY (não se repita)
#' : Sempre que você se pegar escrevendo linhas de
#' 
#' KISS  (_keep it simple and smart_)
#' : Quanto mais simples e direto for o seu código
#' 
#' Estruture seu diretório de trabalho
#' : Organize todos os elementos dos scripts em pa
#' 
#' Comentários são seus amigos
#' : Mesmo se és o único usuário de código, manten
#' 
#' Mantenha uma notação clara e consistente
#' : A notação de código é o toque pessoal que voc
#' 
#' Nomes de arquivos e caminhos
#' : Nomes e caminhos de arquivos devem ajudar a i
#' 
## ------------------------------------------------------------------------------------------------------------
# GOOD STYLE
my_f <- '01_Run_Research.R'
my_f <- '02_Import_and_Clean_Data.R'
my_f <- 'data/gdp.rds'
my_f <- 'fcts/report_functions.R'

# BAD STYLE
my_f <- 'functions.R'
my_f <- 'data/script.R'
my_f <- 'html/script_ver_03.R'
my_f <- 'script_ver_05_with_clean_data.R'

#' 
#' Seções de código
#' : Use três traços seguidos no script (`---`) pa
#' 
## ------------------------------------------------------------------------------------------------------------
# Import data ----

# Clean data ----

# Estimate models ----

#' 
#' Nomes de variáveis e funções 
#' : use estas diretrizes para nomear objetos, inc
#' 
#' - Dê preferência a caracteres minúsculos ao nom
#' - Mantenha os nomes curtos, concisos e intuitiv
#' - Use as primeiras letras para identificar a cl
#' - Evite o uso de pontos (`.`) ao conectar palav
#' 
## ---- eval=FALSE---------------------------------------------------------------------------------------------
## # GOOD
## my_seq <- 1:100 # simple and clean
## df_prices <- tibble()  # for sure it is a dataframe with prices!
## fct_plot_prices <- function() # I know what it does before executing it!
## l_args <- list() # also nice and clean
## 
## # BAD
## DF <- tibble() # all uppercase and generic
## DataFrame <- tibble() # camel case and same name as object
## list <- list() # Same name as constructor. Does it even work?
##                # It does..
## Prices_of_Facebook <- tibble() # very informative,
##                                # but too long!
## DATAFRAME_WITH_SPECIAL_DATA <- tibble() # too long!
## # Why SHOUT in code? Be nice..
## df.prices <- tibble() # use of dots

#' 
#' **Outras convenções de código**:
#' 
#' - Sempre coloque um espaço entre os operadores 
#' 
## ------------------------------------------------------------------------------------------------------------
# GOOD
x <- 10
flag <- (x > 0)

# BAD
x<-0
flag<-x>0

#' 
#' - Sempre defina um espaço depois de usar a vírg
#' 
## ---- eval = FALSE-------------------------------------------------------------------------------------------
## # GOOD
## my_fct(1, 2, 3)
## my_x <- c(1, 2, 3)
## my_sum <- x + y
## 
## # BAD
## my_fct(1,2,3)
## my_x<-c(1,2,3)
## my_sum<-x+y

#' 
#' Essas são regras simples e importantes que você
#' 
#' 
#' ## Otimizando a Velocidade de Execução 
#' 
#' Para a maioria dos usuários de R, o tempo de ex
#' 
#' Particularmente, análise de dados e produção de
#' 
#' Portanto, fiques ciente de que, ao tentar otimi
#' 
#' O tempo de execução se torna um problema quando
#' 
## A tecnologia `Shiny` permite que programadores do R desenvolvam websites dinâmicos baseados em código do R. Isso significa que podes, por exemplo, ter um site onde o usuário insere um parâmetro qualquer, tal como ticker de uma ação, e a página retorna um gráfico atualizado do preço da ação. Esse é um tópico avançado, além do escopo do livro. Para maiores detalhes sobre a tecnologia, veja o [site oficial do shinny](https://shiny.rstudio.com/)^[https://shiny.rstudio.com/].

#' 
#' De volta ao código, otimizar a velocidade em sc
#' 
#' 
#' ### Perfil do Código R (_profiling_)
#' 
#' Existem diferentes rotas para analisar um códig
#' 
#' Como exemplo, primeiro escreverei uma função qu
#' 
## ------------------------------------------------------------------------------------------------------------
my_bench_fct <- function() {
  
  require(tictoc)
  require(tidyverse)
  
  message('01-Set parameters')
  my_n <- 1000000
  
  message('02-Build variables')
  x <- runif(my_n)
  y <- x + rnorm(my_n)
  
  message('03-Pause for a while -- the bottleneck')
  profvis::pause(1)
  
  message('04-Estimate a linear model')
  lm_model <- lm(data = tibble(x = x, y = y), 
                 formula = y ~ x)
  
  return(lm_model)
}

out <- my_bench_fct()

#' 
#' Sempre que você fizer uma chamada para a função
#' 
#' Para um código complexo e extenso, no entanto, 
#' 
#' Para usar `base::Rprof`, primeiro definimos um 
#' 
#' 
## ---- results='hold'-----------------------------------------------------------------------------------------
# set temporary file for results
profiling_file <-  tempfile(pattern = 'profiling_example', 
                            fileext = '.out')

# initialize profiling
Rprof(filename = profiling_file)

message('01-Set parameters')
my_n <- 1000000

message('02-Build variables ')
x <- runif(my_n)
y <- x + rnorm(my_n)

message('03-Pause for a while -- the bottleneck ')
profvis::pause(1)

message('04-Estimate a linear model ')
lm_model <- lm(data = tibble(x = x, y = y), 
               formula = y ~ x)

# stop profiling
Rprof(NULL)

#' 
#' Os resultados agora podem ser importados com `b
#' 
## ------------------------------------------------------------------------------------------------------------
# check results
df_res <- summaryRprof(profiling_file)$by.total

# print it
print(head(df_res))

#' 
#' No `dataframe` resultante vemos as 5 principais
#' 
#' Outra solução interessante para criação de perf
#' 
## ---- eval=FALSE---------------------------------------------------------------------------------------------
## library(profvis)
## 
## # use profvis
## profiling <- profvis(expr = {
##   require(tictoc)
##   require(tidyverse)
## 
##   message('01-Set parameters ')
##   my_n <- 1000000
## 
##   message('02-Build variables ')
##   x <- runif(my_n)
##   y <- x + rnorm(my_n)
## 
##   message('03-Pause for a while -- the bottleneck ')
##   profvis::pause(1)
## 
##   message('04-Estimate a linear model ')
##   lm_model <- lm(data = tibble(x = x, y = y),
##                  formula = y ~ x)
## 
## })
## 
## # create visualization
## htmlwidgets::saveWidget(profiling , "profile.html")
## 
## # Can open in browser from R
## browseURL("profile.html")

#' 
#' O resultado será semelhante à Figura \@ref(fig:
#' 

#' 
#' 
#' ### Estratégias para Melhorar a Velocidade de E
#' 
#' Depois de identificar o gargalo em seu código, 
#' 
#' 
#' #### Use Operações Vetoriais
#' 
#' Sempre que estiver trabalhando com vetores atôm
#' 
#' Como exemplo, vamos analisar o caso de construç
#' 
## ---- results='hold'-----------------------------------------------------------------------------------------
library(tictoc)

N <- 10000000
x <- 1:N

tic('Using loops without preallocation') # start timer
y <- numeric()
for (i in seq_along(x)) {
  y[i] <- x[i] + 1
}
toc() # end timer

tic('Using loops with preallocation') # start timer
y <- numeric(length = N)
for (i in seq_along(x)) {
  y[i] <- x[i] + 1
}
toc() # end timer

tic('Using vectors') # start timer
y <- x + 10
toc() # end timer

#' 
#' Na primeira versão com loop, definimos `y <- nu
#' 
#' A lição aqui é: **sempre busque versões vetoriz
#' 
#' 
#' #### Junção Repetitiva de `dataframes`
#' 
#' Outro erro comum quando se trata de código R é 
#' 
#' Vamos explorar um exemplo com alguns dados alea
#' 
## ---- results='hold'-----------------------------------------------------------------------------------------
library(tidyverse)

n_dfs <- 1000 # number of dataframes to bind
n_obs <- 1000 # number of observations in each dataframe

tic('Binding dataframes within the loop')
my_df <- tibble()
for (i in 1:n_dfs) {
  temp_df <- tibble(x = runif(n_obs),
                    y = rnorm(n_obs))
  
  my_df <- bind_rows(my_df, temp_df)
  
}
toc()

tic('Using lists within the loop, bind it later')
my_l <- list()
for (i in 1:n_dfs) {
  temp_df <- tibble(x = runif(n_obs),
                    y = rnorm(n_obs))
  
  my_l <- c(my_l, list(temp_df))
}

my_df <- bind_rows(my_l)
toc()

#' 
#' Como você pode ver, a diferença de tempo de exe
#' 
#' 
#' ### Usando Código C ++ (pacote `Rcpp`)
#' 
#' Pacote `Rcpp` [@R-Rcpp] é um ótimo exemplo de c
#' 
#' Veja o próximo exemplo, onde escrevemos uma fun
#' 
## ------------------------------------------------------------------------------------------------------------
library(Rcpp)
library(tictoc)

sum_R_looped <- function(x) {
  total <- 0
  for (i in seq_along(x)) {
    total <- total + x[i]
  }
  return(total)
}

sum_R_vector <- function(x) {
  total <- sum(x)
  return(total)
}

cppFunction('double sum_C(NumericVector x) {
  int n = x.size();
  double total = 0;
  for(int i = 0; i < n; ++i) {
    total += x[i];
  }
  return total;
}')

#' 
#' Usar `cppFunction` é simples, mas vai exigir co
#' 
#' Agora, vamos testar todas as três funções com u
#' 
## ---- results='hold'-----------------------------------------------------------------------------------------
x <- 1:5000000

tic('Sum with R loops')
out1 <- sum_R_looped(x)
toc()

tic('Sum with R (vectorized)')
out2 <- sum_R_vector(x)
toc()

tic('Sum with C++ (rcpp)')
out3 <- sum_C(x)
toc()

#' 
#' O caso com menor tempo de execução é a versão v
#' 
#' Sempre que você tiver um gargalo numérico em se
#' 
#' 
#' ### Usando Cacheeamento Local (pacote `memoise`
#' 
#' Um recurso muito subestimado no R é o uso de es
#' 
#' A estratégia de cache funciona perfeitamente co
#' 
#' Particularmente, o cache funciona muito bem na 
#' 
#' Embora você possa escrever seu próprio sistema 
#'  
## ------------------------------------------------------------------------------------------------------------
sleeping_beauty <- function(arg1, arg2) {
  # Simple example function that will sleep for one second
  #
  # ARGS: arg1 - anything 
  #       arg2 - anything
  # RETURNS: A list
  
  profvis::pause(1)
  
  return(list(arg1, arg2))
}

#' 
#' O primeiro passo para usar `memoise` é definir 
#' 
## Note que ao usar o sistema de arquivos como local de armazenamento dos arquivos do cache, a memória do `memoise` persistirá entre sessões do R. Caso usar a alternativa de `memoise::cache_memory`, a memória existirá apenas para a sessão atual do R e, caso reiniciar a sessão, perderá todas as informações de cache salvas anteriormente.

#' 
## ---- include=FALSE------------------------------------------------------------------------------------------
my_dir <- 'mem_cache'
if (dir.exists(my_dir)) fs::dir_delete(my_dir)

#' 
## ---- message=FALSE------------------------------------------------------------------------------------------
library(memoise)

my_cache_folder <- cache_filesystem(path = 'mem_cache')

#' 
#' O próximo passo é dizer ao `memoise` que temos 
#' 
## ------------------------------------------------------------------------------------------------------------
mem_sleeping_beauty <- memoise(f = sleeping_beauty, 
                               cache = my_cache_folder)

#' 
#' Agora, vamos chamar a função com diferentes arg
#' 
## ---- results='hold'-----------------------------------------------------------------------------------------
library(memoise)
library(tictoc)

tic('    sleeping_beauty:\t arg1 = 1, arg2 = 2')
out1 <- sleeping_beauty(1, 2)
toc()

tic('mem_sleeping_beauty:\t arg1 = 1, arg2 = 2')
out1 <- mem_sleeping_beauty(1, 2)
toc()

tic('    sleeping_beauty:\t arg1 = 1, arg2 = 2')
out1 <- sleeping_beauty(1, 2)
toc()

tic('mem_sleeping_beauty:\t arg1 = 1, arg2 = 2')
out1 <- mem_sleeping_beauty(1, 2)
toc()

#' 
#' A função `sleeping_beauty` é o código original 
#' 
#' Indo além, se mudarmos os argumentos de `mem_sl
#' 
## ---- results='hold'-----------------------------------------------------------------------------------------
tic('mem_sleeping_beauty:\t arg1 = 2, arg2 = 2')
out1 <- mem_sleeping_beauty(2, 2)
toc()

tic('mem_sleeping_beauty:\t arg1 = 2, arg2 = 2')
out2 <- mem_sleeping_beauty(2, 2)
toc()

tic('mem_sleeping_beauty:\t arg1 = 5, arg2 = 1')
out3 <- mem_sleeping_beauty(5, 1)
toc()

#' 
#' Olhando para a pasta `mem_cache`, encontramos o
#' 
## ------------------------------------------------------------------------------------------------------------
mem_files <- list.files('mem_cache/')

print(mem_files)

#' 
#' Esses são apenas arquivos _rds_ com o conteúdo 
#' 

#' 
#' **O armazenamento em cache é uma das melhores t
#' 
#' 
#' #### Usando Processamento Paralelo (pacote `fur
#' 
#' Por padrão, sempre que você está executando um 
#' 
#' Processamento paralelo refere-se a prática de s
#' 
## Uma problemática importante que também deve ser levado em conta na paralelização de código R é o aumento do uso da memória RAM do seu computador. Saiba que, ao paralelizar, o R faz cópias dos objetos para cada núcleo e os armazena na memória RAM da máquina. Caso suas tabelas foram grandes e a memória limitada, o R não conseguirá criar as cópias dos objetos e um erro sobre a falta de memória será mostrado na tela. Como solução para este problema, tente diminuir o número de núcleos utilizados na execução do código, ou então instalar mais memória RAM no seu computador.

#' 
#' Antes de começar, entenda que nem todo código p
#' 
#' Um caso típico de análise de dados onde a paral
#' 
#' Primeiro, vamos escrever uma função que criará 
#' 
## ------------------------------------------------------------------------------------------------------------
create_file <- function(n_obs, folder_to_save) {
  # Create files in the computer
  #
  # ARGS: n_obs - Number of observations in dataframe
  #       folder_to_save - Where to save files
  # RETURNS: True, if successful
  
  require(tidyverse)
  
  
  temp_df <- tibble(x = runif(n_obs),
                    y = rnorm(n_obs))
  
  temp_file <- tempfile(pattern = 'file', tmpdir = folder_to_save, 
                        fileext = '.csv')
  
  write_csv(temp_df, 
            file = temp_file)
  
  return(TRUE)
}

#' 
#' Assim, com a função concluída, é hora de chamá-
#' 
## ---- message=FALSE------------------------------------------------------------------------------------------
library(purrr)

n_files <- 1000
n_obs <- 10000
folder_to_save <- file.path(tempdir(), 'many files')

dir.create(folder_to_save)

pwalk(.l = list(n_obs = rep(n_obs, n_files), 
                folder_to_save = rep(folder_to_save, 
                                     n_files)), 
      create_file)

#' 
#' Agora, lemos esses arquivos com duas estratégia
#' 
#' Antes de começar, precisamos configurar nossa m
#' 
## ------------------------------------------------------------------------------------------------------------
n_cores_available <- future::availableCores()

print(n_cores_available)

#' 
#' A máquina na qual o livro foi compilado possui 
#' 
#' Para executar de forma paralela o código origin
#' 
## ------------------------------------------------------------------------------------------------------------
library(furrr)
library(tictoc)

# get files
my_files <- list.files(path = folder_to_save, 
                       full.names = TRUE)

# setup for multicore
n_cores <- 10

# set the number of cores and type of parallel
plan(strategy = multisession, workers = n_cores)

tic('Sequential with pmap (1 core)')
l_out_1 <- pmap(
  .l = list(file = my_files, 
            col_types = rep(list(cols()), 
                            length(my_files)) ), 
  .f = readr::read_csv
)
toc()

tic(paste0('Parallel with future_pmap (', 
           n_cores, ' cores)'))
l_out_2 <- future_pmap(
  .l = list(file = my_files,
            col_types = rep(list(cols()), 
                            length(my_files)) ), 
  
  .f = readr::read_csv
)
toc()

identical(l_out_1, l_out_2)

#' 
#' Observe que o ganho de velocidade não é dez vez
#' 
#' Concluindo, a computação paralela funciona melh
#' 
#' 
## No uso do pacote `purrr`, saiba que o mesmo limita e memória RAM por núcleo do computador em 500MB. Isso é mais que suficiente para a grande maioria dos caso porém, caso estiver tendo problemas com a insuficiência de RAM na execução de código paralelizado, podes aumentar o limite com o comando `options('future.globals.maxSize' = 1014*1024^2)`. Nesse caso, o limite foi aumentado para 1GB por núcleo.

#' 
#' ## Exercícios
#' 
## ---- echo=FALSE, results='asis'-----------------------------------------------------------------------------
f_in <- fs::dir_ls('../02-EOCE-Rmd//Cap13-Otimização/', 
                   type = 'file')

build_exercises(f_in, type_doc = my_engine)
