#' # Operações Básicas no R {#operacoes-basicas}
#' 

#' 
#' Antes de começar a desenvolver o seu código, é 
#' 
#' Neste capítulo iremos percorrer os passos inici
#' 
#' 
#' ## Como o R Funciona?
#' 
#' A maior dificuldade que um usuário iniciante po
#' 
#' Enquanto esse formato de interação visual e mot
#' 
#' Além disso, o **risco de erro humano na execuçã
#' 
#' No uso do R, o ideal é mesclar o uso do mouse c
#' 
#' O R também possibilita a exportação de arquivos
#' 
#' O produto final de trabalhar com R e RStudio se
#' 
#' 
#' ## Objetos e Funções
#' 
#' No R, **tudo é um objeto, e cada tipo de objeto
#' 
#' Enquanto representamos informações do mundo rea
#' 
#' Cada função possui um próprio nome. Por exemplo
#' 
## ------------------------------------------------------------------------------------------------------------
sort(c(2, 1, 3, 0), decreasing = TRUE)

#' 
#' O comando `c(2, 1, 3, 0)` combina os valores em
#' 
## ------------------------------------------------------------------------------------------------------------
sort(c(2, 1, 3, 0), decreasing = FALSE)

#' 
#' **O uso de funções está no coração do R** e ire
#' 
#' 
#' ## O Formato Brasileiro
#' 
#' Antes de começar a explicar o uso do R e RStudi
#' 
#' **Decimal:** O decimal no R é definido pelo pon
#' 
#' **Caracteres latinos:** Devido ao seu padrão in
#' 
#' **Formato das datas:** Datas no R são formatada
#' 
#' No momento de instalação do R, diversas informa
#' 
## ------------------------------------------------------------------------------------------------------------
# get local format
Sys.localeconv()

#' 
#' A saída de `Sys.localeconv()` mostra como o R i
#' 
## Muito cuidado ao modificar o formato que o R interpreta os diferentes símbolos e notações. Como regra de bolso, caso precisar usar algum formato específico, faça-o isoladamente dentro do contexto do código. Evite mudanças permanentes pois nunca se sabe onde tais formatos estão sendo usados. Evite, assim, surpresas desagradáveis no futuro.

#' 
#' ## Tipos de Arquivos
#' 
#' Assim como outros programas, o R possui um ecos
#' 
#' **Arquivos com extensão _.R_**: Representam arq
#' 
#' **Arquivos com extensão _.RData_ e _.rds_**: ar
#' 
#' **Arquivos com extensão _.Rmd_, _.md_ e _.Rnw_*
#' 
#' **Arquivos com extensão _.Rproj_**: Contém info
#' 
#' 
#' ## Explicando a Tela do RStudio
#' 
#' Após instalar os dois programas, R e RStudio, P
#' 
## ----RStudio1, echo=FALSE, out.width = my.out.width, fig.cap = 'A tela do RStudio'---------------------------
knitr::include_graphics('00-text-resources/figs/RStudio1.png')

#' 
#' Observe que o RStudio automaticamente detectou 
#' 
#' Como um primeiro exercício, clique em _File_,  
#' 
## ----RStudio2, echo=FALSE, out.width = my.out.width, fig.cap = 'Explicando a tela do RStudio'----------------
knitr::include_graphics('00-text-resources/figs/RStudio2.png')

#' 
## Uma sugestão importante aqui é modificar o esquema de cores do RStudio para uma configuração de **tela escura**. Não é somente uma questão estética mas sim de prevenção e melhoria de sua saúde física. Possivelmente irás passar demasiado tempo na frente do computador. Assim, vale a pena modificar as cores da interface para aliviar seus olhos do constante brilho da tela. Dessa forma, conseguirás trabalhar por mais tempo, sem forçar a sua visão. Podes configurar o esquema de cores do RStudio indo na opção _Tools_, _Global Options_ e então em _Appearance_. Um esquema de cores escuras que pessoalmente gosto e sugiro é o _Ambience_.

#' 
#' Após os passos anteriores, a tela do RStudio de
#' 
#' **Editor de scripts (_Script editor_):**  local
#' 
#' **Console do R (_R prompt_):** localizado no la
#' 
#' **Área de trabalho (_Environment_):** localizad
#' 
#' **Pacotes (_Panel Packages_):** mostra os pacot
#' 
#' Como um exercício introdutório, vamos inicializ
#' 
## ------------------------------------------------------------------------------------------------------------
# set x and y
x <- 1
y <- 'my text'

#' 
#' Após a execução, dois objetos devem aparecer no
#' 
#' Agora, vamos mostrar na tela os valores de `x`.
#' 
## ------------------------------------------------------------------------------------------------------------
# print x
print(x)

#' 
#' A função `print` é uma das principais funções p
#' 
## ------------------------------------------------------------------------------------------------------------
# print vector from 50 to 100
print(50:100)

#' 
#' Nesse caso, utilizamos o símbolo `:` em `50:100
#' 
#' 
#' ## Pacotes do R
#' 
#' Um dos grandes benefícios do uso do R é o seu a
#' 
#' Esses pacotes podem ser instalados de diferente
#' 
#' O CRAN é o repositório oficial do R e é livre. 
#' 
#' A lista completa de pacotes disponíveis no CRAN
#' 
#' Outra fonte importante para o encontro de pacot
#' 
## ----TaskViews, echo=FALSE, out.width = '100%', fig.cap = 'Tela do Task Views'-------------------------------
knitr::include_graphics("00-text-resources/figs/TaskViews.png")

#' 
#' Ao contrário do CRAN, o _Github_ não possui res
#' 
#' O mais interessante no uso de pacotes é que est
#' 
## ------------------------------------------------------------------------------------------------------------
# find current available packages
df_cran_pkgs <- available.packages()

# get size of matrix
n_cran_pkgs <- nrow(df_cran_pkgs)

# print it
print(n_cran_pkgs)

#' 
#' Atualmente, `r Sys.time()`, existem `r n_cran_p
#' 
#' Também se pode verificar a quantidade de pacote
#' 
## ------------------------------------------------------------------------------------------------------------
# get number of local (installed) packages
n_local_pkgs <- nrow(installed.packages())

# print it
print(n_local_pkgs)

#' 
#' Nesse caso, o computador em que o livro foi esc
#' 
#' 
#' ### Instalando Pacotes do CRAN
#' 
#' Para instalar um pacote, basta utilizar o coman
#' 
## ----eval=FALSE----------------------------------------------------------------------------------------------
## # install pkg readr
## install.packages('readr')

#' 
#' Copie e cole este comando no _prompt_ e pronto!
#' 
#' Aproveitando o tópico, sugiro que o leitor já i
#' 
## ----eval=FALSE----------------------------------------------------------------------------------------------
## # install pkgs from tidyverse
## install.packages('tidyverse')

#' 
#' O `tidyverse` é um conjunto de pacotes voltados
#' 
#' 
#' ### Instalando Pacotes do Github
#' 
#' Para instalar um pacote diretamente do Github, 
#' 
## ----eval=FALSE----------------------------------------------------------------------------------------------
## # install devtools
## install.packages('devtools')

#' 
#' Após isto, utilize função `devtools::install_gi
#' 
#' No exemplo a seguir instalamos a versão em dese
#' 
## ----eval=FALSE----------------------------------------------------------------------------------------------
## # install ggplot2 from github
## devtools::install_github("hadley/ggplot2")

#' 
#' Observe que o nome do usuário do repositório ta
#' 
## Um aviso aqui é importante. **Os pacotes do github não são moderados. Qualquer pessoa pode enviar código para lá e o conteúdo não é checado de forma independente.** Nunca instale pacotes do github sem conhecer os autores. Apesar de improvável -- nunca aconteceu comigo por exemplo -- é possível que esses possuam algum código malicioso.

#' 
#' 
#' ### Carregando Pacotes
#' 
#' Dentro de uma rotina de pesquisa, utilizamos a 
#' 
## ----eval=FALSE----------------------------------------------------------------------------------------------
## # load dplyr
## library(dplyr)

#' 
#' A partir disso, todas as funções do pacote esta
#' 
## ------------------------------------------------------------------------------------------------------------
# call fct fortune() from pkg fortune
fortunes::fortune(10)

#' 
#' Nesse caso, utilizamos a função `fortune` do pr
#' 
## ---- echo = FALSE-------------------------------------------------------------------------------------------
message('Error in library("fortune") : there is no package called "fortune"')

#' 
#' Para resolver, utilize o comando `install.packa
#' 
#' Outra maneira de carregar um pacote é através d
#' 
## ----eval=FALSE----------------------------------------------------------------------------------------------
## my_fct <- function(x){
##   require(quantmod)
## 
##   df <- getSymbols(x, auto.assign = F)
##   return(df)
## }

#' 
#' Nesse caso, a função `getSymbols` faz parte do 
#' 
## Uma precaucão que deve sempre ser tomada quando se carrega um pacote é um possível **conflito de funções**. Por exemplo, existe uma função chamada `filter` no pacote `dplyr` e também no pacote `stats`. Caso carregarmos ambos pacotes e chamarmos a função `filter` no escopo do código, qual delas o R irá usar? Pois bem, a **preferência é sempre para o último pacote carregado**. Esse é um tipo de problema que pode gerar muita confusão. Felizmente, note que o próprio R acusa um conflito de nome de funções no carregamento do pacote. Para testar, inicie uma nova sessão do R e carregue o pacote `dplyr`. Verás que uma mensagem indica haver dois conflitos com o pacote `stats` e quatro com pacote o `base`.

#' 
#' 
#' ### Atualizando Pacotes
#' 
#' Ao longo do tempo, é natural que os pacotes dis
#' 
## ----RStudio-update, echo=FALSE, out.width = '100%', fig.cap = 'Atualizando pacotes no R'--------------------
knitr::include_graphics('00-text-resources/figs/RStudio_update.png')

#' 
#' A atualização de pacotes através do _prompt_ ta
#' 
## ----eval=FALSE----------------------------------------------------------------------------------------------
## update.packages()

#' 
#' O comando `update.packages()` compara a versão 
#' 
## Versionamento de pacotes é extremamente importante para manter a reproducibilidade do código. Apesar de ser raro de acontecer, é possível que a atualização de um pacote no R modifique, para os mesmos dados, resultados já obtidos anteriormente. Tenho uma experiência particularmente memorável quando um artigo científico retornou da revisão e, devido a atualização de um dos pacotes, não consegui reproduzir os resultados apresentados no artigo. No final deu tudo certo, mas o trauma fica.

## 
## Uma solução para este problema é congelar as versões dos pacotes para cada projeto usando a ferramenta `packrat` do RStudio. Em resumo, o `packrat` faz cópias locais dos pacotes utilizados no projeto, os quais têm preferência aos pacotes do sistema. Assim, se um pacote for atualizado no sistema, mas não no projeto, o código R vai continuar usando a versão mais antiga e seu código sempre rodará nas mesmas condições.

#' 
#' ## Executando Códigos em um _Script_
#' 
#' Agora, vamos juntar todos os códigos digitados 
#' 
## ---- eval = FALSE-------------------------------------------------------------------------------------------
## # set objects
## x <- 1
## y <- 'my text'
## 
## # print it
## print(x)
## print(1:50)

#' 
#' Após colar todos os comandos no editor, salve o
#' 
#' No RStudio existem alguns atalhos predefinidos 
#' 

#' 
#' Outro comando muito útil é a execução por linha
#' 
#' * **control+shift+s** executa o arquivo atual d
#' * **control+shift+enter**: executa o arquivo at
#' * **control+enter**: executa a linha selecionad
#' * **control+shift+b**: executa os códigos do in
#' * **control+shift+e**: executa os códigos da li
#' 
#' Sugere-se que esses atalhos sejam memorizados e
#' 
#' Porém, no mundo real de programação, poucos são
#' 
#' Neste caso, para executar os _scripts_ em sequê
#' 
## ----eval=FALSE----------------------------------------------------------------------------------------------
## # Import all data
## source('01-import-data.R')
## 
## # Clean up
## source('02-clean-data.R')
## 
## # Build tables
## source('03-build-table.R')

#' 
#' Nesse caso, o código anterior é equivalente a a
#' 
#' Como podemos ver, existem diversas maneiras de 
#' 
#' 
#' ## Testando Código
#' 
#' O desenvolvimento de códigos em R segue um conj
#' 
#' Um ciclo de trabalho fica claro, a escrita do c
#' 
#' Quando você está tentando encontrar um erro em 
#' 
#' 

#' 
#' O círculo vermelho indica um ponto de interrupç
#' 
## ----eval=FALSE----------------------------------------------------------------------------------------------
## # set x
## x <- 1
## 
## # set y
## browser()
## y <- 'My humble text'
## 
## # print contents of x
## print(x)

#' 
#' O resultado prático do código anterior é o mesm
#' 
#' 
#' ## Criando Objetos Simples
#' 
#' Um dos comandos mais básicos no R é a definição
#' 
## ------------------------------------------------------------------------------------------------------------
# set x
my_x <- 123

# set x, y and z in one line
my_x <- 1 ; my_y <- 2; my_z <- 3

#' 
#' Lê-se esse código como _x é definido como 123_.
#' 
## O uso do símbolo `<-` para a definição de objetos é específico do R. Na época da concepção da linguagem _S_, de onde o R foi baseado, existiam teclados com uma tecla específica que definia diretamente o símbolo de seta. Teclados contemporâneos, porém, não possuem mais esta configuração. Uma alternativa é utilizar o atalho para o símbolo, o qual, no Windows, é definido por `alt + -`.

#' 
#' É possível também usar o símbolo `=` para defin
#' 
#' O nome dos objetos é importante no R. Tirando a
#' 
#' O R executa o código procurando objetos e funçõ
#' 
## ---- error=TRUE---------------------------------------------------------------------------------------------
print(z)

#' 
#' Isso ocorre pois o objeto `z` não existe na ses
#' 
#' Um ponto importante aqui é a definição de objet
#' 
## ------------------------------------------------------------------------------------------------------------
# set vars
x <- 1
y <- '1'

# display classes
class(x)
class(y)

#' 
#' As saídas anteriores mostram que a variável `x`
#' 
#' 
#' ## Criando Vetores
#' 
#' Nos exemplos anteriores criamos objetos simples
#' 
#' Um dos procedimentos mais utilizados no R é a c
#' 
#' **Vetores atômicos são criados no R através do 
#' 
## ------------------------------------------------------------------------------------------------------------
# set vector
x <- c(1, 2, 3)

# print it
print(x)

#' 
#' Esse comando funciona da mesma maneira para qua
#' 
#' O uso do comando `c` não é exclusivo para vetor
#' 
## ------------------------------------------------------------------------------------------------------------
y <- c('text 1', 'text 2', 'text 3', 'text 4')
print(y)

#' 
#' A única restrição no uso do comando `c` é que t
#' 
## ------------------------------------------------------------------------------------------------------------
# numeric class
x <- c(1, 2)
class(x)

# character class
x <- c(1, 2, '3')
class(x)

#' 
#' Outra utilização do comando `c` é a combinação 
#' 
## ------------------------------------------------------------------------------------------------------------
# set x and y
x <- c(1, 2, 3)
y <- c(4, 5)

# print concatenation between x and y
print(c(x, y))

#' 
#' Portanto, o comando `c` possui duas funções pri
#' 
#' 
#' ## Conhecendo os Objetos Criados
#' 
#' Após a execução de diversos comandos no editor 
#' 
## ---- eval = FALSE-------------------------------------------------------------------------------------------
## # set vars
## x <- 1
## y <- 2
## z <- 3
## 
## # show current objects
## ls()

#' 
## ---- echo = FALSE-------------------------------------------------------------------------------------------
# set vars
x <- 1
y <- 2
z <- 3

# show current objects
print(c('x', 'y', 'z'))

#' 
#' Os objetos `x`, `y` e `z` foram criados e estav
#' 
## ------------------------------------------------------------------------------------------------------------
x
y
z

#' 
#' Destaca-se que digitar o nome do objeto na tela
#' 
#' No R, conforme já mostrado, todos os objetos pe
#' 
## ------------------------------------------------------------------------------------------------------------
# set vars
x <- 1
y <- 'a'

# check classes
class(x)
class(y)

#' 
#' Outra maneira de conhecer melhor um objeto é ve
#' 
## ------------------------------------------------------------------------------------------------------------
# print textual representation of a vector
x <- 1:10
print(str(x))

#' 
#' Essa função é particularmente útil quando se es
#' 
#' 
#' ## Mostrando e Formatando Informações na Tela
#' 
#' Como já vimos, é possível mostrar o valor de um
#' 
#' Porém, existem outras funções específicas para 
#' 
#' Por exemplo, caso quiséssemos mostrar na tela o
#' 
## ------------------------------------------------------------------------------------------------------------
# set var
x <- 2

# print with message()
message('The value of x is', x)

#' 
#' Função `message` também funciona para vetores:
#' 
## ------------------------------------------------------------------------------------------------------------
# set vec
x <- 2:5

# print with message()
message('The values in x are: ', x)

#' 
#' A customização da saída da tela é possível atra
#' 
## ------------------------------------------------------------------------------------------------------------
# set char
my_text <- 'First line,\nSecond Line,\nThird Line'

# print with new lines
message(my_text)

#' 
#' Observe que o uso do `print` não resultaria no 
#' 
## ------------------------------------------------------------------------------------------------------------
print(my_text)

#' 
#' Outro exemplo no uso de comandos específicos pa
#' 
## ------------------------------------------------------------------------------------------------------------
# set char with \t
my_text_1 <- 'A and B'
my_text_2 <- '\tA and B'
my_text_3 <- '\t\tA and B'

# print with message()
message(my_text_1)
message(my_text_2)
message(my_text_3)

#' 
#' Vale destacar que, na grande maioria dos casos 
#' 
#' Parte do processo de apresentação de texto na t
#' 
#' A função  `paste` _cola_ uma série de caractere
#' 
## ------------------------------------------------------------------------------------------------------------
# set chars
my_text_1 <- 'I am a text'
my_text_2 <- 'very beautiful'
my_text_3 <- 'and informative.'

# using paste and message
message(paste(my_text_1, my_text_2, my_text_3))

#' 
#' O resultado anterior não está muito longe do qu
#' 
## ------------------------------------------------------------------------------------------------------------
# using paste0
message(paste0(my_text_1, my_text_2, my_text_3))

#' 
## Uma alternativa a função `message` é `cat` (_concatenate and print_). Não é incomum encontrarmos códigos onde mensagens para o usuário são transmitidas via `cat` e não `message`. Como regra, dê preferência a `message` pois esta é mais fácil de controlar. Por exemplo, caso o usuário quiser silenciar uma função, omitindo todas saídas da tela, bastaria usar o comando `suppressMessages`.

#' 
#' Outra possibilidade muito útil no uso do `paste
#' 
## ------------------------------------------------------------------------------------------------------------
# using custom separator
message(paste(my_text_1, my_text_2, my_text_3, sep = ', '))

#' 
#' Caso tivéssemos um vetor atômico com os element
#' 
## ------------------------------------------------------------------------------------------------------------
# using paste with collapse argument
my_text <-c('Eu sou um texto', 'muito bonito', 'e charmoso.')
message(paste(my_text, collapse = ', '))

#' 
#' Prosseguindo, o comando `format` é utilizado pa
#' 
## ------------------------------------------------------------------------------------------------------------
# message without formatting
message(1/3)

#' 
#' Caso quiséssemos apenas dois dígitos aparecendo
#' 
## ------------------------------------------------------------------------------------------------------------
# message with format and two digits
message(format(1/3, digits=2))

#' 
#' Tal como, também é possível mudar o símbolo de 
#' 
## ------------------------------------------------------------------------------------------------------------
# message with format and two digits
message(format(1/3, decimal.mark = ','))

#' 
#' Tal flexibilidade é muito útil quando devemos r
#' 
#' Uma alternativa recente e muito interessante pa
#' 
## ------------------------------------------------------------------------------------------------------------
library(stringr)

# define some vars
my_name <- 'Pedro'
my_age <- 23

# using base::paste0
my_str_1 <- paste0('My name is ', my_name, ' and my age is ', my_age)

# using stringr::str_c
my_str_2 <- str_c('My name is ', my_name, ' and my age is ', my_age)

# using stringr::str_glue
my_str_3 <- str_glue('My name is {my_name} and my age is {my_age}')

identical(my_str_1, my_str_2)
identical(my_str_1, my_str_3)
identical(my_str_2, my_str_3)

#' 
#' Como vemos, temos três alternativas para o mesm
#' 
#' 
#' ## Conhecendo o Tamanho dos Objetos
#' 
#' Na prática de programação com o R, é muito impo
#' 
#' No R, o tamanho do objeto pode ser verificado c
#' 
#' A função `length` é destinada a objetos com uma
#' 
## ------------------------------------------------------------------------------------------------------------
# set x
x <- c(2,3,3,4,2,1)

# get length x
n <- length(x)

# display message
message(paste('The length of x is', n))

#' 
#' Para objetos com mais de uma dimensão, por exem
#' 
## ------------------------------------------------------------------------------------------------------------
# set matrix and print it
x <- matrix(1:20, nrow = 4, ncol = 5)
print(x)

# find number of rows, columns and elements
my_nrow <- nrow(x)
my_ncol <- ncol(x)
my_length <- length(x)

# print message
message(paste('\nThe number of lines in x is ', my_nrow))
message(paste('\nThe number of columns in x is ', my_ncol))
message(paste('\nThe number of elements in x is ', my_length))

#' 
#' Já a função `dim` mostra a dimensão do objeto, 
#' 
## ------------------------------------------------------------------------------------------------------------
print(dim(x))

#' 
#' Para o caso de objetos com mais de duas dimensõ
#' 
## ------------------------------------------------------------------------------------------------------------
# set array with dimension
my_array <- array(1:9, dim = c(3,3,3))

# print it
print(my_array)

# print its dimension
print(dim(my_array))

#' 
#' Uma observação importante aqui é que as funções
#' 
## ------------------------------------------------------------------------------------------------------------
# set char object
my_char <- 'abcde'

# find its length (and NOT number of characters)
print(length(my_char))

#' 
#' Isso ocorre pois a função `length` retorna o nú
#' 
## ------------------------------------------------------------------------------------------------------------
# using nchar for number of characters
print(nchar(my_char))

#' 
#' Reforçando, cada objeto no R tem suas proprieda
#' 
#' 
#' ## Selecionando Elementos de um Vetor Atômico
#' 
#' Após a criação de um vetor atômico de qualquer 
#' 
#' Esse processo de seleção de _pedaços_ de um vet
#' 
## ------------------------------------------------------------------------------------------------------------
# set my_x
my_x <- c(1, 5, 4, 3, 2, 7, 3.5, 4.3)

#' 
#' Se quiséssemos apenas o terceiro elemento de `m
#' 
## ------------------------------------------------------------------------------------------------------------
# get third element of my_x
elem_x <- my_x[3]
print(elem_x)

#' 
#' Também podemos utilizar o comando `length`, apr
#' 
## ------------------------------------------------------------------------------------------------------------
# get last element of my_x
last_elem <- my_x[length(my_x)]

# print it
print(last_elem)

#' 
#' No caso de estarmos interessado apenas no últim
#' 
## ------------------------------------------------------------------------------------------------------------
# get last and second last elements
piece_x_1 <- my_x[ (length(my_x)-1):length(my_x) ]

# print it
print(piece_x_1)

#' 
#' Uma propriedade única da linguagem R é que, cas
#' 
## ------------------------------------------------------------------------------------------------------------
# set vec
my_vec <- c(1,2,3)

# find fourth element (NA returned!)
print(my_vec[4])

#' 
#' É importante conhecer esse comportamento do R, 
#' 
## Geralmente, a ocorrência de `NAs` (_Not Available_) sugere a existência de problema no código. Saiba que `NA` indicam a falta de dados e são contagiosos: tudo que interagir com objeto do tipo `NA`, seja uma soma ou multiplicação, irá também virar `NA`. **O usuário deve prestar atenção toda vez que surgirem valores `NA` de forma inesperada nos objetos criados.** Uma inspeção nos índices dos vetores pode ser necessária.

#' 
#' O uso de indexadores é muito útil quando se est
#' 
## ------------------------------------------------------------------------------------------------------------
# get all values higher than 3
piece_x_2 <- my_x[my_x>3]

# print it
print(piece_x_2)

#' 
#' É possível também indexar por mais de uma condi
#' 
## ------------------------------------------------------------------------------------------------------------
# get all values higher than 2 AND lower than 4
piece_x_3 <- my_x[ (my_x>2) & (my_x<4) ]

# print it
print(piece_x_3)

#' 
#' Da mesma forma, havendo interesse nos itens que
#' 
## ------------------------------------------------------------------------------------------------------------
# get all values lower than 3 OR higher than 6
piece_x_4 <- my_x[ (my_x<3)|(my_x>6) ]

# print it
print(piece_x_4)

#' 
#' A indexação lógica também funciona com a intera
#' 
## ------------------------------------------------------------------------------------------------------------
# set my_x and my_y
my_x <- c(1, 4, 6, 8, 12)
my_y <- c(-2, -3, 4, 10, 14)

# find elements in my_x where my_y are positive
my_piece_x <- my_x[ my_y > 0 ]

# print it
print(my_piece_x)

#' 
#' Olhando mais de perto o processo de indexação, 
#' 
## ------------------------------------------------------------------------------------------------------------
# set logical object
my_logical <- my_y > 0

# print it
print(my_logical)

# show its class
class(my_logical)

#' 
#' As demais propriedades e operações com vetores 
#' 
#' 
#' ## Limpando a Memória
#' 
#' Após a criação de diversas variáveis, o ambient
#' 
#' Por exemplo, dada uma variável `x`, podemos exc
#' 
## ---- eval = FALSE-------------------------------------------------------------------------------------------
## # set x and y
## x <- 1
## y <- 2
## 
## # print all existing objects
## ls()
## 
## # remove x from memory
## rm('x')
## 
## # print objects again
## ls()

#' 
#' Observe que o objeto `x` não estará mais mais d
#' 
#' Entretanto, em situações práticas é desejável l
#' 
## ---- eval = FALSE-------------------------------------------------------------------------------------------
## # clean up workspace (all existing objects)
## rm(list = ls())

#' 
#' O termo `list` é um argumento da função `rm`, o
#' 
## A limpeza da memória em _scripts_ é uma estratégia controversa. Alguns autores argumentam que é melhor não limpar a memória pois isso pode apagar resultados importantes. Na minha opinião, acho fundamental limpar a memória, desde que todos resultados sejam reproduzíveis. Ao iniciar um código sempre do mesmo estado, isto é, nenhuma variável criada, fica mais fácil de entender e capturar possíveis _bugs_.

#' 
#' 
#' ## Mostrando e Mudando o Diretório de Trabalho
#' 
#' Assim como outros softwares, **o R sempre traba
#' 
#' Em sua inicialização, o R possui como diretório
#' 
#' Para mostrar o diretório atual de trabalho, bas
#' 
## ---- eval = FALSE-------------------------------------------------------------------------------------------
## # get current directory
## my_dir <- getwd()
## 
## # print it
## print(my_dir)

#' 
## ---- echo=FALSE---------------------------------------------------------------------------------------------
message('[1] home/msperlin/adfeR/01-Book Content')

#' 
#' O resultado do código anterior mostra a pasta o
#' 
#' A mudança de diretório de trabalho é realizada 
#' 
## ----eval=FALSE----------------------------------------------------------------------------------------------
## # set dir
## my_d <- 'C:/Minha Pesquisa/'
## setwd(my_d)

#' 
#' Enquanto para casos simples, como o anterior, l
#' 
## ---- eval=FALSE, error=TRUE---------------------------------------------------------------------------------
## my_d <- 'C:\Minha pesquisa\'
## setwd(my_d)

#' 
#' O erro terá a seguinte mensagem:
#' 
#'     Error: '\M' is an unrecognized escape in ch
#' 
#' A justificativa para o erro é que a barra inver
#' 
## ------------------------------------------------------------------------------------------------------------
# set char with \
my_char <- 'using \\'

# print it
message(my_char)

#' 
#' A solução do problema é simples. Após copiar o 
#' 
## ----eval=FALSE----------------------------------------------------------------------------------------------
## my_d <- 'C:/Minha pesquisa/'
## setwd(my_d)

#' 
#' É possível também utilizar barras invertidas du
#' 
#' Outro ponto importante aqui é o uso de endereço
#' 
## ----eval=FALSE----------------------------------------------------------------------------------------------
## # change to subfolder
## setwd('Data')

#' 
#' Outra possibilidade pouco conhecida no uso de `
#' 
## ----eval=FALSE----------------------------------------------------------------------------------------------
## # change to previous level
## setwd('..')

#' 
#' Portanto, caso estejas trabalhando no diretório
#' 
#' Uma maneira mais moderna e pouco conhecida de d
#' 
## ---- eval=FALSE---------------------------------------------------------------------------------------------
## my_path <- dirname(rstudioapi::getActiveDocumentContext()$path)
## setwd(my_path)

#' 
#' Dessa forma, o _script_ mudará o diretório para
#' 
## Outro truque bastante útil para definir diretórios de trabalho no R é usar o símbolo `~`. Esse define a pasta `'Documentos'` no _Windows_, a qual é única para cada usuário. Portanto, ao executar `setwd('~')`, irás direcionar o R a uma pasta de fácil acesso e livre modificação pelo usuário atual do computador.

#' 
#' 
#' ## Comentários no Código
#' 
#' Comentários são definidos usando o símbolo `#`.
#' 
## ------------------------------------------------------------------------------------------------------------
# This is a comment
# This is another comment
x <- 'abc' # this is another comment, but mixed with code

my_l <- list(var1 = 1:10,   # set var 1
             var2 = 2:5)    # another var

#' 
#' **Os comentários são uma eficiente maneira de c
#' 
## ---- eval = FALSE-------------------------------------------------------------------------------------------
## # read a csv file
## df <- read.csv ('MyDataFile.csv')

#' 
#' Como você pode ver, é bastante óbvio que a linh
#' 
## ---- eval=FALSE---------------------------------------------------------------------------------------------
## # Script for reproducing results of JOHN (2018)
## # Author: Mr Researcher (dontspamme@emailprovider.com)
## # Last script update: 2018-01-10
## #
## # File downloaded from www.sitewithdatafiles.com/data-files/
## # The description of the data goes here
## #
## # Last file update: 2017-12-05
## df <- read.csv('MyDataFile.csv')

#' 
#' Com esses comentários, o usuário saberá o propó
#' 
#' Outro uso de comentários é **definir seções no 
#' 
## ---- eval=FALSE---------------------------------------------------------------------------------------------
## # Script for reproducing results of JOHN (2018)
## # Author: Mr Researcher (dontspamme@emailprovider.com)
## # Last script update: 2018-01-10
## #
## # File downloaded from www.sitewithdatafiles.com/data-files/
## # The description of the data goes here
## #
## # Last file update: 2017-12-05
## 
## # Clean data -------------------------
## # - remove outliers
## # - remove unnecessary columns
## 
## # Create descriptive tables ----------
## 
## 
## # Estimate models --------------------
## 
## 
## # Report results ---------------------

#' 
#' O uso de uma longa linha de traços (`-`) é inte
#' 
## Quando começar a compartilhar código com outras pessoas, logo perceberás que os comentários são essenciais e esperados. Eles ajudam a transmitir informações que não estão disponíveis no código. Uma nota aqui, ao longo do livro você verá que os comentários do código são, na maior parte do tempo, bastante óbvios. Isso foi intencional, pois mensagens claras e diretas são importantes para novos usuários, os quais fazem parte da audiência.

#' 
#' ## Cancelando a Execução de um Código
#' 
#' Toda vez que o R estiver executando algum códig
#' 
#' Para testar o cancelamento de código, copie e c
#' 
## ---- tidy=FALSE, eval=FALSE---------------------------------------------------------------------------------
## for (i in 1:100) {
##   message('\nRunning code (please make it stop by hitting esc!)')
##   Sys.sleep(1)
## }

#' 
#' O código anterior usa um comando especial do ti
#' 
#' 
#' ## Procurando Ajuda
#' 
#' Uma tarefa muito comum no uso do R é procurar a
#' 
#' É possível buscar ajuda utilizando tanto o pain
#' 
#' No R, toda tela de ajuda de uma função é igual,
#' 
## ----ExemploAjuda, echo=FALSE, out.width = '100%', fig.cap = 'Tela de ajuda da função mean'------------------
knitr::include_graphics('00-text-resources/figs/ExemploAjuda.png')

#' 
#' Caso quiséssemos procurar um termo nos arquivos
#' 
#' Como sugestão, o ponto inicial e mais direto pa
#' 
#' Outra fonte muito importante de ajuda é a própr
#' 
#' Caso estiver recebendo uma mensagem de erro eni
#' 
## Toda vez que for pedir ajuda na internet, procure sempre 1) descrever claramente o seu problema e 2) adicionar um código reproduzível do seu problema. Assim, o leitor pode facilmente verificar o que está acontecendo ao rodar o exemplo no seu computador. Não tenho dúvida que, se respeitar ambas regras, logo uma pessoa caridosa lhe ajudará com o seu problema.

#' 
#' 
#' ## Utilizando _Code Completion_ com a Tecla _ta
#' 
#' Um dos recursos mais úteis do RStudio é o preen
#' 
## ----autocomplete, echo=FALSE, out.width = '100%', fig.cap = 'Uso do autocomplete para objetos'--------------
knitr::include_graphics('00-text-resources/figs/autocomplete_objetos.png')

#' 
#' Essa ferramenta também funciona para pacotes. P
#' 
## ----autocomplete-pacotes, echo=FALSE, out.width = '100%', fig.cap = 'Uso do autocomplete para pacotes'------
knitr::include_graphics('00-text-resources/figs/autocomplete_pacotes.png')

#' 
#' Observe que uma descrição do pacote ou objeto t
#' 
#' O uso dessa ferramenta torna-se ainda mais bené
#' 
#' Outro uso do _tab_ é no encontro de arquivos e 
#' 
## ----autocomplete-arquivos, echo=FALSE, out.width = '100%', fig.cap = 'Uso do autocomplete para arquivos'----
knitr::include_graphics('00-text-resources/figs/autocomplete_arquivos.png')

#' 
#' Uma dica aqui é utilizar o _tab_ com a raiz do 
#' 
#' O _autocomplete_ também funciona para encontrar
#' 
## O _autocomplete_ é uma das ferramentas mais importantes do RStudo, funcionando para encontro de objetos, locais no disco rígido, pacotes e funções. Acostume-se a utilizar a tecla _tab_ o quanto antes e logo verá como fica mais fácil escrever código rapidamente, e sem erros de digitação.

#' 
#' 
#' ## Interagindo com Arquivos e o Sistema Operaci
#' 
#' Em muitas situações de uso do R será necessário
#' 
#' 
#' ### Listando Arquivos e Pastas
#' 
#' Para listar arquivos do computador, basta utili
#' 
## ------------------------------------------------------------------------------------------------------------
my_f <- list.files(path = "00-text-resources/data", full.names = TRUE)
print(my_f[1:5])

#' 
#' Observe que nesse diretório encontram-se vários
#' 
## ----eval=FALSE----------------------------------------------------------------------------------------------
## # list all files recursively
## list.files(path = getwd(), recursive = T, full.names = TRUE)

#' 
#' O comando anterior irá listar todos os arquivos
#' 
#' Para listar pastas (diretórios) do computador, 
#' 
## ------------------------------------------------------------------------------------------------------------
# list directories
my_dirs <- list.dirs(recursive = F)
print(my_dirs)

#' 
#' No caso anterior, o comando lista todos os dire
#' 
## ------------------------------------------------------------------------------------------------------------
list.files(path = getwd(), pattern = "*.Rmd$")

#' 
#' O texto `*.Rmd$` orienta o R a procurar todos a
#' 
#' 
#' ### Apagando Arquivos e Diretórios
#' 
#' A remoção de arquivos é realizada através do co
#' 
## ------------------------------------------------------------------------------------------------------------
# create temporary file
my_file <- 'MyTemp.csv'
write.csv(x = data.frame(x=1:10),
          file = my_file)

# delete it
file.remove(my_file)

#' 
#' Lembre-se que deves ter permissão do seu sistem
#' 
#' Para deletar diretórios e todos os seus element
#' 
## ---- echo=FALSE---------------------------------------------------------------------------------------------
if (dir.exists('temp')) unlink('temp')

#' 
## ------------------------------------------------------------------------------------------------------------
# create temp dir
dir.create('temp')

# fill it with file
my_file <- 'temp/tempfile.csv'
write.csv(x = data.frame(x=1:10),
          file = my_file)

unlink(x = 'temp', recursive = TRUE)

#' 
#' A função, neste caso, não retorna nada. Podes c
#' 
## ------------------------------------------------------------------------------------------------------------
dir.exists('temp')

#' 
## Não preciso nem dizer, **tenha muito cuidado** com comandos `file.remove` e `unlink`, principalmente quando utilizar a recursividade (`recursive = TRUE`). Uma execução errada e partes importantes do seu disco rídigo podem ser apagadas, deixando o seu computador inoperável. Vale salientar que o R **realmente apaga** os arquivos e não somente manda para a "lixeira". Portanto, ao apagar diretórios com `unlink`, não poderás recuperar os arquivos.

#' 
#' 
#' ### Utilizando Arquivos e Diretórios Temporário
#' 
#' Um aspecto interessante do R é que ele possui u
#' 
#' O endereço do diretório temporário de uma sessã
#' 
## ---- eval=TRUE----------------------------------------------------------------------------------------------
my_tempdir <- tempdir()
message(str_glue('My tempdir is {my_tempdir}'))

#' 
#' O último texto do diretório, neste caso `r base
#' 
#' A mesma dinâmica é encontrada para nomes de arq
#' 
## ---- eval=TRUE----------------------------------------------------------------------------------------------
my_tempfile <- tempfile(fileext = '.txt')
message(my_tempfile)

#' 
#' Note que o nome do arquivo -- `r basename(my_te
#' 
#' 
#' ### Baixando Arquivos da Internet
#' 
#' O R pode baixar arquivos da Internet diretament
#' 
## ------------------------------------------------------------------------------------------------------------
# set link
link_dl <- 'go.microsoft.com/fwlink/?LinkID=521962'
local_file <- tempfile(fileext = '.xlsx') # name of local file

download.file(url = link_dl,
              destfile = local_file)


#' 
#' O uso de `download.file` é bastante prático qua
#' 
#' Um exemplo nesse caso é a tabela de empresas li
#' 
## ------------------------------------------------------------------------------------------------------------
library(readr)
library(dplyr)

# set destination link and file
my_link <- 'http://sistemas.cvm.gov.br/cadastro/SPW_CIA_ABERTA.ZIP'
my_destfile <- tempfile(fileext = '.zip')

# download file
download.file(my_link, 
              destfile = my_destfile, 
              mode="wb")

# read it
df_cvm <- read_delim(my_destfile,
                     delim = '\t',
                     locale = locale(encoding = 'Latin1'),
                     col_types = cols())

# check available columns
print(names(df_cvm))

#' 
#' Existem diversas informações interessantes nest
#' 
#' 
#' ## Exercícios {#exerc-operacoes-basicas}
#' 
## ---- echo=FALSE, results='asis'-----------------------------------------------------------------------------
f_in <- list.files('../02-EOCE-Rmd//Cap02-Operações-Básicas/', 
                   full.names = TRUE)

build_exercises(f_in, type_doc = my_engine)

#' 