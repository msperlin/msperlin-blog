#' # Visualizando Dados {#figuras}
#' 

#' 
#' O uso de recursos gráficos em relatórios técnic
#' 
#' Essa deficiência foi sanada por Hadley Hickman,
#' 
#' Neste livro, não pretendemos entrar a fundo na 
#' 
#' Para todos os exemplos dados aqui, iremos traba
#' 
## ------------------------------------------------------------------------------------------------------------
library(dplyr)
library(readr)

# set files and column types
my_f <- adfeR::get_data_file('IbovStocks_long.csv')

# read file
my_df <- read_csv(my_f,
                  col_types = cols())

glimpse(my_df)

#' 
#' Para criar uma nova coluna com os retornos arit
#' 
## ------------------------------------------------------------------------------------------------------------
calc_ret <- function(P, tickers = rep('ticker', length(P))) {
  # calculates arithmetic returns from a vector of prices
  #
  # Args:
  #   P - vector of prices (numeric)
  #   tickers - vector of tickers (optional)
  #
  # Returns:
  #   A vector of returns

  # ret = p_{t}/p_{t-1} - 1

  my_length <- length(P)
  ret <- c(NA, P[2:my_length]/P[1:(my_length - 1)] - 1)

  idx <- (tickers != dplyr::lag(tickers))
  ret[idx] <- NA

  return(ret)
}

#' 
#' E adicionamos ao `dataframe`:
#' 
## ------------------------------------------------------------------------------------------------------------
my_df <- my_df %>%
  mutate(ret = calc_ret(price.adjusted, ticker)) %>%
  glimpse()

#' 
#' Pronto. Com base nos dados em `my_df`, partimos
#' 
#' 
#' ## Criando Janelas de Gráficos com `x11`
#' 
#' Antes de apresentar os códigos para a criação d
#' 
#' Uma abordagem mais inteligente para a criação d
#' 
## ---- eval=FALSE---------------------------------------------------------------------------------------------
## x11()
## plot(1:10)

#' 
#' O resultado na tela do RStudio deve ser algo pr
#' 

#' 
#' Depois de criar tantos janelas no R, é importan
#' 
#' 
#' ## Criando Figuras com `qplot`
#' 
#' O pacote `ggplot2` possui uma função que imita 
#' 
#' Por exemplo, caso formos construir um gráfico d
#' 
## ----eval=TRUE, fig.height=my_fig_height, fig.width=my_fig_width---------------------------------------------
library(ggplot2)
library(dplyr)

# filter stock data
temp_df <- my_df %>%
    filter(ticker == 'PETR4')

# plot its prices
qplot(data = temp_df,
      x = ref.date,
      y = price.adjusted,
      geom = 'line')

#' 
#' Observe que, no exemplo anterior, os nomes dos 
#' 
## ----fig.height=my_fig_height, fig.width=my_fig_width--------------------------------------------------------
qplot(data = temp_df,
      x = ref.date,
      y = price.adjusted,
      geom = 'line',
      main = 'Preços de PETR4',
      xlab = 'Datas', 
      ylab = 'Preços')

#' 
#' Destaca-se que o eixo horizontal de datas na fi
#' 
#' 
#' ## Criando Figuras com `ggplot`
#' 
#' O uso do `qplot` é recomendado para uma visuali
#' 
#' Antes de apresentarmos exemplos de uso de `ggpl
#' 
#' Essa distinção entre as etapas de formação de f
#' 
#' Veja a sintaxe do código no exemplo a seguir, o
#' 
## ----fig.height=my_fig_height, fig.width=my_fig_width--------------------------------------------------------
p <- ggplot(data = temp_df, aes(x = ref.date, y = price.adjusted))  
p <- p + geom_line() 
p <- p + labs(x = 'Datas', y = 'Preços', title  = 'Preços da PETR4')

print(p)

#' 
#' No uso da função `ggplot`, o argumento `data` é
#' 
#' Após a definição dos dados, temos o uso da funç
#' 
#' Observa-se que, na primeira linha do código ant
#' 
## ------------------------------------------------------------------------------------------------------------
library(ggplot2)
library(stringr)

# get names of functions in ggplot2
fcts <- ls('package:ggplot2')

# select those that starts with geom_
idx <- str_sub(fcts, 1, 5) == 'geom_'
fcts <- fcts[idx]

# print result
print(fcts)

#' 
#' Como visto, temos muitas opções. Iremos explora
#' 
#' Voltando ao exemplo, a terceira linha do código
#' 
#' O uso do _pipeline_ também é possível. Para exe
#' 
## ---- eval=FALSE---------------------------------------------------------------------------------------------
## p <- temp_df %>%
##   ggplot(aes(x = ref.date, y = price.adjusted)) +
##   geom_line() +
##   labs(x = 'Datas', y = 'Preços')
## 
## print(p)

#' 
#' Note que usamos `+` e não `%>%` para interligar
#' 
## Cuidado ao misturar os operadores. Sempre que estiver passando tabelas entre comandos do `dplyr`, use o operador `%>%`. Para o caso de sequenciamento de camadas de um gráfico do `ggplot`, use sempre o sýmbolo de soma (`+`).

#' 
#' O uso do comando `ggplot` mostra as suas vantag
#' 
## ----eval=TRUE-----------------------------------------------------------------------------------------------
# fix seed
set.seed(100)

# select 4 stocks randomly
my_tickers <- sample(unique(my_df$ticker), 4)

# filter df for all rows that contain the stocks
temp_df <- filter(my_df, ticker %in% my_tickers)

#' 
#' Nesse código, utilizamos o operador `%in%` e `f
#' 
## ----fig.height=my_fig_height, fig.width=my_fig_width--------------------------------------------------------
p <- temp_df %>%
  ggplot(aes(x = ref.date, y = price.adjusted, color=ticker)) +
  geom_line() +
  labs(x = 'Datas', y = 'Preços', title = 'Preços de Ações da B3')

print(p)

#' 
#' A diferença para o exemplo anterior é que usamo
#' 
#' 
#' ### A Curva de Juros Brasileira
#' 
#' Agora, vamos usar o que aprendemos até aqui par
#' 
## ------------------------------------------------------------------------------------------------------------
library(GetTDData)
library(dplyr)

# get BR yield curve
df_yield_curve <- get.yield.curve()

# check it
glimpse(df_yield_curve)

#' 
#' Felizmente, os dados já estão organizados no fo
#' 
## ------------------------------------------------------------------------------------------------------------
p <- df_yield_curve %>%
  ggplot(aes(x = ref.date, y = value, color = type, linetype = type)) +
  geom_line(size = 1) +
  labs(x = 'Datas', y = 'Taxas de Retorno', 
       title = 'Curva de Juros Brasileira',
       subtitle = paste0('Dados obtidos em ', Sys.Date()) )

print(p)

#' 
#' O gráfico resultante não está ideal, a curva de
#' 
#' 
#' ### Usando Temas
#' 
#' Caso estejas pouco satisfeito com as cores esco
#' 
## ------------------------------------------------------------------------------------------------------------
library(ggplot2)
library(stringr)

# get all functions
fcts <- ls('package:ggplot2')

# find out those that start with theme_
idx <- str_sub(fcts, 1, 6) == 'theme_'
fcts <- fcts[idx]

# print result
print(fcts)

#' 
#' Vamos dar um exemplo de uso com `theme_bw`. Do 
#' 
#' 
## ------------------------------------------------------------------------------------------------------------
set.seed(15)

# get assets
p <- temp_df %>%
  ggplot(aes(x = ref.date, y = price.adjusted, color = ticker)) +
  geom_line() +
  labs(x = 'Datas', y = 'Preços', title = 'Preços de Ações da B3') +
  theme_bw()

print(p)

#' 
#' Como você pode ver, o novo tema define um fundo
#' 
#' Para explorar os demais temas, usaremos o pacot
#' 
## ---- fig.height=9 , fig.width = 9, message=FALSE------------------------------------------------------------
require(gridExtra)

p1 <- p + 
  theme_bw() + 
  labs(title = 'Theme BW')

p2 <- p + 
  theme_dark() + 
  labs(title = 'Theme Dark')

p3 <- p + 
  theme_grey() + 
  labs(title = 'Theme Grey')

p4 <- p + 
  theme_light() + 
  labs(title = 'Theme Light')

p5 <- p + 
  theme_classic() + 
  labs(title = 'Theme Classic')

p6 <- p + 
  theme_minimal() + 
  labs(title = 'Theme Minimal')

grid.arrange(p1, p2, p3,
             p4, p5, p6,
             ncol=2, nrow = 3)

#' 
#' Você pode testar outros temas em seu computador
#' 
#' No exemplo anterior, observe como a estrutura d
#' 
## ---- fig.height=my_fig_height, fig.width=my_fig_width-------------------------------------------------------
p <- temp_df %>%
  ggplot(aes(x = ref.date, y = price.adjusted, color = ticker)) +
  geom_line() +
  labs(x = 'Datas', y = 'Preços', title = 'Preços de Ações da B3') +
  theme_bw() +
  scale_colour_grey(start = 0.0, end = 0.8)

print(p)

#' 
#' A figura agora está no formato preto e branco, 
#' 
#' 
#' ### Criando Painéis com `facet_wrap` {#facets}
#' 
#' Outra possibilidade para produzir figuras de gr
#' 
#' Essa operação é executada com o uso da função `
#' 
## ---- fig.height=my_fig_height, fig.width=my_fig_width-------------------------------------------------------
p <- temp_df %>%
  ggplot(aes(x = ref.date, y = price.adjusted)) +
  geom_line() +
  labs(x = 'Datas', y = 'Preços', title = 'Preços de Ações da B3') +
  facet_wrap(~ticker)

print(p)

#' 
#' O uso de painéis é recomendado quando os dados 
#' 
## ----fig.height=my_fig_height, fig.width=my_fig_width--------------------------------------------------------
p <- temp_df %>%
  ggplot(aes(x = ref.date, y = ret)) +
  geom_line() +
  labs(x = 'Datas', y = 'Retornos', title = 'Preços de Ações da B3') +
  facet_wrap(~ticker)

print(p)

#' 
#' Vale destacar que o eixo vertical dos painéis é
#' 
## ----fig.height=my_fig_height, fig.width=my_fig_width--------------------------------------------------------
p <- temp_df %>%
  ggplot(aes(x = ref.date, y = ret)) +
  geom_line() +
  labs(x = 'Datas', y = 'Retornos',
       title = 'Preços de Ações da B3') +
  facet_wrap(~ticker, scales = 'free')

print(p)

#' 
#' Note que agora cada grupo de dados possui seus 
#' 
#' Voltando ao exemplo da curva de juros Brasileir
#' 
## ------------------------------------------------------------------------------------------------------------
p <- df_yield_curve %>%
  ggplot(aes(x = ref.date, y = value, color = type)) +
  geom_line() +
  labs(x = 'Datas', y = 'Taxas de Retorno', 
       title = 'Curva de Juros Brasileira',
       subtitle = paste0('Dados obtidos em ', Sys.Date())) +
  facet_wrap(~type, scale = 'free') + 
  theme_bw()

print(p)

#' 
#' Como podemos ver, é mais fácil de analisar o fo
#' 
#' 
#' ## Uso do Operador _pipeline_
#' 
#' Como já vimos anteriormente, a função `ggplot` 
#' 
## ---- eval=TRUE, tidy=FALSE,fig.height=my_fig_height, fig.width=my_fig_width---------------------------------
library(dplyr)
library(readr)
library(ggplot2)

# import data, calculate mean and sd of returns, plot result
my_f <- adfeR::get_data_file(
  'SP500_Stocks_long_by_year.rds'
  )
p <- read_rds(file = my_f) %>%
  mutate(ret = calc_ret(price.adjusted, ticker)) %>%
  na.omit(.) %>%
  group_by(ticker) %>%
  summarise(mean_ret = mean(ret),
            std.ret = sd(ret)) %>%
  ggplot(aes(x = std.ret, y = mean_ret)) +
  geom_point() +
  labs(x = 'Standard deviation of returns',
       y = 'Average Returns') + 
  theme_bw()


print(p)

#' 
#' O código anterior é autocontido, fácil de ler e
#' 
#' Este é outro exemplo de um código elegante que 
#' 
#' 
#' ## Criando Figuras Estatísticas
#' 
#' Pacote `ggplot2` inclui diversas opções para cr
#' 
#' 
#' ### Criando Histogramas
#' 
#' Um histograma mostra a distribuição empírica do
#' 
## ----fig.height=my_fig_height, fig.width=my_fig_width--------------------------------------------------------
p <- temp_df %>%
  na.omit(.) %>%
  ggplot(aes(x = ret)) +
  geom_histogram(bins = 50)

print(p)

#' 
#' Observa-se que, nesse caso, define-se apenas um
#' 
#' Para o caso de diferentes grupos de dados, o us
#' 
## ----fig.height=my_fig_height, fig.width=my_fig_width--------------------------------------------------------
# fix seed
set.seed(15)

# select 4 stocks randomly
my_tickers <- sample(unique(my_df$ticker), 4)

p <- my_df %>%
  na.omit(.) %>%
  filter(ticker %in% my_tickers) %>%
  ggplot(aes(x = ret)) +
  geom_histogram(bins = 50) +
  facet_wrap(facets = ~ticker, scales = 'free')

print(p)

#' 
#' Também é possível a criação de densidades a par
#' 
## ----fig.height=my_fig_height, fig.width=my_fig_width--------------------------------------------------------
# fix seed
set.seed(15)

# select 4 stocks randomly
my_tickers <- sample(unique(my_df$ticker), 4)

p <- my_df %>%
  na.omit(.) %>%
  filter(ticker %in% my_tickers) %>%
  ggplot(aes(x = ret)) +
  geom_density() +
  facet_wrap(facets = ~ticker, scales = 'free_x')

print(p)

#' 
#' A figura anterior permite uma comparação visual
#' 
#' 
#' ### Criando Figuras _Boxplot_
#' 
#' As figuras do tipo _boxplots_ (ou diagrama _box
#' 
## ----eval=TRUE, fig.height=my_fig_height, fig.width=my_fig_width, tidy=FALSE---------------------------------
# fix seed
set.seed(35)

# select 4 stocks randomly
my_tickers <- sample(unique(my_df$ticker), 4)

p <- my_df %>%
  filter(ticker %in% my_tickers) %>%
  ggplot(aes(x = ticker, y = price.adjusted)) +
  geom_boxplot()

print(p)

#' 
#' No exemplo anterior, bastou definir o eixo hori
#' 
#' 
#' ### Criando Figuras _QQ_
#' 
#' Figuras do tipo _QQ_ permitem a comparação visu
#' 
#' Veja um exemplo com dados simulados.
#' 
## ----fig.height=my_fig_height, fig.width=my_fig_width--------------------------------------------------------
# fix seed
set.seed(40)

N=1000
my_mean <- 10
my_sd <- 2

# build sim data
temp_df <- data.frame(y=rnorm(n = N, mean = my_mean, sd = my_sd))

# create qq plot
p <- temp_df %>%
  ggplot(aes(sample = y)) +
  geom_qq(distribution = qnorm,
                 dparams = c(mean=my_mean, sd=my_sd))

print(p)

#' 
#' Simulamos variáveis aleatórias normais com médi
#' 
#' Agora, vamos tentar essa análise para o nosso c
#' 
## ----eval=TRUE,fig.height=my_fig_height, fig.width=my_fig_width, tidy=FALSE----------------------------------
# fix seed
set.seed(45)

# select 4 stock randomly and filter from my_df
my_tickers <- sample(unique(my_df$ticker), 4)
temp_df <- filter(my_df, ticker %in% my_tickers)

# set function for normalization
norm_vec <- function(ret_in){
  # Normalizes a vector by subtracting mean and dividing
  # by the standard deviation
  #
  # Args:
  #   ret_in - numerical vector
  #
  # Returns:
  #   A normalized vector

  mean_ret <- mean(ret_in, na.rm = TRUE)
  sd_ret <- sd(ret_in, na.rm = TRUE)

  ret.norm <- (ret_in-mean_ret)/sd_ret
  return(ret.norm)
}

# apply function
my_l <- tapply(X = temp_df$ret,
               INDEX = factor(temp_df$ticker),
			   FUN = norm_vec)

# reorder list (tapply sorts alphabetically)
my_l <- my_l[as.character(unique(temp_df$ticker))]

# save new column norm_ret
temp_df$norm_ret <- unlist(my_l)

# plot it!
p <- temp_df %>%
  ggplot(aes(sample = norm_ret)) +
  geom_qq() + facet_wrap(~ticker, scales = 'free_y')

print(p)

#' 
#' 
#' Como podemos ver, o resultado não é visualmente
#' 
#' 
#' ## Salvando Figuras para Arquivos
#' 
#' Utilizamos a função `ggsave` para salvar figura
#' 
## ----fig.height=my_fig_height, fig.width=my_fig_width, warning=FALSE-----------------------------------------
p <- temp_df %>%
  ggplot(aes(x = ref.date, y = price.adjusted, color=ticker)) +
  geom_line() +
  labs(x = 'Datas', y = 'Preços')

my_fig_file <- '00-text-resources/fig_ggplot/MyPrices.png'
ggsave(filename = my_fig_file,
       plot = p,
       dpi = 600)

#' 
#' Pode-se verificar a criação do arquivo com o co
#' 
## ------------------------------------------------------------------------------------------------------------
print(list.files('00-text-resources/fig_ggplot'))

#' 
#' Como esperado, o arquivo criado está lá, pronto
#' 
#' ## Exercícios {#exerc-figuras}
#' 
## ---- echo=FALSE, results='asis'-----------------------------------------------------------------------------
f_in <- fs::dir_ls('../02-EOCE-Rmd//Cap10-Figuras/', 
                   type = 'file')

build_exercises(f_in, type_doc = my_engine)

#' 