#' # Econometria Financeira com o R {#modelos}
#' 

#' 
#' As ferramentas da Econometria permitem ao pesqu
#' 
#' A variedade e quantidade de modelos utilizados 
#' 
#' - Modelos lineares (OLS)
#' - Modelos lineares generalizados (GLS)
#' - Modelos de dados do painel
#' - Modelos ARIMA (médias móveis autoregressivas 
#' - Modelos GARCH (heterocedasticidade condiciona
#' - Modelos de mudança de regimes markovianos
#' 
#' Não apresentaremos a completa descrição da teor
#' 
#' 
#' ## Modelos Lineares (OLS)
#' 
#' Um modelo linear é, sem dúvida, o tipo de espec
#' 
#' Particularmente em Finanças, o uso mais direto 
#' 
#' Um modelo linear com _N_ variáveis explicativas
#' 

#' 

#' 
#' O lado esquerdo da equação, (`r if (my_engine!=
#' 
#' 
#' ### Simulando um Modelo Linear
#' 
#' Considere a seguinte equação:
#' 

#' 

#' 
#' Podemos usar o R para simular _1000_ observaçõe
#' 
## ------------------------------------------------------------------------------------------------------------
set.seed(50)

# number of obs
n_row <- 1000

# set x as Normal (0, 1)
x <- rnorm(n_row)

# set coefficients
my_alpha <- 0.5
my_beta <- 2

# build y
y <- my_alpha + my_beta*x + rnorm(n_row)

#' 
#' Usando `ggplot2:ggplot`, podemos criar um gráfi
#' 
## ---- fig.height=my_fig_height, fig.width=my_fig_width-------------------------------------------------------
library(ggplot2)

# set temp df
temp_df <- tibble(x, y)

# plot it
p <- ggplot(temp_df, aes(x = x, y = y)) +
  geom_point(size=0.5)

print(p)

#' 
#' Claramente há uma correlação linear positiva; u
#' 
#' 
#' ### Estimando um Modelo Linear {#estimating-ols
#' 
#' A principal função para estimar um modelo linea
#' 
## ------------------------------------------------------------------------------------------------------------
# set df
lm_df <- tibble(x, y)

# estimate linear model
my_lm <- lm(data = lm_df, formula = y ~ x)
print(my_lm)

#' 
#' O argumento `formula` define o formato do model
#' 
#' Argumento `formula` permite outras opções perso
#' 
## ------------------------------------------------------------------------------------------------------------
set.seed(15)

# set simulated dataset
N <- 100
df <- tibble(x = runif(N),
             y = runif(N),
             z = runif(N),
             group = sample(LETTERS[1:3],
                            N,
                            replace = TRUE ))

# Vanilla formula
#
# example: y ~ x + z
# model: y(t) = alpha + beta(1)*x(t) + beta(2)*z(t) + error(t)
my_formula <- y ~ x + z
print(lm(data = df,
         formula = my_formula))

# Vannila formula with dummies
#
# example: y ~ group + x + z
# model: y(t) = alpha + beta(1)*D_1(t)+beta(2)*D_2(t) +
#               beta(3)*x(t) + beta(4)*z(t) + error(t)
# D_i(t) - dummy for group i
my_formula <- y ~ group + x + z
print(lm(data = df,
         formula = my_formula))

# Without intercept
#
# example: y ~ -1 + x + z
# model: y(t) = beta(1)*x(t) + beta(2)*z(t) + error(t)
my_formula <- y ~ -1 + x + z
print(lm(data = df,
         formula = my_formula))

# Using combinations of variables
# example: y ~ x*z
# model: y(t) = alpha + beta(1)*x(t) + beta(2)*z(t) +
#               beta(3)*x(t)*z(t) + error(t)
my_formula <- y ~ x*z
print(lm(data = df,
         formula = my_formula))

# Interacting variables
# example: y ~ x:group + z
# model: y(t) = alpha + beta(1)*z(t) + beta(2)*x(t)*D_1(t) +
#               beta(3)*x(t)*D_2(t) + beta(4)*x(t)*D_3(t) +
#               error(t)
# D_i(t) - dummy for group i
my_formula <- y ~ x:group + z
print(lm(data = df,
         formula = my_formula))


#' 
#' As diferentes opções na entrada `formula` permi
#' 
#' A saída da função `lm` é um objeto semelhante a
#' 
## ------------------------------------------------------------------------------------------------------------
# print names in model
print(names(my_lm))

#' 
#' Todos os coeficientes estimados são armazenados
#' 
## ------------------------------------------------------------------------------------------------------------
print(my_lm$coefficients)

#' 
#' No nosso exemplo de usar `lm` com dados simulad
#' 
#' Pesquisadores experientes provavelmente devem t
#' 
## ------------------------------------------------------------------------------------------------------------
print(summary(my_lm))

#' 

#' 
#' Os coeficientes estimados têm elevados valores 
#' 
#' Informações adicionais estão disponíveis no obj
#' 
## ------------------------------------------------------------------------------------------------------------
my_summary <- summary(my_lm)
print(names(my_summary))

#' 
#' Cada um desses elementos contém informações que
#' 
#' Agora, vamos passar para um exemplo com dados r
#' 

#' 

#' 
#' Primeiro, vamos carregar e ajustar os dados.
#' 
## ------------------------------------------------------------------------------------------------------------
# load stock data
library(tidyverse)

my_f <- adfeR::get_data_file(
  'IbovStocks_long.csv'
)

my_df <- read_csv(my_f, col_types = cols())

# select rnd asset and filter data
set.seed(10)

my_asset <- sample(my_df$ticker, 1)
my_df_asset <- my_df[my_df$ticker == my_asset, ]

# load Ibov data
my_f <- adfeR::get_data_file(
  'Ibov.csv'
)
df_ibov <- read_csv(file = my_f,
                    col_types = cols())

# calculate return for
df_ibov$ret <- calc_ret(df_ibov$price.close)
my_df_asset$ret <- calc_ret(my_df_asset$price.adjusted,
                            my_df_asset$ticker)

# print number of rows in datasets
print(nrow(my_df_asset))
print(nrow(df_ibov))

#' 
#' Destaca-se que o número de linhas do conjunto d
#' 
## ------------------------------------------------------------------------------------------------------------
# find location of dates
idx <- match(my_df_asset$ref.date, df_ibov$ref.date)

# create column in my_df
my_df_asset$ret_ibov <- df_ibov$ret[idx]

#' 
#' Como um começo, vamos criar o gráfico de disper
#' 
## ---- fig.height=my_fig_height, fig.width=my_fig_width-------------------------------------------------------
library(ggplot2)

p <- my_df_asset %>%
  na.omit(.) %>%
  ggplot(aes(x=ret_ibov, y= ret)) +
  geom_point() +
  geom_smooth(method = 'lm')

print(p)

#' 
#' A figura mostra uma clara tendência linear. O r
#' 
## ------------------------------------------------------------------------------------------------------------
# estimate beta model
my_beta_model <- lm(data = my_df_asset,
                    formula = ret ~ ret_ibov)

# print it
print(summary(my_beta_model))

#' 

#' 
#' O resultado anterior mostra que a ação `r my_as
#' 
#' 
#' ### Inferência Estatística em Modelos Lineares 
#' 
#' Depois de estimar um modelo com a função `lm`, 
#' 
## ------------------------------------------------------------------------------------------------------------
n_row <- 100
df <- tibble(y = runif(n_row),
             x_1 = runif(n_row),
             x_2 = runif(n_row))

my_lm <- lm(data = df,
            formula = y ~ x_1 + x_2)

print(summary(my_lm))

#' 
#' A estatística F do modelo estimado resulta em `
#' 
#' Outro tipo de teste executado automaticamente p
#' 
#' Na prática da pesquisa, é provável que ambos os
#' 
#' Como um exemplo simples, vamos testar uma hipót
#' 
## ------------------------------------------------------------------------------------------------------------
set.seed(10)

# number of time periods
n_row <- 1000

# set parameters
my_intercept <- 0.5
my_beta <- 1.5

# simulate
x <- rnorm(n_row)
y <- my_intercept + my_beta*x + rnorm(n_row)

# set df
df <- tibble(y, x)

# estimate model
my_lm <- lm(data = df,
            formula = y ~ x )

#' 
#' Após a estimação do modelo, usamos função `Line
#' 

#' 

#' 
#' Com essa operação de matriz, testamos a hipótes
#' 
## ------------------------------------------------------------------------------------------------------------
library(car)

# set test matrix
test_matrix <- matrix(c(my_intercept,  # alpha test value
                        my_beta))  # beta test value

# hypothesis matrix
hyp_mat <- matrix(c(1,0,
                    0,1),nrow = 2)

# do test
my_waldtest <- linearHypothesis(my_lm,
                                hypothesis.matrix = hyp_mat,
                                rhs = test_matrix)

# print result
print(my_waldtest)

#' 
#' Como podemos ver, o teste falha na rejeição da 
#' 
#' Outra família de testes comumente aplicada a mo
#' 
#' No R, podemos usar o pacote `lmtest` [@lmtest] 
#' 
## ---- results='hold'-----------------------------------------------------------------------------------------
library(lmtest)

# Breush Pagan test 1 - Serial correlation
# Null Hypothesis: No serial correlation in residual
print(bgtest(my_lm, order = 5))

# Breush Pagan test 2 - Homocesdasticity of residuals
# Null Hypothesis: homocesdasticity
#                  (constant variance of residuals)
print(ncvTest(my_lm))

# Durbin Watson test - Serial correlation
# Null Hypothesis: No serial correlation in residual
print(dwtest(my_lm))

# Shapiro test  - Normality
# Null Hypothesis: Data is normally distributed
print(shapiro.test(my_lm$residuals))

#' 
#' Como esperado, o modelo com dados artificiais p
#' 
#' Outra abordagem interessante para validar model
#' 
## ------------------------------------------------------------------------------------------------------------
library(gvlma)

# global validation of model
gv_model <- gvlma(my_lm)

# print result
summary(gv_model)

#' 
#' A saída de `gvlma` mostra vários testes realiza
#' 
#' 
#' ## Modelos Lineares Generalizados (GLM)
#' 
#' O modelo linear generalizado (GLM) é uma altern
#' 
#' Podemos escrever uma especificação GLM univaria
#' 

#' 

#' 
#' A principal diferença de um modelo GLM a um mod
#' 

#' 

#' 
#' Observe que, nesse caso, função _g()_ garante q
#' 
#' 
#' ### Simulando um Modelo GLM
#' 
#' Como exemplo, vamos simular o seguinte modelo G
#' 
#' 

#' 

#' 
#' Voltando ao R, usamos o seguinte código para co
#' 
## ------------------------------------------------------------------------------------------------------------
set.seed(15)

# set number of obs
n_row <- 500

# set x
x = rnorm(n_row)

my_alpha <- 2
my_beta <- 5

# set probabilities
z = my_alpha + my_beta*x
p = exp(z)/(1+exp(z))

# set response variable
y = rbinom(n = n_row, size = 1, prob = p)

#' 
#' Função `rbinom` cria um vetor de 1s e 0s, com b
#' 
#' 
## ------------------------------------------------------------------------------------------------------------
# check distribution of y
summary(y)

#' 
#' Objeto `y` contém apenas 0s e 1s, como esperado
#' 
#' 
#' ### Estimando um Modelo GLM
#' 
#' No R, a estimativa de modelos GLM é realizada c
#' 
#' Primeiro, vamos usar os dados previamente simul
#' 
## ------------------------------------------------------------------------------------------------------------
# create df
df <- tibble(y = y, x = x)

# estimate GLM
my_glm <- glm(data=df,
              formula = y~x ,
              family= binomial(link = "logit"))

# print it with summary
print(summary(my_glm))

#' 
#' Os coeficientes estimados são próximos do que d
#' 
#' A função `glm` oferece muitas opções para confi
#' 

#' 
#' O primeiro passo no uso de um modelo GLM é iden
#' 
#' Como exemplo com dados reais dos mercados finan
#' 
## ------------------------------------------------------------------------------------------------------------
set.seed(15)

# select stock
my_ticker <- sample(unique(my_df$ticker), 1)
my_df_asset <- my_df[my_df$ticker == my_ticker, ]

# calc ret
my_df_asset <- my_df_asset %>%
  mutate(ret = calc_ret(price.adjusted, ticker))

# find location of dates
idx <- match(my_df_asset$ref.date, 
             df_ibov$ref.date)

# create column in my_df
my_df_asset$ret_ibov <- df_ibov$ret[idx]

# set column with dummy variable
my_df_asset$D_ret <- my_df_asset$ret > 0

# estimate model
my_glm <- glm(data=my_df_asset,
              formula = D_ret~ret_ibov ,
              family= binomial(link = "probit"))

print(summary(my_glm))

#' 
#' Como esperado, o parâmetro para o índice de mer
#' 
#' 
#' ## Modelos para Dados em Painel
#' 
#' Os modelos de dados em painel são aconselhados 
#' 
#' A principal motivação para usar essa classe de 
#' 
#' Podemos representar o caso mais simples de um m
#' 

#' 

#' 
#' Observe que agora usamos índice _i_ nas variáve
#' 
#' 
#' ### Simulando Dados em Painel
#' 
#' Vamos simular um painel balanceado com efeitos 
#' 
#' 
## ------------------------------------------------------------------------------------------------------------
library(dplyr)

set.seed(25)

# number of obs for each case
n_row <- 5

# set number of groups
N <- 12

# set possible cases
possible_cases <- LETTERS[1:N]

# set parameters
my_alphas <- seq(-10,10,length.out = N)
my_beta <- 1.5

# set indep var (x) and dates
indep_var <- sapply(rep(n_row,N), rnorm)
my_dates <- Sys.Date() + 1:n_row

# create response matrix (y)
response_matrix <- matrix(rep(my_alphas,n_row),
                          nrow = n_row,
                          byrow = TRUE) +
  indep_var*my_beta + sapply(rep(n_row,N),rnorm, sd = 0.25)

# set df
sim_df <- tibble(G = as.character(sapply(possible_cases,
                                         rep,
                                         times=n_row )),
                 dates = rep(my_dates, times=N),
                 y = as.numeric(response_matrix),
                 x = as.numeric(indep_var))

# check result
glimpse(sim_df)

#' 
#' O resultado é um objeto dataframe com `r nrow(s
#' 
## ---- fig.height=my_fig_height, fig.width=my_fig_width-------------------------------------------------------
library(ggplot2)

p <- ggplot(sim_df, aes(x=x, y=y)) +
  geom_point() + geom_line()+ facet_wrap(~G)

print(p)

#' 
#' A figura mostra o forte relacionamento linear e
#' 
#' 
#' ### Estimando Modelos de Dados em Painel
#' 
#' Com os dados artificiais simulados no passo ant
#' 
## ---- message=FALSE------------------------------------------------------------------------------------------
library(plm)

# estimate panel data model with fixed effects
my_plm <- plm(data = sim_df,
              formula = y ~ x,
              model = 'within',
              index = c('G','dates'))

# print result
print(summary(my_plm))

#' 
#' Como esperado, os parâmetros foram recuperados 
#' 
## ------------------------------------------------------------------------------------------------------------
print(fixef(my_plm))

#' 
#' Mais uma vez, os valores simulados de intercept
#' 
## ------------------------------------------------------------------------------------------------------------
par_df <- tibble(real_alpha = my_alphas,
                 estimated_alpha = fixef(my_plm),
                 perc_diff = (estimated_alpha-real_alpha)/
                   real_alpha)

print(par_df)

#' 
#' Observe como as diferenças percentuais entre os
#' 
#' Como um exemplo no mundo real, vamos usar o con
#' 
## ---- message=FALSE------------------------------------------------------------------------------------------
my_f <- adfeR::get_data_file('grunfeld.csv')

df_grunfeld <- read_csv(my_f, col_types = cols())

# print it
glimpse(df_grunfeld)

#' 
#' Uma nota aqui é importante, dado o elevado núme
#' 
#' Primeiro, vamos explorar os dados brutos estima
#' 
#' 
## ------------------------------------------------------------------------------------------------------------
my_fct <- function(df) {
  # Estimates a linear model from Grunfeld data
  #
  # Args:
  #   df - dataframe from Grunfeld
  #
  # Returns:
  #   lm object
  
  my_model <- lm(data = df,
                 formula = I ~  F + C)
  
  return(my_model)
}

# estimate model for each firm
my_l <- by(df_grunfeld,
           INDICES = df_grunfeld$FIRM,
           FUN = my_fct)

# print result
my_coefs <- sapply(my_l, coef)
print(my_coefs)

#' 

#' 
#' Os resultados mostram uma grande discrepância e
#' 
## ------------------------------------------------------------------------------------------------------------
# test if all coef are the same across firms
my_pooltest <- pooltest(I~ F + C,
                        data = df_grunfeld,
                        model = "pooling")

# print result
print(my_pooltest)

#' 
#' O alto valor do teste F e o pequeno valor de _p
#' 
#' Antes de estimar o modelo, precisamos entender 
#' 
#' Podemos testar a especificação do modelo usando
#' 
## ------------------------------------------------------------------------------------------------------------
# set options for Hausman test
my_formula <- I ~ F + C
my_index <- c('FIRM','YEAR')

# do Hausman test
my_hausman_test <- phtest(x = my_formula,
                          data = df_grunfeld,
                          model = c('within', 'random'),
                          index = my_index)

# print result
print(my_hausman_test)

#' 
#' O valor de _p_ igual a `r format(my_hausman_tes
#' 
#' Depois de identificar o modelo, vamos estimá-lo
#' 
## ------------------------------------------------------------------------------------------------------------
# set panel data model with random effects
my_model <- 'random'
my_formula <- I ~ F + C
my_index <- c('FIRM','YEAR')

# estimate it
my_plm_random <- plm(data = df_grunfeld,
                     formula = my_formula,
                     model = my_model,
                     index = my_index)

# print result
print(summary(my_plm_random))

#' 

#' 
#' Como esperado, os coeficientes são estatisticam
#' 
#' Como último exemplo para os dados de `Grunfeld`
#' 
#' O pacote `systemfit` oferece uma função com o m
#' 
## ---- message=FALSE------------------------------------------------------------------------------------------
library(systemfit)

# set pdataframe
p_grunfeld <- pdata.frame(df_grunfeld, c( "FIRM", "YEAR" ))

# estimate sur
my_SUR <- systemfit(formula = I ~ F + C,
                    method =  "SUR",
                    data = p_grunfeld)
print(my_SUR)

#' 
#' O objeto de saída contém a estimativa de todas 
#' 
#' 
#' ## Modelos ARIMA
#' 
#' A especificação ARIMA (_AutoRegressive Integrat
#' 
#' Um exemplo simples de um modelo ARIMA é definid
#' 
#' 

#' 

#' 
#' Neste exemplo, temos um modelo ARIMA(AR=1, D=0,
#' 
#' 
#' ### Simulando Modelos ARIMA
#' 
#' Em primeiro lugar, vamos simular um modelo ARIM
#' 
## ------------------------------------------------------------------------------------------------------------
set.seed(1)

# set number of observations
my_N <- 5000

# set model's parameters
my_model <- list(ar = 0.5, ma = -0.1)
my_sd <- 1

# simulate model
my_ts <- arima.sim(n = my_N,
                   model = my_model ,
                   sd = my_sd)

#' 
#' Podemos observar o resultado da simulação crian
#' 
## ---- tidy=FALSE---------------------------------------------------------------------------------------------
library(ggplot2)

# set df
temp_df <- tibble(y = unclass(my_ts),
                  date = Sys.Date() + 1:my_N)

p <- ggplot(temp_df, aes(x = date, y = y))
p <- p + geom_line(size=0.5)

print(p)

#' 
#' O gráfico mostra uma série de tempo com média p
#' 
#' 
#' ### Estimando Modelos ARIMA {#arima-estimating}
#' 
#' Para estimar um modelo ARIMA, usamos função `ar
#' 
## ------------------------------------------------------------------------------------------------------------
# estimate arima model
my_arima <- arima(my_ts, order = c(1,0,1))

# print result
print(coef(my_arima))

#' 
#' Como esperado, os parâmetros estimados estão pr
#' 
## ------------------------------------------------------------------------------------------------------------
print(summary(my_arima))

#' 
#' A identificação do modelo ARIMA, definindo valo
#' 
#' No próximo exemplo usamos função `auto.arima` p
#' 
## ------------------------------------------------------------------------------------------------------------
library(readr)

# load Ibov data
my_f <- adfeR::get_data_file('Ibov.csv')
df_ibov <- read_csv(file = my_f,
                    col_types = cols(ref.date = col_date(format = ""),
                                     price.close = col_integer()))

# calculate return for
df_ibov$ret <- calc_ret(df_ibov$price.close)

#' 
#' Antes de estimar o modelo, precisamos verificar
#' 
## ---- message=FALSE------------------------------------------------------------------------------------------
library(tseries)
print(adf.test(na.omit(df_ibov$ret)))

#' 
#' O resultado do teste mostra um pequeno valor da
#' 
## ---- message=FALSE------------------------------------------------------------------------------------------
print(adf.test(na.omit(df_ibov$price.close)))

#' 
#' Facilmente falhamos em rejeitar a hipótese nula
#' 
#' Indo em frente, função `forecast::auto.arima` p
#' 
## ------------------------------------------------------------------------------------------------------------
library(forecast)

# estimate arima model with automatic identification
my_auto_arima <- auto.arima(x = df_ibov$ret)

# print result
print(my_auto_arima)

#' 
#' O resultado nos diz que o melhor modelo para os
#' 
#' 
#' ### Prevendo Modelos ARIMA
#' 
#' Podemos obter as previsões de um modelo ARIMA c
#' 
## ------------------------------------------------------------------------------------------------------------
# forecast model
print(forecast(my_auto_arima, h = 5))

#' 
#' Note que a previsão em _t+k_ converge para um v
#' 
#' 
#' ## Modelos GARCH
#' 
#' Os modelos do tipo GARCH (_generalized autoregr
#' 
#' Os modelos GARCH tornaram-se muito populares na
#' 
#' Um modelo GARCH é modular. No formato mais simp
#' 
#' 

#' 

#' 
#' A equação para `r if (my_engine!='epub3') {'$y_
#' 
#' 
#' ### Simulando Modelos GARCH
#' 
#' O R não tem função nativa para simular e estima
#' 
#' Simulamos um modelo usando a função `fGarch::ga
#' 
## ---- tidy=FALSE, message=FALSE------------------------------------------------------------------------------
library(fGarch)

# set list with model spec
my_model = list(omega=0.001,
                alpha=0.15,
                beta=0.8,
                mu=0.02,
                ar = 0.1)

# set garch spec
spec = garchSpec(model = my_model)

# print it
print(spec)

#' 
#' O código anterior define um modelo GARCH equiva
#' 

#' 

#' 
#' Para simular _1000_ observações do modelo, usam
#' 
## ------------------------------------------------------------------------------------------------------------
set.seed(20)
# simulate garch model
sim_garch = garchSim(spec, n = 1000)

#' 
#' Podemos visualizar a série temporal gerada com 
#' 
## ---- eval=TRUE, tidy=FALSE, fig.height=my_fig_height, fig.width=my_fig_width--------------------------------
# set df for ggplot
temp_df <- tibble(sim.ret = sim_garch$garch,
                  idx=seq_along(sim_garch$garch))

library(ggplot2)
p <- ggplot(temp_df, aes(x=idx, y=sim.ret)) + 
  geom_line()

print(p)

#' 
#' O comportamento da série simulada é semelhante 
#' 
## ------------------------------------------------------------------------------------------------------------
plot(volatility(sim_garch))

#' 
#' Claramente podemos ver a instabilidade da volat
#' 
#' 
#' ### Estimando Modelos GARCH {#estimating-garch}
#' 
#' Os parâmetros de um modelo GARCH geralmente são
#' 
#' No exemplo a seguir estimamos um modelo GARCH p
#' 
## ------------------------------------------------------------------------------------------------------------
# estimate garch model
my_garchfit <- garchFit(data = sim_garch,
                        formula = ~ arma(1,0) + garch(1,1),
                        trace = FALSE)

#' 
#' Para aprender mais sobre o modelo estimado, o a
#' 
## ------------------------------------------------------------------------------------------------------------
print(my_garchfit)

#' 
#' Os parâmetros resultantes da estimação do model
#' 
#' Agora, vamos estimar um modelo GARCH para dados
#' 
#' 
## ------------------------------------------------------------------------------------------------------------
library(MTS)

# test for Arch effects
archTest(rt = na.omit(df_ibov$ret))

#' 
#' A evidência é forte para  efeitos Arch nos reto
#' 
## ------------------------------------------------------------------------------------------------------------
# set object for estimation
df_est <- as.timeSeries(na.omit(df_ibov))

# estimate garch model
my_garchfit_ibov <- garchFit(data = df_est ,
                             formula = ret ~ arma(1,0) + garch(1,1),
                             trace = FALSE)

print(my_garchfit_ibov)


#' 
#' Como esperado, todos os coeficientes GARCH (`om
#' 
#' 
#' ### Prevendo Modelos GARCH
#' 
#' A previsão de modelos GARCH envolve dois elemen
#' 
#' No pacote `fGarch`, ambas as previsões são calc
#' 
## ------------------------------------------------------------------------------------------------------------
# static forecast for garch
my_garch_for <- predict(my_garchfit_ibov, n.ahead = 3)

# print df
print(my_garch_for)

#' 
#' A primeira coluna do resultado anterior é a pre
#' 
#' 
#' ## Modelos de Mudança de Regime {#mudanca-regim
#' 
#' Modelos de mudança de regime são um tipo de esp
#' 
#' Para motivar o modelo de mudança de regime, con
#' 

#' 

#' 
#' onde `r if (my_engine!='epub3') {'$S_t=1..k$'} 
#' 
#' Agora, vamos assumir que o modelo anterior tem 
#' 

#' 

#' 
#' Onde:
#' 

#' 

#' 
#' Essa representação implica dois processos para 
#' 
#' Como exemplo em finanças, a variável dependente
#' 
#' As diferentes volatilidades representam a maior
#' 
#' As mudanças dos estados no modelo podem ser def
#' 
#' Uma classe especial de modelos de mudança de re
#' 

#' 

#' 
#' Na matriz anterior, o elemento da linha _i_ e c
#' 
#' 
#' ### Simulando Modelos de Mudança de Regime
#' 
#' No R, dois pacotes estão disponíveis para manip
#' 
## ---- eval=FALSE---------------------------------------------------------------------------------------------
## install.packages("fMarkovSwitching",
##                  repos="http://R-Forge.R-project.org")

#' 
## ---- echo=FALSE---------------------------------------------------------------------------------------------
if (!require('fMarkovSwitching')){
  install.packages("fMarkovSwitching",
                   repos="http://R-Forge.R-project.org")
}

#' 
#' Após o término da instalação, vamos verificar a
#' 
## ------------------------------------------------------------------------------------------------------------
library(fMarkovSwitching)
print(ls('package:fMarkovSwitching'))

#' 
#' O pacote inclui funções para simular, estimar e
#' 
#' 

#' 

#' 
#' A matriz de transição será dada por:
#' 

#' 

#' 
#' Esse modelo tem dois estados com diferentes vol
#' 
## ------------------------------------------------------------------------------------------------------------
set.seed(10)
library(fMarkovSwitching)

# number of obs
nr <- 500

# distribution of residuals
distrib <- "Normal"

# number of states
k <- 2

# set transition matrix
P <- matrix(c(.9 ,.2,
              .1 ,.8),
            nrow = 2,
            byrow = T)

# set switching flag
S <- c(0,1)

# set parameters of model (see manual for details)
nS_param <- matrix(0)
S_param <- matrix(0,sum(S),k)
S_param[,1] <-  .5
S_param[,2] <- -.5

# set variance of model
sigma <- matrix(0,1,k)
sigma[1,1] <- sqrt(0.25)  # state 1
sigma[1,2] <- 1           # state 2

# build list
Coeff <- list(P = P               ,
              S = S               ,
              nS_param = nS_param ,
              S_param = S_param   ,
              sigma = sigma       )

# simulate model
my_MS_sim <- MS_Regress_Simul(nr,Coeff,k,distrib)

#' 
#' Na função de simulação, argumento `nS_param` de
#' 
#' Os elementos em `S_param` definem os coeficient
#' 
#' Uma vez que o modelo é simulado e disponível, v
#' 
## ---- fig.height=my_fig_height, fig.width=my_fig_width-------------------------------------------------------
library(ggplot2)
df_to_plot <- tibble(y = my_MS_sim@dep,
                     x = Sys.Date()+1:my_MS_sim@nr,
                     states = my_MS_sim@trueStates[,1])

p <- ggplot(data = df_to_plot, aes(y=y, x=seq_along(y))) +
  geom_line() + labs(x='Time', y = 'Simulated time series')

print(p)

#' 
#' Também podemos verificar os estados simulados:
#' 
## ---- eval=TRUE, tidy=FALSE, fig.height=my_fig_height, fig.width=my_fig_width--------------------------------
library(ggplot2)
library(dplyr)

df_to_plot<- tibble(y = as.numeric(my_MS_sim@dep),
                    x = Sys.Date()+1:my_MS_sim@nr,
                    states = my_MS_sim@trueStates[,1])

p <- ggplot(data = df_to_plot, aes(y=states, x=x)) +
  geom_line() + labs(y='Probability of state 1')

print(p)

#' 
#' Como esperado, o modelo está mudando de um esta
#' 
#' 
#' ### Estimando Modelos de Mudança de Regime
#' 
#' Estimamos um modelo univariado de mudança de re
#' 
## ---- message=FALSE, results='hide', cache=TRUE--------------------------------------------------------------
# set dep and indep
dep <- my_MS_sim@dep
indep <- my_MS_sim@indep

# set switching parameters and distribution
S <- c(0,1)
k <- 2
distIn <- "Normal"

# estimate the model
my_MS_model <- MS_Regress_Fit(dep,indep,S,k)	# fitting the model

#' 
#' Argumentos `dep` e `indep` definem as variáveis
#' 
## ---- eval=FALSE---------------------------------------------------------------------------------------------
## # print estimation output
## print(my_MS_model)

#' 
#' Os coeficientes estimados são próximos dos util
#' 
#' 
## ---- eval = FALSE, fig.height=6, fig.width=7----------------------------------------------------------------
## plot(my_MS_model)	# plotting output

#' 
#' O nosso exemplo com dados reais será com o índi
#' 
## ---- message=FALSE,results='hide', cache=TRUE---------------------------------------------------------------
df_ibov <- na.omit(df_ibov)

# set input objects to MS_Regress_Fit
ret <- na.omit(df_ibov$ret)
dep <- matrix(ret, nrow = length(ret))
indep <- matrix(rep(1, length(dep)),nrow = length(dep))

S <- c(1)	# where to switch (in this case in the only indep)
k <- 2		# number of states
distIn <- "Normal" #distribution assumption

my_Ibov_MS_Model<- MS_Regress_Fit(dep,indep,S,k)	# fitting the model

#' 
#' Por fim, checamos a saída do modelo com `print`
#' 
## ---- eval=FALSE---------------------------------------------------------------------------------------------
## # printing output
## print(my_Ibov_MS_Model)

#' 
#' 

#' 
#' O modelo identificou e separou os dois regimes 
#' 
#' Uma figura comum na análise de modelos de mudan
#' 
#' 
## ---- fig.height=my_fig_height, fig.width=my_fig_width-------------------------------------------------------
library(dplyr)

# get variables for plot
smooth.prob <- as.numeric(my_Ibov_MS_Model@smoothProb[-1,1])
price <- df_ibov$price.close[2:nrow(df_ibov)]
ref.dates <- df_ibov$ref.date[2:nrow(df_ibov)]

# build long df to plot
df_to_plot<- tibble(type = c(rep('Probabilities S_t=1', 
                                 length(smooth.prob)),
                             rep('IBOV', 
                                 length(smooth.prob))),
                    ref.date = rep(ref.dates ,2),
                    value = c(smooth.prob,
                              price) )

# plot with ggplot
p <- ggplot(df_to_plot,
            aes(y=value, x =ref.date)) +
  geom_line() + facet_wrap(~type, nrow = 2, scales = 'free_y')

# plot it!
print(p)

#' 
#' A figura mostra como os preços diminuiram forte
#' 
#' 
#' ### Prevendo Modelos de Mudança de Regime
#' 
#' Pacote `MS_Regress` fornece função `MS_Regress_
#' 
## ------------------------------------------------------------------------------------------------------------
# make static forecast of regime switching model
newIndep <- 1

my_for <- MS_Regress_For(my_Ibov_MS_Model, newIndep)

# print output
print(my_for)

#' 

#' 
#' O modelo prevê que, para o dia depois da última
#' 
#' 
#' ## Trabalhando com Diversos Modelos
#' 
#' Na prática da pesquisa, é provável que o estudo
#' 
#' No capítulo \@ref(programacao) aprendemos sobre
#' 
#' 
## ------------------------------------------------------------------------------------------------------------
library(readr)

set.seed(10)

# set number of stocks
n_stocks <- 4

# load data from .RData
my_f <- adfeR::get_data_file('IbovStocks_long.csv')
my_df <- read_csv(file = my_f,
                  col_types = cols(ref.date = col_date(format = ""),
                                   ticker = col_character(),
                                   price.adjusted = col_double()))

# calc ret
my_df$ret <- calc_ret(my_df$price.adjusted, my_df$ticker)

# select tickers
my_tickers <- sample(unique(my_df$ticker), n_stocks)

# set my_df
my_df_stocks <- my_df[my_df$ticker %in% my_tickers, ]

# renew factors in ticker
my_df_stocks$ticker <- as.factor(as.character(my_df_stocks$ticker))

#' 
#' Agora, queremos ter um modelo ARIMA diferente p
#' 
## ---- tidy=FALSE---------------------------------------------------------------------------------------------
my_l <- tapply(X = my_df_stocks$ret,
               INDEX = my_df_stocks$ticker,
               FUN = arima,
               order = c(1,0,0))


#' 
#' Cada modelo está disponível na lista `my_l`. Pa
#' 
## ------------------------------------------------------------------------------------------------------------
print(sapply(X = my_l, FUN = coef))

#' 
#' Uma limitação no uso de `tapply` é que estamos 
#' 
#' Para um exemplo de estimativa de vários modelos
#' 
## ------------------------------------------------------------------------------------------------------------
# load data
my_f <- adfeR::get_data_file('Ibov.csv')
df_ibov <- read_csv(file = my_f,
                    col_types = cols(ref.date = col_date(format = ""),
                                     price.close = col_integer()))


# calculate return
df_ibov$ret <- calc_ret(df_ibov$price.close)

# find location of dates
idx <- match(my_df$ref.date, df_ibov$ref.date)

# create column in my_df
my_df$ret_ibov <- df_ibov$ret[idx]

#' 
#' O próximo passo é criar uma função que irá toma
#' 
## ------------------------------------------------------------------------------------------------------------
estimate_beta <- function(df) {
  # Function to estimate beta from dataframe of stocks returns
  #
  # Args:
  #   df - Dataframe with columns ret and ret_ibov
  #
  # Returns:
  #   The value of beta
  
  my_model <- lm(data = df, formula = ret ~ ret_ibov)
  
  return(coef(my_model)[2])
}

#' 
#' Agora vamos utilizar `estimate_beta` com `by`:
#' 
## ------------------------------------------------------------------------------------------------------------
# calculate beta for each stock
my_betas <- by(data = my_df,
               INDICES = my_df$ticker,
               FUN = estimate_beta)

glimpse(as.numeric(my_betas))

#' 
#' Os valores dos betas estão disponíveis no objet
#' 
## ---- eval=TRUE, tidy=FALSE, fig.height=my_fig_height, fig.width=my_fig_width--------------------------------
library(ggplot2)

df_to_plot<- tibble(betas = as.numeric(my_betas))

p <- ggplot(df_to_plot, aes(x=betas)) +
  geom_histogram()

print(p)

#' 
#' Como podemos ver, os _betas_ são positivos na m
#' 
#' Outra maneira de armazenar e gerenciar vários m
#' 
## ---- tidy=FALSE---------------------------------------------------------------------------------------------
library(dplyr)

my_tab <- my_df %>%
  group_by(ticker) %>%
  do(my_model = arima(x = .$ret, 
                      order = c(1,0,0)))

glimpse(my_tab)

#' 
#' Temos uma coluna lista chamada `my_model`. Essa
#' 
## ---- tidy=FALSE---------------------------------------------------------------------------------------------
my_model_tab <- my_df %>%
  group_by(ticker) %>%
  do(my_model = arima(x = .$ret, order = c(1,0,0))) %>%
  mutate(alpha = coef(my_model)[2],
         ar1 = coef(my_model)[1])

print(head(my_model_tab))

#' 
#' Um truque muito interessante para manejar diver
#' 
## ---- eval = FALSE-------------------------------------------------------------------------------------------
## library(broom)
## 
## # get coefs with tidy
## my_coef_tab <- my_model_tab %>%
##   tidy(my_model)
## 
## # print result
## print(head(my_coef_tab))

#' 
#' Note que função `broom::tidy` incluiu os erros 
#' 
## ---- tidy=FALSE, eval=FALSE---------------------------------------------------------------------------------
## # get info on models
## my_info_models <- my_model_tab %>%
##   glance(my_model)
## 
## print(head(my_info_models))

#' 
#' Essa inclui informações sobre coeficiente e est
#' 
#' ## Exercícios {#exerc-modelos}
#' 
## ---- echo=FALSE, results='asis'-----------------------------------------------------------------------------
f_in <- fs::dir_ls('../02-EOCE-Rmd//Cap11-Modelagem/', 
                   type = 'file')

build_exercises(f_in, type_doc = my_engine)
