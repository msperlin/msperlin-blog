#' # Bem vindo! {-}
#' 
#' <p>
#' <a href="https://www.amazon.com.br/dp/B07DN4M35
#' </p>
#' 
#' Esta versão online do livro também está disponí
#' 
#' 
#' ## Licença de uso {-}
#' 
#' Este trabalho é licenciado pela <a rel="license
#' 
#' Perlin, M. S. Análise de Dados Financeiros com 
#' 
#' 
#' ## Sobre o Autor {-}
#' 
#' Sou professor e pesquisador do programa de pós-
#' 
#' 
#' ## Livros do Autor {-}
#' 
#' - [Poupando e Investindo em Renda Fixa](https:/
#' 
#' - [Analyzing Financial and Economic Data with R
#' 