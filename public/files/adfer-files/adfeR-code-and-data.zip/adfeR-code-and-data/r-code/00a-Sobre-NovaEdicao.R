#' # Sobre Nova Edição  {-}
#' 
#' Desde a última edição do livro em 2018, muita c
#' 
#' O diferencial da terceira edição é o **foco no 
#' 
#' - Todo o conteúdo do livro agora é disponibiliz
#' 
#' - Uso de caixas de textos customizadas para ind
#' 
#' - Mais de **100 exercícios de final de capítulo
#' 
#' - **Quatro novos pacotes** especializados na ob
#' 
#' - Um novo capítulo sobre **Otimização de Código
#' 
#' - Uso de **template customizado** para o ebook 
#' 
#' Este livro é um projeto vitalício que pretendo 