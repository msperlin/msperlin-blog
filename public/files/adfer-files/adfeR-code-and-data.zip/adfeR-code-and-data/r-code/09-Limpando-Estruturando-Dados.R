#' # Estruturando e Limpando Dados {#limpando-estr
#' 

#' 
#' Após entender o processo de importação de dados
#' 
#' 
#' ## O Formato do `dataframe`
#' 
#' O formato do `dataframe` é uma discussão relati
#' 
#' Formato _wide_ (largo)
#' : No formato largo, as linhas da tabela são ger
#' 
#' | refdate    | PETR4 | GGBR4 | VALE5 |
#' |------------|-------|-------|-------|
#' | 2015-01-01 | 10    | 3     | 6     |
#' | 2015-01-02 | 11    | 3.1   | 7     |
#' | 2015-01-03 | 10.5  | 3.2   | 7.5   |
#' | 2015-01-04 | 12    | 3.5   | 6     |
#' | ...        | ...   | ...   | ...   |
#' 
#' Observe que a tabela anterior possui três infor
#' 
#' Formato _long_ (longo)
#' : No formato longo, cada linha da tabela é uma 
#' 
#' | refdate    | asset.code | Price |
#' |------------|------------|-------|
#' | 2015-01-01 | PETR4      | 10    |
#' | 2015-01-01 | GGBR4      | 3     |
#' | 2015-01-01 | VALE5      | 6     |
#' | 2015-01-02 | PETR4      | 11    |
#' | 2015-01-02 | GGBR4      | 3.1   |
#' | 2015-01-02 | VALE5      | 7     |
#' | 2015-01-03 | PETR4      | 10.5  |
#' | 2015-01-03 | GGBR4      | 3.2   |
#' | 2015-01-03 | VALE5      | 7.5   |
#' | ...        | ...        | ...   |
#' 
#' Em comparação, o formato largo (`wide`) é mais 
#' 
#' À primeira vista, essa discussão pode parecer b
#' 
#' 
#' ### Conversão entre _long_ e _wide_
#' 
#' A conversão entre um tipo de formato e outro é 
#' 
## ------------------------------------------------------------------------------------------------------------
library(tidyr)
library(dplyr)

# set data
refdate <- as.Date('2021-01-01') + 0:3
PETR4 <- c(10, 11, 10.5, 12)
GGBR4 <- c(3, 3.1, 3.2, 3.5)
VALE5 <- c(6, 7, 7.5, 6)

# set `dataframe`
my_df_wide <- tibble(refdate, PETR4, GGBR4, VALE5)

# from wide to long
my_df_long <- gather(data = my_df_wide,
                     key = 'ticker',
                     value = 'price', - refdate)

# print it
print(my_df_long)

#' 
#' Para realizar a conversão inversa, de longo par
#' 
## ------------------------------------------------------------------------------------------------------------
my_df_wide_converted <- spread(data = my_df_long,
                               key = 'ticker',
                               value = 'price')

print(my_df_wide_converted)

#' 
#' No caso de conversões mais complexas, onde é ne
#' 
## ---- message=FALSE------------------------------------------------------------------------------------------
library(reshape2)
my_df_long <- melt(data = my_df_wide,
                   id.vars = 'refdate',
                   variable.name = 'ticker',
                   value.name = 'price')

print(my_df_long)

#' 
## ------------------------------------------------------------------------------------------------------------
my_df_wide_converted <- dcast(data = my_df_long,
                              formula = refdate ~ ticker,
                              value.var = 'price')
print(my_df_wide_converted)

#' 
#' É importante conhecer essas funções ao se traba
#' 
#' 
#' ## Convertendo Listas em `dataframes`
#' 
#' Um situação muito comum em análise de dados é q
#' 
#' Como um exemplo prático, vamos utilizar o pacot
#' 
## ---- cache=TRUE, message=FALSE------------------------------------------------------------------------------
library(BETS)
my_id <- 3785:3791

# set dates
first_date = '2010-01-01'
last_date  = as.character(Sys.Date())

# get data
l_out <- BETSget(code = my_id, data.frame = TRUE,
                 from = first_date, to = last_date)

# check data
dplyr::glimpse(l_out)

#' 
#' Como usuário, o nosso objetivo é transformar a 
#' 
#' O primeiro passo para estruturar esses dados em
#' 
## ------------------------------------------------------------------------------------------------------------
my_countries <- c("Germany", "Canada", "United States", "France",
                  "Italy", "Japan", "United Kingdom")

#' 
#' Agora, vamos criar uma função que aceite duas e
#' 
## ------------------------------------------------------------------------------------------------------------
clean_bets <- function(df_in, country_in) {
  # function for cleaning data from BETS
  #
  # ARGS: df_in - `dataframe` within a list
  #       country_in - name of country
  #
  # VALUE: a new `dataframe` with new column type
  
  #set column
  df_in$country <- country_in
  
  # return df
  return(df_in)
}

#' 
#' Claramente, caso fosse necessário, poderíamos a
#' 
## ---- eval=FALSE---------------------------------------------------------------------------------------------
## library(purrr)
## 
## # format dfs
## l_out_formatted <- map2(l_out, my_countries, .f = clean_bets)
## 
## # check first element (all are the same structure)
## glimpse(l_out_formatted[[1]])

#' 
#' Note que a coluna `country` foi adicionada a ca
#' 
## ---- eval=FALSE---------------------------------------------------------------------------------------------
## # bind all rows of `dataframes` in list
## df_unemp <- map_df(l_out_formatted, bind_rows)
## 
## # check it
## glimpse(df_unemp)

#' 
#' E pronto! O `dataframe` resultante está no form
#' 
#' 
#' ## Eliminando Outliers {#fct-replace}
#' 
#' Uma parte comum a todas pesquisas com dados é a
#' 
#' Para visualizar o efeito destrutivo de um _outl
#' 
## ------------------------------------------------------------------------------------------------------------
# set options
set.seed(15)
nT <- 50
sim_x <- rnorm(nT)
my_beta <- 0.5

# simulate x and y
sim_y <- sim_x*my_beta + rnorm(nT)
sim_y_with_outlier <- sim_y

# simulate y with outlier
sim_y_with_outlier[10] <- 50

#' 
#' Note que objetos `sim_y` e `sim_y_with_outlier`
#' 
## ---- message=FALSE------------------------------------------------------------------------------------------
library(texreg)

# estimate models
model_no_outlier <- lm(formula = sim_y ~ sim_x)
model_with_outlier <- lm(formula = sim_y_with_outlier ~ sim_x)

# report them
screenreg(list(model_no_outlier, model_with_outlier),
          custom.model.names = c('No Outlier', 'With Outlier'))

#' 
#' Aqui reportamos os modelos com o pacote `texreg
#' 
#' Uma das maneiras de realizar isso é identificar
#' 
## ------------------------------------------------------------------------------------------------------------
quantile90 <- quantile(x = abs(sim_y_with_outlier),
                       probs = 0.95)

#' 
#' Portanto, as observações a seguir são maiores q
#' 
## ------------------------------------------------------------------------------------------------------------
idx <- which(sim_y_with_outlier > quantile90)
print(sim_y_with_outlier[idx])

#' 
#' Observe que capturamos o _outlier_ definido arb
#' 
## ------------------------------------------------------------------------------------------------------------
# copy content
sim_y_without_outlier <- sim_y_with_outlier

# set NA in outlier
sim_y_without_outlier[idx] <- NA

# remove it
sim_y_without_outlier <- sim_y_without_outlier[-idx]

#' 
#' Outra alternativa para a identificação de valor
#' 
## ------------------------------------------------------------------------------------------------------------
library(outliers)

# find outlier
my_outlier <- outlier(sim_y_with_outlier)

# print it
print(my_outlier)

#' 
#' O resultado, porém, é o mesmo que no uso dos qu
#' 
#' Outro ponto importante aqui é a possibilidade d
#' 
#' O primeiro passo é definir uma função que aceit
#' 
## ------------------------------------------------------------------------------------------------------------
replace_outliers <- function(col_in, my_prob = 0.05) {
  # Replaces outliers from a vector
  #
  # INPUTS: col_in The vector
  #         my_prob Probability of quantiles (p and 1-p)
  #
  # OUTPUT: A vector
  
  # return if class is other than numeric
  if (!(class(col_in) %in% c('numeric', 'integer'))) return(col_in)
  
  my_outliers <- stats::quantile(x = col_in,
                                 probs = c(my_prob, 1-my_prob))
  
  idx <- (col_in <= my_outliers[1])|(col_in >= my_outliers[2])
  col_in[idx] <- NA
  
  return(col_in)
  
}

#' 
#' Vamos testá-la:
#' 
## ------------------------------------------------------------------------------------------------------------
# set test vector
my_x <- runif(25)

# find and replace outliers
print(replace_outliers(my_x, my_prob = 0.05))

#' 
#' Como podemos ver, a função funcionou corretamen
#' 
## ------------------------------------------------------------------------------------------------------------
# options
my_N <- 100

# set df
my_df <- tibble(char1 = sample(LETTERS, my_N, replace = T),
                factor1 = factor(sample(LETTERS,
                                        my_N,
                                        replace = T)),
                x1 = runif(my_N),
                x2 = rnorm(my_N),
                x3 = rnorm(my_N))

# check it
glimpse(my_df)

#' 
#' Agora, utilizamos a função `purrr::map` para it
#' 
## ------------------------------------------------------------------------------------------------------------
library(purrr)

# remove outlivers from vectors
l_out <- map(my_df, replace_outliers)

#' 
#' Em seguida reagrupamos todos os vetores em um `
#' 
## ------------------------------------------------------------------------------------------------------------
# rebuild `dataframe`
my_df <- as_tibble(l_out)

# check it
glimpse(my_df)

# summary of df
summary(my_df)

#' 
#' Note que os valores  `NA` foram encontrados nas
#' 
#' Por fim, eliminamos todos as linhas com outlier
#' 
## ------------------------------------------------------------------------------------------------------------
my_df <- na.omit(my_df)

glimpse(my_df)

#' 
#' Observe que algumas observações foram perdidas.
#' 
#' 
#' ## Desinflacionando Dados de Preços
#' 
#' Uma operação muito comum em dados econômicos e 
#' 
#' Para tirar o efeito da inflação em dados de pre
#' 

#' 
#' 
## ------------------------------------------------------------------------------------------------------------
library(Quandl)
library(dplyr)

# register api key
Quandl.api_key(my_api_key)

# set symbol and dates
my_symbol <- 'BCB/433'
first_date <- as.Date('2010-01-01')
last_date <- Sys.Date()

# get data!
df_inflation <- Quandl(code = my_symbol,
                       type='raw',
                       collapse = 'annual',
                       start_date = first_date,
                       order = 'asc',
                       end_date = last_date)

# check content
glimpse(df_inflation)

#' 
#' Agora, vamos construir um `dataframe` com preço
#' 
## ------------------------------------------------------------------------------------------------------------
n_T_ <- nrow(df_inflation)

# create df with prices
my_df <- tibble(Date = df_inflation$Date,
                x = 100 + cumsum(rnorm(n_T_)),
                y = 100 + cumsum(rnorm(n_T_)))

# check it
glimpse(my_df)

#' 
#' O primeiro passo para desinflacionar é criar um
#' 
## ------------------------------------------------------------------------------------------------------------
# accumulate: R_a = cumprod(r_t + 1)
my_df$inflation_index <- cumprod(df_inflation$Value/100 +1)

# set inflation index
my_base <- my_df$inflation_index[nrow(my_df)]
my_df$inflation_index <- my_df$inflation_index/my_base

#' 
#' E, com isso, multiplicar as colunas para criar 
#' 
## ------------------------------------------------------------------------------------------------------------
my_df$x_desinflated <- my_df$x*my_df$inflation_index
my_df$y_desinflated <- my_df$y*my_df$inflation_index

glimpse(my_df)

#' 
#' Pronto. Os dados estão sem o efeito da inflação
#' 
#' 
#' ## Modificando a Frequência Temporal dos Dados
#' 
#' A última estruturação de dados descrita aqui é 
#' 
#' Vamos partir para um exemplo com o índice Ibove
#' 
## ---- message=FALSE------------------------------------------------------------------------------------------
library(BatchGetSymbols)

df_ibov <- BatchGetSymbols(tickers = '^BVSP',
                           first.date = '2010-01-01',
                           last.date = '2022-01-01')[[2]]

#' 
#' Uma das maneiras de realizar a operação de muda
#' 
## ------------------------------------------------------------------------------------------------------------
library(lubridate)

# from daily to annual
df_ibov_annual <- na.omit(df_ibov) %>%
  mutate(ref_year = year(ref.date)) %>%
  group_by(ref_year) %>%
  summarise(Value = last(price.adjusted)) %>%
  print()

#' 
#' Criamos uma nova coluna com os anos, agrupamos 
#' 
#' Usuários interessados em conhecer uma forma mai
#' 
#' 
#' ## Exercícios {#exerc-limpando-estruturando}
#' 
## ---- echo=FALSE, results='asis'-----------------------------------------------------------------------------
f_in <- fs::dir_ls('../02-EOCE-Rmd//Cap09-Limpeza-e-estruturação-dados/', 
                   type = 'file')

build_exercises(f_in, type_doc = my_engine)
