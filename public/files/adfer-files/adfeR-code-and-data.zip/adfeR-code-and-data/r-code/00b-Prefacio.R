#' # Prefácio {-}
#' 

#' 
#' Dado que se interessou por este livro, prevejo 
#' 
#' Este livro é o resultado do meu trabalho como d
#' 
#' Outra motivação que tive para escrever o livro 
#' 
#' Assim como se espera que um artigo científico e
#' 
#' Antes de prosseguir, um aviso. Não iremos traba
#' 
#' Com este livro irás aprender os seguinte tópico
#' 
#' Usar o R e RStudio
#' : O capítulo 01 apresenta, discute e justifica 
#' 
#' Importação de dados financeiros e econômicos
#' : Nos capítulos 04 e 05 vamos aprender a import
#' 
#' Limpar, estruturar e analisar dados
#' : Nos capítulos 06 e 07 iremos estudar o ecossi
#' 
#' Visualização de dados
#' : No capítulo 10 aprenderemos a usar o pacote `
#' 
#' Analisar dados com econometria
#' : No capítulo 11 aprenderemos a usar os modelos
#' 
#' Reporte de resultados
#' : No capítulo 12 veremos como reportar os resul
#' 
#' Melhorando o seu código
#' : No último capítulo do livro vamos discutir as
#' 
#' 
#' ## Material Suplementar {-}
#' 
#' Todo o material usado no livro, incluindo exemp
#' 
#' Para instalar este pacote no seu computador, ba
#' 
## ---- eval=FALSE---------------------------------------------------------------------------------------------
## # install devtools dependency
## install.packages('devtools')
## 
## # install book package
## devtools::install_github('msperlin/adfeR')

#' 
#' O que este código fará é instalar o pacote `dev
#' 
#' Depois da instalação, todos os arquivos do livr
#' 
## ---- eval=FALSE---------------------------------------------------------------------------------------------
## adfeR::copy_book_files(path_to_copy = '~')

#' 
#' Veja que o tilda (`~`) é um atalho para o diret
#' 
#' 
#' ## Conteúdo para Instrutores {-}
#' 
#' Se você for um instrutor de R, aqui encontrarás
#' 
#' Exercícios estáticos
#' : Cada capítulo deste livro inclui exercícios q
#' 
#' Acesso ao livro na internet
#' : Na versão web do livro, o conteúdo integral e
#' 
#' Espero que goste deste livro. O conteúdo tem si
#' 
#' Boa leitura!
#' 
#' Marcelo S. Perlin