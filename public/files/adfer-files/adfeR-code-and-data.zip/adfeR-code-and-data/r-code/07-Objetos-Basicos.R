#' # As Classes Básicas de Objetos {#classes-basic
#' 

#' 
#' **As classes básicas são os elementos mais prim
#' 
#' Neste capítulo iremos estudar mais a fundo as c
#' 
#' - Numéricos (`numeric`)
#' - Texto (`character`)
#' - Fatores (`factor`)
#' - Valores lógicos (`logical`)
#' - Datas e tempo (`Date` e `timedate`)
#' - Dados Omissos (`NA`)
#' 
#' 
#' ## Objetos Numéricos
#' 
#' Uma das classes mais utilizadas em pesquisa emp
#' 
#' 
#' ### Criando e Manipulando Vetores Numéricos
#' 
#' A criação e manipulação de valores numéricos é 
#' 
## ------------------------------------------------------------------------------------------------------------
# create numeric vectors
x <- 1:5
y <- 2:6

# print sum
print(x+y)

# print multiplication
print(x*y)

# print division
print(x/y)

# print exponentiation
print(x^y)

#' 
#' Um diferencial do R em relação a outras linguag
#' 
## ------------------------------------------------------------------------------------------------------------
# set x with 4 elements and y with 2
x <- 1:4
y <- 2:1

# print sum
print(x + y)

#' 
#' O resultado de `x + y` é equivalente a `1:4 + c
#' 
## ----warning=TRUE, error=TRUE--------------------------------------------------------------------------------
# set x = 4 elements and y with 3
x <- c(1, 2, 3, 4)
y <- c(1, 2, 3)

# print sum (recycling rule)
print(x +y)

#' 
#' Os três primeiros elementos de `x` foram somado
#' 
#' Os elementos de um vetor numérico também podem 
#' 
## ------------------------------------------------------------------------------------------------------------
# create named vector
x <- c(item1 = 10,
       item2 = 14,
       item3 = 9,
       item4 = 2)

# print it
print(x)

#' 
#' Para nomear os elementos após a criação, podemo
#' 
## ------------------------------------------------------------------------------------------------------------
# create unnamed vector
x <- c(10, 14, 9, 2)

# set names of elements
names(x) <- c('item1', 'item2', 'item3', 'item4')

# print it
print(x)

#' 
#' Vetores numéricos vazios também podem ser criad
#' 
## ------------------------------------------------------------------------------------------------------------
# create empty numeric vector of length 10
my_x <- numeric(length = 10)

# print it
print(my_x)

#' 
#' Observe que, nesse caso, os valores de `my_x` s
#' 
#' 
#' #### Criando Sequências de Valores
#' 
#' Existem duas maneiras de criar uma sequência de
#' 
#' Porém, o uso do operador `:` limita as possibil
#' 
## ------------------------------------------------------------------------------------------------------------
# set sequence
my_seq <- seq(from = -10, to = 10, by = 2)

# print it
print(my_seq)

#' 
#' Outro atributo interessante da função `seq` é a
#' 
## ------------------------------------------------------------------------------------------------------------
# set sequence with fixed size
my_seq <- seq(from = 0, to = 10, length.out = 20)

# print it
print(my_seq)

#' 
#' No caso anterior, o tamanho final do vetor foi 
#' 
#' 
#' #### Criando Vetores com Elementos Repetidos
#' 
#' Outra função interessante é a que cria vetores 
#' 
## ------------------------------------------------------------------------------------------------------------
# repeat vector three times
my_x <- rep(x = 1, times = 10)

# print it
print(my_x)

#' 
#' A função também funciona com vetores. Considere
#' 
## ------------------------------------------------------------------------------------------------------------
# repeat vector three times
my_x <- rep(x = c(1, 2), times = 3)

# print it
print(my_x)

#' 
#' 
#' #### Criando Vetores com Números Aleatórios
#' 
#' Em muitas situações será necessário a criação d
#' 
#' A função `rnorm` gera números aleatórios da dis
#' 
## ------------------------------------------------------------------------------------------------------------
# generate 10000 random numbers from a Normal distribution
my_rnd_vec <- rnorm(n = 10000,
                    mean = 0,
                    sd = 1)

# print first 20 elements
print(my_rnd_vec[1:20])

#' 
#' O código anterior gera uma grande quantidade de
#' 
## ---- message=FALSE, echo=FALSE------------------------------------------------------------------------------
p <- ggplot(tibble(x = my_rnd_vec), aes(x = x)) + 
  geom_histogram() + theme_bw()

print(p)

#' 
#' Como esperado, temos o formato de sino que cara
#' 
#' Já a função `runif` gera valores aleatórios da 
#' 
## ------------------------------------------------------------------------------------------------------------
# create a random vector with minimum and maximum
my_rnd_vec <- runif(n = 10,
                    min = -5,
                    max = 5)

# print it
print(my_rnd_vec)

#' 
#' Observe que ambas as funções anteriores são lim
#' 
## ------------------------------------------------------------------------------------------------------------
# create sequence
my_vec <- seq(from = 0, to = 25, by=5)

# sample sequence
my_rnd_vec <- sample(my_vec)

# print it
print(my_rnd_vec)

#' 
#' A função `sample` também permite a seleção alea
#' 
## ------------------------------------------------------------------------------------------------------------
# sample one element of my_vec
my_rnd_vec <- sample(my_vec, size = 1)

# print it
print(my_rnd_vec)

#' 
#' Caso quiséssemos dois elementos, escreveríamos:
#' 
## ------------------------------------------------------------------------------------------------------------
# sample two elements of my_vec
my_rnd_vec <- sample(my_vec, size = 2)

# print it
print(my_rnd_vec)

#' 
#' Também é possível selecionar valores de uma amo
#' 
## ------------------------------------------------------------------------------------------------------------
# create vector
my_vec <- c(5, 10, 15)

# sample
my_rnd_vec <- sample(x = my_vec, size = 10, replace = TRUE)
print(my_rnd_vec)

#' 
#' Vale destacar que a função `sample` funciona pa
#' 
## ------------------------------------------------------------------------------------------------------------
# example of sample with characters
print(sample(c('elem 1', 'elem 2', 'elem 3'),
             size = 1))

# example of sample with list
print(sample(list(x = c(1,1,1),
                  y = c('a', 'b')),
             size = 1))

#' 
#' É importante ressaltar que a geração de valores
#' 
#' Uma propriedade interessante no R é a possibili
#' 
## ------------------------------------------------------------------------------------------------------------
# fix seed
set.seed(seed = 10)

# set vec and print
my_rnd_vec_1 <- runif(5)
print(my_rnd_vec_1)

# set vec and print
my_rnd_vec_2 <- runif(5)
print(my_rnd_vec_2)

#' 
#' No código anterior, o valor de `set.seed` é um 
#' 
#' O uso de `set.seed` também funciona para o caso
#' 
## ------------------------------------------------------------------------------------------------------------
# fix seed
set.seed(seed = 15)

# print vectors
print(sample(1:10))
print(sample(10:20))

#' 
#' Novamente, execute os comandos anteriores no R 
#' 
#' 
#' ### Acessando Elementos de um Vetor Numérico
#' 
#' Todos os elementos de um vetor numérico podem s
#' 
## ------------------------------------------------------------------------------------------------------------
# set vector
x <- c(-1, 4, -9, 2)

# get first element
first_elem_x <- x[1]

# print it
print(first_elem_x)

#' 
#' A mesma notação é válida para extrair porções d
#' 
## ------------------------------------------------------------------------------------------------------------
# sub-vector of x
sub_x <- x[1:2]

# print it
print(sub_x)

#' 
#' Para acessar elementos nomeados de um vetor num
#' 
## ------------------------------------------------------------------------------------------------------------
# set named vector
x <- c(item1 = 10, item2 = 14, item3 = -9, item4 = -2)

# access elements by name
print(x['item2'])
print(x[c('item2','item4')])

#' 
#' O acesso aos elementos de um vetor numérico tam
#' 
## ------------------------------------------------------------------------------------------------------------
# find all values of x higher than zero
print(x[x > 0])

#' 
#' Os usos de regras de segmentação dos dados de a
#' 
#' 
#' ### Modificando e Removendo Elementos de um Vet
#' 
#' A modificação de um vetor numérico é muito simp
#' 
## ------------------------------------------------------------------------------------------------------------
# set vector
my_x <- 1:4

# modify first element to 5
my_x[1] <- 5

# print result
print(my_x)

#' 
#' Essa modificação também pode ser realizada em b
#' 
## ------------------------------------------------------------------------------------------------------------
# set vector
my_x <- 0:5

# set the first three elements to 5
my_x[1:3] <- 5

# print result
print(my_x)

#' 
#' O uso de condições para definir elementos é rea
#' 
## ------------------------------------------------------------------------------------------------------------
# set vector
my_x <- -5:5

# set any value lower than 2 to 0
my_x[my_x<2] <- 0

# print result
print(my_x)

#' 
#' A remoção de elementos é realizada com o uso de
#' 
## ------------------------------------------------------------------------------------------------------------
# create vector
my_x <- -5:5

# remove first and second element of my_x
my_x <- my_x[-(1:2)]

# show result
print(my_x)

#' 
#' Note como o uso do índice negativo em `my_x[-(1
#' 
#' 
#' ### Criando Grupos
#' 
#' Em algumas situações será necessário entender q
#' 
#' A função `cut` serve para criar grupos de inter
#' 
## ------------------------------------------------------------------------------------------------------------
# set rnd vec
my_x <- rnorm(10)

# "cut" it into 5 pieces
my_cut <- cut(x = my_x, breaks = 5)
print(my_cut)

#' 
#' Observe que os nomes dos elementos da variável 
#' 
#' No exemplo anterior, os intervalos para cada gr
#' 
## ------------------------------------------------------------------------------------------------------------
# set random vector
my_x <- rnorm(10)

# create groups with 5 breaks
my_cut <- cut(x = my_x, breaks = 5)

# print it!
print(my_cut)

#' 
#' Note que os nomes dos elementos em `my_cut` for
#' 
## ------------------------------------------------------------------------------------------------------------
# create random vector
my_x <- rnorm(10)

# define breaks manually
my_breaks <- c(min(my_x)-1, -1, 1, max(my_x)+1)

# define labels manually
my_labels <- c('Low','Normal', 'High')

# create group from numerical vector
my_cut <- cut(x = my_x, breaks = my_breaks, labels = my_labels)

# print both!
print(my_x)
print(my_cut)

#' 
#' Como podemos ver, os nomes dos grupos estão mai
#' 
#' 
#' ### Outras Funções Úteis
#' 
#' **as.numeric** - Converte determinado objeto pa
#' 
## ------------------------------------------------------------------------------------------------------------
my_text <- c('1', '2', '3')
class(my_text)
my_x <- as.numeric(my_text)
print(my_x)
class(my_x)

#' 
#' **sum** - Soma os elementos de um vetor.
#' 
## ------------------------------------------------------------------------------------------------------------
my_x <- 1:50
my_sum <- sum(my_x)
print(my_sum)

#' 
#' **max** - Retorna o máximo valor numérico do ve
#' 
## ------------------------------------------------------------------------------------------------------------
x <- c(10, 14, 9, 2)
max_x <- max(x)
print(max_x)

#' 
#' **min** - Retorna o mínimo valor numérico do ve
#' 
## ------------------------------------------------------------------------------------------------------------
x <- c(12, 15, 9, 2)
min_x <- min(x)
print(min_x)

#' 
#' **which.max** - Retorna a posição do máximo val
#' 
## ------------------------------------------------------------------------------------------------------------
x <- c(100, 141, 9, 2)
which.max_x <- which.max(x)
cat(paste('The position of the maximum value of x is ', which.max_x))
cat(' and its value is ', x[which.max_x])

#' 
#' **which.min** - Retorna a posição do mínimo val
#' 
## ---- tidy=FALSE---------------------------------------------------------------------------------------------
x <- c(10, 14, 9, 2)
which.min_x <- which.min(x)
cat(paste('The position of the minimum value of x is ',
          which.min_x, ' and its value is ', x[which.min_x]))

#' 
#' **sort** - Retorna uma versão ordenada de um ve
#' 
## ------------------------------------------------------------------------------------------------------------
x <- runif(5)
print(sort(x, decreasing = FALSE))
print(sort(x, decreasing = TRUE))

#' 
#' **cumsum** - Soma os elementos de um vetor de f
#' 
## ------------------------------------------------------------------------------------------------------------
my_x <- 1:25
my_cumsum <- cumsum(my_x)
print(my_cumsum)

#' 
#' **prod** - Realiza o produto de todos os elemen
#' 
## ------------------------------------------------------------------------------------------------------------
my_x <- 1:10
my_prod <- prod(my_x)
print(my_prod)

#' 
#' **cumprod** - Calcula o produto cumulativo de t
#' 
## ------------------------------------------------------------------------------------------------------------
my_x <- 1:10
my_prod <- cumprod(my_x)
print(my_prod)

#' 
#' 
#' ## Classe de Caracteres (texto)
#' 
#' A classe de caracteres, ou texto, serve para ar
#' 
#' O R possui vários recursos que facilitam a cria
#' 
#' Um aspecto positivo de `stringr` é que as funçõ
#' 
#' 
#' ### Criando um Objeto Simples de Caracteres
#' 
#' Todo objeto de caracteres é criado através da e
#' 
## ------------------------------------------------------------------------------------------------------------
my_assets <- c('PETR3', 'VALE4', 'GGBR4')
print(my_assets)

#' 
#' Confirma-se a classe do objeto com a função `cl
#' 
## ------------------------------------------------------------------------------------------------------------
class(my_assets)

#' 
#' 
#' ### Criando Objetos Estruturados de Texto
#' 
#' Em muitos casos no uso do R, estaremos interess
#' 
#' Para criar um vetor textual capaz de unir texto
#' 
## ------------------------------------------------------------------------------------------------------------
library(stringr)

# create sequence
my_seq <- 1:20

# create character
my_text <- 'text'

# paste objects together (without space)
my_char <- str_c(my_text, my_seq)
print(my_char)

# paste objects together (with space)
my_char <- str_c(my_text, my_seq, sep = ' ')
print(my_char)

# paste objects together (with space)
my_char <- paste(my_text, my_seq)
print(my_char)

#' 
#' O mesmo procedimento também pode ser realizado 
#' 
## ------------------------------------------------------------------------------------------------------------
# set character value
my_x <- 'My name is'

# set character vector
my_names <- c('Marcelo', 'Ricardo', 'Tarcizio')

# paste and print
print(str_c(my_x, my_names, sep = ' '))

#' 
#' Outra possibilidade de construção de textos est
#' 
## ------------------------------------------------------------------------------------------------------------
my_char <- str_dup(string = 'abc', times = 5)
print(my_char)

#' 
#' ### Objetos Constantes de Texto
#' 
#' O R também possibilita o acesso direto a todas 
#' 
## ------------------------------------------------------------------------------------------------------------
# print all letters in alphabet (no cap)
print(letters)

#' 
## ------------------------------------------------------------------------------------------------------------
# print all letters in alphabet (WITH CAP)
print(LETTERS)

#' 
#' Observe que em ambos os casos não é necessário 
#' 
## ------------------------------------------------------------------------------------------------------------
# print abreviation and full names of months
print(month.abb)
print(month.name)

#' 
#' 
#' ### Selecionando Pedaços de um Texto
#' 
#' Um erro comum praticado por iniciantes é tentar
#' 
## ------------------------------------------------------------------------------------------------------------
# set char object
my_char <- 'ABCDE'

# print its second character: 'B' (WRONG - RESULT is NA)
print(my_char[2])

#' 
#' O resultado `NA` indica que o segundo elemento 
#' 
## ------------------------------------------------------------------------------------------------------------
print(my_char[1])

#' 
#' O resultado é simplesmente o texto _ABCDE_, que
#' 
## ------------------------------------------------------------------------------------------------------------
# print third and fourth characters
my_substr <- str_sub(string = my_char,
                     start = 4,
                     end = 4)
print(my_substr)

#' 
#' Essa função também funciona para vetores atômic
#' 
## ------------------------------------------------------------------------------------------------------------
# build char vec
my_char_vec <- paste0(c('123','231','321'),
                      ' - other ignorable text')
print(my_char_vec)

#' 
#' Só estamos interessados na informação das três 
#' 
## ------------------------------------------------------------------------------------------------------------
# get ids with stringr::str_sub
ids.vec <- str_sub(my_char_vec, 1, 3)
print(ids.vec)

#' 
## **Operações vetorizadas são comuns e esperadas no R**. Quase tudo o que você pode fazer para um único elemento pode ser expandido para vetores. Isso facilita o desenvolvimento de rotinas pois pode-se facilmente realizar tarefas complicadas em uma série de elementos, em uma única linha de código.

#' 
#' 
#' ### Localizando e Substituindo Pedaços de um Te
#' 
#' Uma operação útil na manipulação de textos é a 
#' 
#' Usualmente, o caso mais comum em pesquisa é ver
#' 
#' O exemplo a seguir mostra como encontrar o cara
#' 
## ------------------------------------------------------------------------------------------------------------
library(stringr)

my_char <- 'ABCDEF-ABCDEF-ABC'
pos = str_locate(string = my_char, pattern = fixed('D') )
print(pos)

#' 
#' Observe que a função `str_locate` retorna apena
#' 
## ------------------------------------------------------------------------------------------------------------
# set object
my_char <- 'ABCDEF-ABCDEF-ABC'

# find position of ALL 'D' using str_locate_all
pos = str_locate_all(string = my_char, pattern = fixed('D'))
print(pos)

#' 
#' Observe também que as funções `regexp` e `grepe
#' 
#' Para substituir caracteres em um texto, basta u
#' 
## ------------------------------------------------------------------------------------------------------------
# set char object
my_char <- 'ABCDEF-ABCDEF-ABC'

# substitute the FIRST 'ABC' for 'XXX' with sub
my_char <- sub(x = my_char,
               pattern = 'ABC',
               replacement = 'XXX')
print(my_char)

# substitute the FIRST 'ABC' for 'XXX' with str_replace
my_char <- 'ABCDEF-ABCDEF-ABC'
my_char <- str_replace(string = my_char,
                       pattern = fixed('ABC'),
                       replacement = 'XXX')
print(my_char)

#' 
#' E agora fazemos uma substituição global dos car
#' 
## ------------------------------------------------------------------------------------------------------------
# set char object
my_char <- 'ABCDEF-ABCDEF-ABC'

# substitute the FIRST 'ABC' for 'XXX' with str_replace
my_char <- str_replace_all(string = my_char,
                           pattern = 'ABC',
                           replacement = 'XXX')
print(my_char)

#' 
#' Mais uma vez, vale ressaltar que as operações d
#' 
## ---- tidy=FALSE---------------------------------------------------------------------------------------------
# set char object
my_char <- c('ABCDEF','DBCFE','ABC')

# create an example of vector
my_char_vec <- str_c(sample(my_char, 5, replace = T),
                     sample(my_char, 5, replace = T),
                     sep = ' - ')

# show it
print(my_char_vec)

# substitute all occurrences of 'ABC'
my_char_vec <- str_replace_all(string = my_char_vec,
                               pattern = 'ABC',
                               replacement = 'XXX')

# print result
print(my_char_vec)

#' 
#' 
#' ### Separando Textos
#' 
#' Em algumas situações, principalmente no process
#' 
## ------------------------------------------------------------------------------------------------------------
# set char
my_char <- 'ABCXABCXBCD'

# split it based on 'X' and using stringr::str_split
split_char <- str_split(my_char, 'X')

# print result
print(split_char)

#' 
#' A saída dessa função é um objeto do tipo lista.
#' 
## ------------------------------------------------------------------------------------------------------------
print(split_char[[1]][2])

#' 
#' Para visualizar um exemplo de dividir textos em
#' 
## ------------------------------------------------------------------------------------------------------------
# set char
my_char_vec <- c('ABCDEF','DBCFE','ABFC','ACD')

# split it based on 'B' and using stringr::strsplit
split_char <- str_split(my_char_vec, 'B')

# print result
print(split_char)

#' 
#' Observe como, novamente, um objeto do tipo `lis
#' 
#' 
#' ### Descobrindo o Número de Caracteres de um Te
#' 
#' Para descobrir o número de caracteres de um tex
#' 
## ------------------------------------------------------------------------------------------------------------
# set char
my_char <- 'abcdef'

# print number of characters using stringr::str_length
print(str_length(my_char))

#' 
#' E agora um exemplo com vetores.
#' 
## ------------------------------------------------------------------------------------------------------------
#set char
my_char <- c('a', 'ab', 'abc')

# print number of characters using stringr::str_length
print(str_length(my_char))

#' 
#' ### Gerando Combinações de Texto
#' 
#' Um truque útil no R é usar as funções `base::ou
#' 
## ------------------------------------------------------------------------------------------------------------
# set char vecs
my_vec_1 <- c('a','b')
my_vec_2 <- c('A','B')

# combine in matrix
comb.mat <- outer(my_vec_1,
                  my_vec_2,
                  paste,sep = '-')

# print it!
print(comb.mat)

#' 
#' A saída de `outer` é um objeto do tipo  matriz.
#' 
## ------------------------------------------------------------------------------------------------------------
print(as.character(comb.mat))

#' 
#' Outra maneira de atingir o mesmo objetivo é usa
#' 
## ------------------------------------------------------------------------------------------------------------
library(tidyverse)

# set vectors
my_vec_1 <- c('John ', 'Claire ', 'Adam ')
my_vec_2 <- c('is fishing.', 'is working.')

# create df with all combinations
my_df <- expand.grid(name = my_vec_1,
                     verb = my_vec_2)

# print df
print(my_df)

# paste columns together in tibble
my_df <- my_df %>%
  mutate(phrase = paste0(name, verb) )

# print result
print(my_df)

#' 
#' Aqui, usamos a função `expand.grid` para criar 
#' 
#' 
#' ### Codificação de Objetos `character`
#' 
#' Para o R, um _string_ de texto é apenas uma seq
#' 
#' Vamos explorar um exemplo. Aqui, vamos importar
#' 
## ------------------------------------------------------------------------------------------------------------
# read text file
my_f <- adfeR::get_data_file('FileWithLatinChar_Latin1.txt')

my_char <- readr::read_lines(my_f)

# print it
print(my_char)

#' 
#' O conteúdo original do arquivo é um texto em po
#' 
## ------------------------------------------------------------------------------------------------------------
my_char <- readr::read_lines(my_f, 
                             locale = readr::locale(encoding='Latin1'))

# print it
print(my_char)

#' 
#' Os caracteres latinos agora estão corretos pois
#' 
#' 
#' ### Outras Funções Úteis
#' 
#' `stringr::str_to_lower`/`base::tolower` - Conve
#' 
## ------------------------------------------------------------------------------------------------------------
print(stringr::str_to_lower('ABC'))

#' 
#' `stringr::str_to_upper/base::toupper` - Convert
#' 
## ------------------------------------------------------------------------------------------------------------
print(toupper('abc'))

print(stringr::str_to_upper('abc'))

#' 
#' 
#' ## Fatores
#' 
#' A classe de fatores (`factor`) é utilizada para
#' 
#' A classe de fatores oferece um significado espe
#' 
#' 
#' ### Criando Fatores
#' 
#' A criação de fatores dá-se através da função `f
#' 
## ------------------------------------------------------------------------------------------------------------
my_factor <- factor(c('M', 'F', 'M', 'M', 'F'))
print(my_factor)

#' 
#' Observe, no exemplo anterior, que a apresentaçã
#' 
## ------------------------------------------------------------------------------------------------------------
my_factor <- factor(c('M','F','M','M','F','ND'))
print(my_factor)

#' 
#' Um ponto importante na criação de fatores é que
#' 
## ------------------------------------------------------------------------------------------------------------
my_status <- factor(c('Solteiro', 'Solteiro', 'Solteiro'))
print(my_status)

#' 
#' Nota-se que, por ocasião, os dados mostram apen
#' 
## ---- tidy=FALSE---------------------------------------------------------------------------------------------
my_status <- factor(c('Solteiro', 'Solteiro', 'Solteiro'),
                    levels = c('Solteiro', 'Casado'))
print(my_status)

#' 
#' 
#' ### Modificando Fatores
#' 
#' Um ponto importante sobre os objetos do tipo fa
#' 
## ----warning=TRUE--------------------------------------------------------------------------------------------
# set factor
my_factor <- factor(c('a', 'b', 'a', 'b'))

# change first element of a factor to 'c'
my_factor[1] <- 'c'

# print result
print(my_factor)

#' 
#' Nesse caso, a maneira correta de proceder é pri
#' 
## ------------------------------------------------------------------------------------------------------------
# set factor
my_factor <- factor(c('a', 'b', 'a', 'b'))

# change factor to character
my_char <- as.character(my_factor)

# change first element
my_char[1] <- 'c'

# mutate it back to class factor
my_factor <- factor(my_char)

# show result
print(my_factor)

#' 
#' Utilizando essas etapas temos o resultado desej
#' 
#' O universo `tidyverse` também possui um pacote 
#' 
## ------------------------------------------------------------------------------------------------------------
library(forcats)

# set factor
my.fct <- factor(c('A', 'B', 'C', 'A', 'C', 'M', 'N'))

# modify factors
my.fct <- fct_recode(my.fct,
                     'D' = 'A',
                     'E' = 'B',
                     'F' = 'C')

# print result
print(my.fct)

#' 
#' Observe como o uso da função `forcats::fct_reco
#' 
#' 
#' ### Convertendo Fatores para Outras Classes
#' 
#' Outro ponto importante no uso de fatores é a su
#' 
## ------------------------------------------------------------------------------------------------------------
# create factor
my_char <-factor(c('a', 'b', 'c'))

# convert and print
print(as.character(my_char))

#' 
#' Porém, quando fazemos o mesmo procedimento para
#' 
## ------------------------------------------------------------------------------------------------------------
# set factor
my_values <- factor(5:10)

# convert to numeric (WRONG)
print(as.numeric(my_values))

#' 
#' Esse resultado pode ser explicado pelo fato de 
#' 
## ------------------------------------------------------------------------------------------------------------
# converting factors to character and then to numeric
print(as.numeric(as.character(my_values)))

#' 
## Tenha muito cuidado ao transformar fatores em números. Lembre-se sempre de que o retorno da conversão direta serão os índices dos `levels` e não os valores em si. Esse é um _bug_ bem particular que pode ser difícil de identificar em um código complexo.

#' 
#' ### Criando Tabelas de Contingência
#' 
#' Após a criação de um fator, podemos calcular a 
#' 
## ---- tidy=FALSE---------------------------------------------------------------------------------------------
# create factor
my_factor <- factor(sample(c('Pref', 'Ord'),
                           size = 20,
                           replace = TRUE))

# print contingency table
print(table(my_factor))

#' 
#' Um caso mais avançado do uso de `table` é utili
#' 
## ---- tidy=FALSE---------------------------------------------------------------------------------------------
# set factors
my_factor_1 <- factor(sample(c('Pref', 'Ord'),
                             size = 20,
                             replace = TRUE))

my_factor_2 <- factor(sample(paste('Grupo', 1:3),
                             size = 20,
                             replace = TRUE))

# print contingency table with two factors
print(table(my_factor_1, my_factor_2))

#' 
#' A tabela criada anteriormente mostra o número d
#' 
#' 
#' ### Outras Funções
#' 
#' **levels** - Retorna os `Levels` de um objeto d
#' 
## ------------------------------------------------------------------------------------------------------------
my_factor <- factor(c('A', 'A', 'B', 'C', 'B'))
print(levels(my_factor))

#' 
#' **as.factor** - Transforma um objeto para a cla
#' 
## ------------------------------------------------------------------------------------------------------------
my_y <- c('a','b', 'c', 'c', 'a')
my_factor <- as.factor(my_y)
print(my_factor)

#' 
#' **split** - Com base em um objeto de fator, cri
#' 
## ------------------------------------------------------------------------------------------------------------
my_factor <- factor(c('A','B','C','C','C','B'))
my_x <- 1:length(my_factor)

my_l <- split(x = my_x, f = my_factor)

print(my_l)

#' 
#' 
#' ## Valores Lógicos
#' 
#' Testes lógicos em dados são centrais no uso do 
#' 
#' 
#' ### Criando Valores Lógicos
#' 
#' Em uma sequência de 1 até 10, podemos verificar
#' 
## ------------------------------------------------------------------------------------------------------------
# set numerical
my_x <- 1:10

# print a logical test
print(my_x > 5)

# print position of elements from logical test
print(which(my_x > 5))

#' 
#' A função `which` do exemplo anterior retorna os
#' 
#' Para realizar testes de igualdade, basta utiliz
#' 
## ------------------------------------------------------------------------------------------------------------
# create char
my_char <- rep(c('abc','bcd'), 5)

# print its contents
print(my_char)

# print logical test
print(my_char == 'abc')

#' 
#' Para o teste de inigualdades, utilizamos o símb
#' 
## ------------------------------------------------------------------------------------------------------------
# print inequality test
print(my_char != 'abc')

#' 
#' Destaca-se que também é possível testar condiçõ
#' 
## ------------------------------------------------------------------------------------------------------------
my_x <- 1:10

# print logical for values higher than 4 and lower than 7
print((my_x > 4)&(my_x < 7) )

# print the actual values
idx <- which( (my_x > 4)&(my_x < 7) )
print(my_x[idx])

#' 
#' Para testar condições não simultâneas, isto é, 
#' 
## ------------------------------------------------------------------------------------------------------------
# location of elements higher than 7 or lower than 4
idx <- which( (my_x > 7)|(my_x < 4) )

# print elements from previous condition
print(my_x[idx])

#' 
#' Observe que, em ambos os casos de uso de testes
#' 
#' Outro uso interessante de objetos lógicos é o t
#' 
## ------------------------------------------------------------------------------------------------------------
library(dplyr)
# location of elements higher than 7 or lower than 4
my_tickers <- c('ABC', 'DEF')

# set df
n_obs <- 100
df_temp <- tibble(tickers = sample(c('ABC', 'DEF', 'GHI', 'JKL'),
                                   size = n_obs,
                                   replace = TRUE),
                  ret = rnorm(n_obs, sd = 0.05) )

# find rows with selected tickers
idx <- df_temp$tickers %in% my_tickers

# print elements from previous condition
glimpse(df_temp[idx, ])

#' 
#' O `dataframe` mostrado na tela possui dados ape
#' 
#' 
#' ## Datas e Tempo
#' 
#' A representação e manipulação de datas é um imp
#' 
#' Nesta seção estudaremos as funções e classes na
#' 
#' Antes de começarmos, vale relembrar que toda da
#' 
#' 
#' ### Criando Datas Simples
#' 
#' No R, existem diversas classes que podem repres
#' 
#' A classe mais básica de datas é `Date`. Essa in
#' 
## ------------------------------------------------------------------------------------------------------------
library(lubridate)

# set Date object
print(ymd('2021-06-24'))

# set Date object
print(dmy('24-06-2021'))


# set Date object
print(mdy('06-24-2021'))

#' 
#' Note que as funções retornam exatamente o mesmo
#' 
#' Um benefício no uso das funções do pacote `lubr
#' 
## ------------------------------------------------------------------------------------------------------------
# set Date object
print(ymd('2021/06/24'))

# set Date object
print(ymd('2021&06&24'))

# set Date object
print(ymd('2021 june 24'))

# set Date object
print(dmy('24 of june 2021'))

#' 
#' Isso é bastante útil pois o formato de datas no
#' 
## ------------------------------------------------------------------------------------------------------------
# set Date from dd/mm/yyyy
my_date <- dmy('24/06/2021')

# print result
print(my_date)

#' 
#' Já no pacote `base`, a função correspondente é 
#' 
## ------------------------------------------------------------------------------------------------------------
# set Date from dd/mm/yyyy with the definition of format
my_date <- as.Date('24/06/2021', format = '%d/%m/%Y')

# print result
print(my_date)

#' 
#' Os símbolos utilizados na entrada `format`, tal
#' 
#' 
#' | Código |          Valor         |Exemplo |
#' |:------:|:----------------------:|:------:|
#' |%d      |dia do mês (decimal)    |0       |
#' |%m      |mês (decimal)           |12      |
#' |%b      |mês (abreviado)         |Abr     |
#' |%B      |mês (nome completo)     |Abril   |
#' |%y      |ano (2 dígitos)         |16      |
#' |%Y      |ano (4 dígitos)         |2021    |
#' 
#' 
#' Os símbolos anteriores permitem a criação de da
#' 
#' 
#' ### Criando Sequências de Datas
#' 
#' Um aspecto interessante no uso de objetos do ti
#' 
## ------------------------------------------------------------------------------------------------------------
# create date
my_date <- ymd('2021-06-24')

# find next day
my_date_2 <- my_date + 1

# print result
print(my_date_2)

#' 
#' A propriedade também funciona com vetores, o qu
#' 
## ------------------------------------------------------------------------------------------------------------
# create a sequence of Dates
my_date_vec <- my_date + 0:15

# print it
print(my_date_vec)

#' 
#' Uma maneira mais customizável de criar sequênci
#' 
## ------------------------------------------------------------------------------------------------------------
# set first and last Date
my_date_1 <- ymd('2021-03-07')
my_date_2 <- ymd('2021-03-20')

# set sequence
my_date_date <- seq(from = my_date_1,
                    to = my_date_2,
                    by = '2 days')

# print result
print(my_date_date)

#' 
#' Caso quiséssemos de duas em duas semanas, escre
## ------------------------------------------------------------------------------------------------------------
# set first and last Date
my_date_1 <- ymd('2021-03-07')
my_date_2 <- ymd('2021-04-20')

# set sequence
my_date_date <- seq(from = my_date_1,
                    to = my_date_2,
                    by = '2 weeks')

# print result
print(my_date_date)

#' 
#' Outra forma de utilizar `seq` é definir o taman
#' 
## ------------------------------------------------------------------------------------------------------------
# set first and last Date
my_date_1 <- ymd('2021-03-07')
my_date_2 <- ymd('2021-10-20')

# set sequence
my_date_vec <- seq(from = my_date_1,
                    to = my_date_2,
                    length.out = 10)

# print result
print(my_date_vec)

#' 
#' O intervalo entre as datas em `my_date_vec` é d
#' 
#' 
#' ### Operações com Datas
#' 
#' É possível descobrir a diferença de dias entre 
#' 
## ------------------------------------------------------------------------------------------------------------
# set dates
my_date_1 <- ymd('2015-06-24')
my_date_2 <- ymd('2016-06-24')

# calculate difference
diff_date <- my_date_2 - my_date_1

# print result
print(diff_date)

#' 
#' A saída da operação de subtração é um objeto da
#' 
## ------------------------------------------------------------------------------------------------------------
# print difference of days as numerical value
print(diff_date[[1]])

#' 
#' Podemos testar se uma data é maior do que outra
#' 
## ------------------------------------------------------------------------------------------------------------
# set date and vector
my_date_1 <- ymd('2016-06-20')
my_date_vec <- ymd('2016-06-20') + seq(-5,5)

# test which elements of my_date_vec are older than my_date_1
my_test <- (my_date_vec > my_date_1)

# print result
print(my_test)

#' 
#' A operação anterior é bastante útil quando se e
#' 
## ------------------------------------------------------------------------------------------------------------
library(dplyr)
library(lubridate)

# set first and last dates
first_date <- ymd('2016-06-01')
last_date <- ymd('2016-06-15')

# create `dataframe` and glimpse it
my_temp_df <- tibble(date_vec = ymd('2016-05-25') + seq(0,30),
                     prices=seq(1,10,
                                length.out = length(date_vec)))

glimpse(my_temp_df)

# find dates that are between the first and last date
my_idx <- (my_temp_df$date_vec >= first_date) &
  (my_temp_df$date_vec <= last_date)

# use index to filter `dataframe`
my_temp_df_filtered <- my_temp_df %>%
  filter(my_idx) %>%
  glimpse()

#' 
#' Nesse caso, o vetor final de preços da coluna `
#' 
#' 
#' ### Lidando com Data e Tempo
#' 
#' O uso da classe `Date` é suficiente quando se e
#' 
#' No pacote `base`, uma das classes utilizadas pa
#' 
#' O formato tempo/data também segue a norma [ISO 
#' 
## ------------------------------------------------------------------------------------------------------------
# creating a POSIXct object
my_timedate <- as.POSIXct('2021-01-01 16:00:00')

# print result
print(my_timedate)

#' 
#' O pacote `lubridate` também oferece funções int
#' 
## ------------------------------------------------------------------------------------------------------------
library(lubridate)

# creating a POSIXlt object
my_timedate <- ymd_hms('2021-01-01 16:00:00')

# print it
print(my_timedate)

#' 
#' Destaca-se que essa classe adiciona automaticam
#' 
## ------------------------------------------------------------------------------------------------------------
# creating a POSIXlt object with custom timezone
my_timedate_tz <- ymd_hms('2021-01-01 16:00:00',
                          tz = 'GMT')

# print it
print(my_timedate_tz)

#' 
#' É importante ressaltar que, para o caso de obje
#' 
## ------------------------------------------------------------------------------------------------------------
# Adding values (seconds) to a POSIXlt object and printing it
print(my_timedate_tz + 30)

#' 
#' Assim como para a classe `Date`, existem símbol
#' 
#' 
#' | Código |           Valor          | Exemplo |
#' |:------:|:------------------------:|:-------:|
#' | %H     | Hora (decimal, 24 horas) | 23      |
#' | %I     | Hora (decimal, 12 horas) | 11      |
#' | %M     | Minuto (decimal, 0-59)   | 12      |
#' | %p     | Indicador AM/PM          | AM      |
#' | %S     | Segundos (decimal, 0-59) | 50      |
#' 
#' A seguir veremos como utilizar essa tabela para
#' 
#' 
#' ### Personalizando o Formato de Datas
#' 
#' A notação básica para representar datas e data/
#' 
#' Para formatar uma data, utilizamos a função `fo
#' 
## ---- tidy=FALSE---------------------------------------------------------------------------------------------
# create vector of dates
my_dates <- seq(from = ymd('2021-01-01'),
                to = ymd('2021-01-15'),
                by = '1 day')

# change format
my_dates_br <- format(my_dates, '%d/%m/%Y')

# print result
print(my_dates_br)

#' 
#' O mesmo procedimento pode ser realizado para ob
#' 
## ------------------------------------------------------------------------------------------------------------
# create vector of date-time
my_datetime <- ymd_hms('2021-01-01 12:00:00') + seq(0,560,60)

# change to Brazilian format
my_dates_br <- format(my_datetime, '%d/%m/%Y %H:%M:%S')

# print result
print(my_dates_br)

#' 
#' Pode-se também customizar para formatos bem esp
#' 
## ------------------------------------------------------------------------------------------------------------
# set custom format
my_dates_custom <- format(my_dates,
                          'Year=%Y | Month=%m | Day=%d')

# print result
print(my_dates_custom)

#' 
#' 
#' ### Extraindo Elementos de uma Data
#' 
#' Para extrair elementos de datas tal como o ano,
#' 
## ------------------------------------------------------------------------------------------------------------
library(lubridate)

# create vector of date-time
my_datetime <- seq(from = ymd_hms('2021-01-01 12:00:00'),
                   to = ymd_hms('2021-01-01 18:00:00'),
                   by = '1 hour')

# get hours from POSIXlt
my_hours <- as.numeric(format(my_datetime, '%H'))

# print result
print(my_hours)

#' 
#' Da mesma forma, poderíamos utilizar os símbolos
#' 
## ------------------------------------------------------------------------------------------------------------
# create vector of date-time
my_datetime <- seq(from = ymd_hms('2021-01-01 12:00:00'),
                   to = ymd_hms('2021-01-01 18:00:00'),
                   by = '15 min')

# get minutes from POSIXlt
my_minutes <- as.numeric(format(my_datetime, '%M'))

# print result
print(my_minutes)

#' 
#' Outra forma é utilizar as funções do `lubridate
#' 
## ------------------------------------------------------------------------------------------------------------
# get hours with lubridate
print(hour(my_datetime))

# get minutes with lubridate
print(minute(my_datetime))

#' 
#' Outras funções também estão disponíveis para os
#' 
#' 
#' ### Conhecendo o Horário e a Data Atual
#' 
#' O R inclui várias funções que permitem o usuári
#' 
#' Para conhecer o dia atual, basta utilizarmos a 
#' 
## ------------------------------------------------------------------------------------------------------------
library(lubridate)

# get today
print(Sys.Date())

# print it
print(today())

#' 
#' Para descobrir a data e horário, utilizamos a f
#' 
## ------------------------------------------------------------------------------------------------------------
# get time!
print(Sys.time())

# get time!
print(now())

#' 
#' Com base nessas, podemos escrever:
#' 
## ------------------------------------------------------------------------------------------------------------
library(stringr)

# example of log message
my_str <- str_c('This code was executed in ', now())

# print it
print(my_str)

#' 
#' 
#' ### Outras Funções Úteis
#' 
#' **weekdays** - Retorna o dia da semana de uma o
#' 
## ---- tidy=FALSE---------------------------------------------------------------------------------------------
# set date vector
my_dates <- seq(from = ymd('2021-01-01'),
                to = ymd('2021-01-5'),
                by = '1 day')

# find corresponding weekdays
my_weekdays <- weekdays(my_dates)

# print it
print(my_weekdays)

#' 
#' **months** - Retorna o mês de uma ou várias dat
#' 
## ---- tidy=FALSE---------------------------------------------------------------------------------------------
# create date vector
my_dates <- seq(from = ymd('2021-01-01'),
                to = ymd('2021-12-31'),
                by = '1 month')

# find months
my_months <- months(my_dates)

# print result
print(my_months)

#' 
#' **quarters** - Retorna a localização de uma ou 
#' 
## ------------------------------------------------------------------------------------------------------------
# get quartiles of the year
my_quarters <- quarters(my_dates)
print(my_quarters)

#' 
#' **OlsonNames** -  Retorna um vetor com as zonas
#' 
#' 
## ------------------------------------------------------------------------------------------------------------
# get possible timezones
possible_tz <- OlsonNames()

# print it
print(possible_tz[1:5])

#' 
#' **Sys.timezone** - Retorna a zona de tempo do s
#' 
#' 
## ------------------------------------------------------------------------------------------------------------
# get current timezone
print(Sys.timezone())

#' 
#' **cut** - Retorna um fator a partir da categori
#' 
#' 
## ---- tidy=FALSE---------------------------------------------------------------------------------------------
# set example date vector
my_dates <- seq(from = ymd('2021-01-01'),
                to = ymd('2021-03-01'),
                by = '5 days')

# group vector based on monthly breaks
my_month_cut <- cut(x = my_dates,
                    breaks = 'month')

# print result
print(my_month_cut)

#' 
## ------------------------------------------------------------------------------------------------------------
# set example datetime vector
my_datetime <- as.POSIXlt('2021-01-01 12:00:00') + seq(0,250,15)

# set groups for each 30 seconds
my_cut <- cut(x = my_datetime, breaks = '30 secs')

# print result
print(my_cut)

#' 
#' 
#' ## Dados Omissos - `NA` (_Not available_)
#' 
#' Uma das principais inovações do R em relação a 
#' 
#' 
#' ### Definindo Valores `NA`
#' 
#' Para definirmos os casos omissos nos dados, bas
#' 
## ------------------------------------------------------------------------------------------------------------
# a vector with NA
my_x <- c(1, 2, NA, 4, 5)

# print it
print(my_x)

#' 
#' Vale destacar que a operação de qualquer valor 
#' 
## ------------------------------------------------------------------------------------------------------------
# example of NA interacting with other objects
print(my_x + 1)

#' 
#' Isso exige cuidado quando se está utilizando al
#' 
## ------------------------------------------------------------------------------------------------------------
# set vector with NA
my_x <- c(1:5, NA, 5:10)

# print cumsum (NA after sixth element)
print(cumsum(my_x))

# print cumprod (NA after sixth element)
print(cumprod(my_x))

#' 
## Toda vez que utilizar as funções `cumsum` e `cumprod`, certifique-se de que não existe algum valor `NA` no vetor de entrada. Lembre-se de que todo `NA` é contagiante e o cálculo recursivo irá resultar em um vetor repleto de dados faltantes.

#' 
#' 
#' ### Encontrando e Substituindo Valores `NA`
#' 
#' Para encontrar os valores `NA` em um vetor, bas
#' 
## ------------------------------------------------------------------------------------------------------------
# set vector with NA
my_x <- c(1:2, NA, 4:10)

# find location of NA
idx_na <- is.na(my_x)
print(idx_na)

#' 
#' Para substituí-los, use indexação com a saída d
#' 
## ------------------------------------------------------------------------------------------------------------
# set vector
my_x <- c(1, NA, 3:4, NA)

# replace NA for 2
my_x[is.na(my_x)] <- 2

# print result
print(my_x)

#' 
#' Outra maneira de limpar o objeto é utilizar a f
#' 
#' 
## ------------------------------------------------------------------------------------------------------------
# set vector
my_char <- c(letters[1:3], NA, letters[5:8])

# print it
print(my_char)

# use na.omit to remove NA
my_char <- na.omit(my_char)

# print result
print(my_char)

#' 
#' Apesar de o tipo de objeto ter sido trocado, de
#' 
## ------------------------------------------------------------------------------------------------------------
# trying nchar on a na.omit object
print(nchar(my_char))

#' 
#' Para outros objetos, porém, recomenda-se cautel
#' 
#' 
#' ### Outras Funções Úteis
#' 
#' **complete.cases** - Retorna um vetor lógico qu
#' 
#' 
## ------------------------------------------------------------------------------------------------------------
# create matrix
my_mat <- matrix(1:15, nrow = 5)

# set an NA value
my_mat[2,2] <- NA

# print index with rows without NA
print(complete.cases(my_mat))

#' 
#' ## Exercícios {#exerc-classes-basicas}
#' 
## ---- echo=FALSE, results='asis'-----------------------------------------------------------------------------
f_in <- fs::dir_ls('../02-EOCE-Rmd//Cap07-Objetos-Básicos/', 
                   type = 'file')

build_exercises(f_in, type_doc = my_engine)
