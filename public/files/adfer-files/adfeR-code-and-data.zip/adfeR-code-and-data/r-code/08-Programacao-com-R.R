#' # Programando com o R {#programacao}
#' 

#' 
#' Nos capítulos anteriores estudamos o ecossistem
#' 
#' 
#' ## Criando Funções
#' 
#' Como já foi destacado anteriormente, **o uso de
#' 
#' Uma função pode ser desenvolvida ao longo do te
#' 
#' Uma função sempre possui três partes conexas: a
#' 
#' No R, o esqueleto de definição de uma função é 
#' 
## ------------------------------------------------------------------------------------------------------------
my_fct <- function(arg1 = 1, arg2 = 'abc'){
  
  length_arg1 <- length(arg1)
  length_arg2 <- length(arg2)
  
  msg1 <- paste0('Number of elements in arg1: ', length_arg1)
  message(msg1)
  
  msg2 <- paste0('Number of elements in arg2: ', length_arg2)
  message(msg2)
  
  out <- c(length_arg1, length_arg2)
  return(out)
  
}

#' 
#' Após o registro da função no ambiente do R (ins
#' 
## ------------------------------------------------------------------------------------------------------------
out1 <- my_fct(arg1 = 2, arg2 = 'bcd')
print(out1)

out2 <- my_fct(arg1 = 1:10, 
               arg2 = c('dab', 'asc'))
print(out2)

#' 
#' Observa-se que a definição de uma função é muit
#' 
#' O uso de igualdade nessas definições, tal como 
#' 
#' Toda função irá retornar algum objeto com o com
#' 
#' Quanto ao uso da função, primeiro você precisa 
#' 
#' Os argumentos da função podem ser definidos por
#' 
#' Agora, vamos criar uma função que faça algo mai
#' 
## ------------------------------------------------------------------------------------------------------------
my_fct <- function(x = c(1, 1, 1, 1)){
  # Calculates the average of input x
  #
  # Args:
  # 	x: a numerical vector
  #
  # Returns:
  #   The mean of x
  
  mean_out <- sum(x)/length(x)
  
  return(mean_out)
  
}

#' 
#' Observe como definimos uma seção de comentários
#' 
#' > "Functions should contain a comments section 
#' >
#' > --- Google's R style manual
#' 
#' Depois de escrever e registrar a função, vamos 
#' 
## ------------------------------------------------------------------------------------------------------------
# testing function my_fct
my_mean <- my_fct(x = 1:100)

# print result
print(my_mean)

#' 
#' Funcionou! A média resultante está correta, con
#' 
#' Caso a função `my_mean` for chamada sem _input_
#' 
## ------------------------------------------------------------------------------------------------------------
# calling my_fct without input
my_mean <- my_fct()

# print result
print(my_mean)

#' 
#' Novamente, como esperado, o valor retornado est
#' 
## Uma estratégia para o uso de valores _default_ de funções é sempre colocar o valor mais óbvio ou mais simples. O usuário não precisa entender toda a complexidade de uma função e as consequências na escolha de diferentes valores. Ao fazer seleções para ele, o uso da função fica mais fácil e intuitivo.

#' 
#' Apesar de simples, o exemplo anterior nos permi
#' 
#' Evitar esse erro é bastante simples, basta util
#' 
## ------------------------------------------------------------------------------------------------------------
my_fct <- function(x = c(1, 1, 1, 1)){
  # Calculates the average of input x
  #
  # Args:
  #   x - a numerical vector
  #
  # Returns:
  #   The mean of x, as numeric
  
  if (!(class(x) %in% c('numeric','integer'))){
    stop('ERROR: x is not numeric or integer')
  }
  
  mean_out <- sum(x)/length(x)
  
  return(mean_out)
}

#' 
#' No código anterior, utilizamos a função `class`
#' 
## ---- error=TRUE---------------------------------------------------------------------------------------------
# using wrong inputs (ERROR)
my_fct(x = c('a', 'b'))

#' 
#' Outro ponto importante da função criada anterio
#' 
## ------------------------------------------------------------------------------------------------------------
# sum with NA
print(sum(c(1, 2, 3, NA, 4)))

#' 
#' Lembre que objetos do tipo `NA` são contagiosos
#' 
#' Para resolver é bastante simples: basta informa
#' 
## ------------------------------------------------------------------------------------------------------------
my_fct <- function(x = c(1, 1, 1, 1)){
  # Calculates the average of input x
  #
  # Args:
  #   x: a numerical vector
  #
  # Returns:
  #   The mean of x, as numeric
  
  if (!(class(x) %in% c('numeric','integer'))){
    stop('ERROR: x is not numeric or integer')
  }
  
  if (any(is.na(x))){
    warning('Warning: Found NA in x. Removing it.')
    x <- na.omit(x)
  }
  
  mean_out <- sum(x)/length(x)
  
  return(mean_out)
}

#' 
#' Para o código anterior, usamos função `warning`
#' 
## ----warning=TRUE--------------------------------------------------------------------------------------------
# set vector with NA
y <- c(1,2,3, NA,1)

# test function
print(my_fct(y))

#' 
#' Como podemos ver, a função reconheceu e alertou
#' 
#' Na escrita de uma função, o teste de aderência 
#' 
## Se você escreveu algo que possa resolver problemas de outros usuários, reforço a possibilidade de organizar a função em um pacote e enviar para o CRAN. Assim, retribuirá a comunidade com o seu trabalho. Detalhes sobre como enviar um pacote para o CRAN encontram-se neste [link](https://r-pkgs.org/index.html).

#' 
#' Agora, vamos passar para um exemplo mais comple
#' 
#' Formalmente, define-se o retorno aritmético uma
#' 
#' 

#' 

#' 
#' No R, esse procedimento toma como entrada um ve
#' 
#' Para começar, vamos criar uma função que toma c
#' 
## ------------------------------------------------------------------------------------------------------------
calc_ret <- function(P) {
  # calculates arithmetic returns from a vector of prices
  # ret_t = p_{t}/p_{t-1} - 1
  #
  # Args:
  #   P - vector of prices (numeric)
  #
  # Returns:
  #   A vector of returns
  
  my_length <- length(P)
  ret <- c(NA, P[2:my_length]/P[1:(my_length - 1)] - 1)
  return(ret)
}

#' 
#' Observe como mantivemos a função simples e dire
#' 
#' Apesar de intuitiva, note que a função `calc_re
#' 
#' Para resolver é bastante fácil, basta inserirmo
#' 
## ------------------------------------------------------------------------------------------------------------
calc_ret <- function(P, tickers = rep('ticker', length(P))) {
  # calculates arithmetic returns from a vector of prices
  #
  # Args:
  #   P - vector of prices (numeric)
  #   tickers - vector of tickers (optional)
  #
  # Returns:
  #   A vector of returns
  
  # ret_t = p_{t}/p_{t-1} - 1
  
  # error checking
  if ( !(class(P) %in% c('numeric', 'integer'))) {
    stop('ERROR: P should be a numeric object.')
  }
  
  if ( !(class(tickers) %in% c('character', 'factor'))) {
    stop('ERROR: tickers should be a character or factor object.')
  }
  
  if (length(P) != length(tickers)) {
    stop('ERROR: The length of P and tickers does not match.')
  }
  
  if ( length(P) < 2) {
    stop('ERROR: input P should have at least 2 elements.')
  }
  
  my_length <- length(P)
  ret <- c(NA, P[2:my_length]/P[1:(my_length - 1)] - 1)
  
  idx <- (tickers != c(NA, tickers[1:(my_length-1)]))
  ret[idx] <- NA
  
  return(ret)
}


#' 
#' Esse é um código extenso! Mas lembre-se, só é n
#' 
#' Agora, vamos aplicar a função com os dados disp
#' 
## ------------------------------------------------------------------------------------------------------------
library(readr)
library(dplyr)

my_f <- adfeR::get_data_file('SP500-Stocks_long.csv')

# set columns types
my_cols <- cols(
  price.adjusted = col_double(),
  ref.date = col_date(format = ""),
  ticker = col_character()
)

# import data
my_df <- read_csv(my_f, col_types = my_cols)

# calculate return column
my_df <- my_df %>%
  mutate(ret = calc_ret(P = price.adjusted,
                        tickers = ticker))


#' 
#' Vamos verificar o resultado:
#' 
## ------------------------------------------------------------------------------------------------------------
glimpse(my_df)
summary(my_df)

#' 
#' Perfeito! O novo `dataframe` possui a coluna `r
#' 
#' Indo mais além, vamos remover todos `NAs` com f
#' 
## ------------------------------------------------------------------------------------------------------------
library(dplyr)

my_df <- my_df %>%
  filter(complete.cases(.))

# check result
glimpse(my_df)
summary(my_df)

#' 
#' Por fim, salvamos o `dataframe` resultante em u
#' 
## ------------------------------------------------------------------------------------------------------------
f_to_save <- '00-text-resources/data/SP500-Stocks-WithRet.rds'
readr::write_rds(x = my_df,
                 file = f_to_save)

#' 
#' 
#' ## Utilizando Loops (comando _for_) {#loops}
#' 
#' Os _loops_ são os comandos mais básicos dentro 
#' 
#' Considere, por exemplo, um cenário envolvendo u
#' 
#' A grande _sacada_ no uso de _loops_ é que o seu
#' 
#' A estrutura de um _loop_ segue o seguinte esque
#' 
## ----eval=FALSE----------------------------------------------------------------------------------------------
## for (i in i_vec){
## 
##   # codes goes here
## 
## }

#' 
#' Para o código anterior, comando `for` indica o 
#' 
## ------------------------------------------------------------------------------------------------------------
# set seq
my_seq <- seq(-5,5)

# do loop
for (i in my_seq){
  message(paste('The value of i is',i))
}

#' 
#' No exemplo anterior, criamos uma sequência de -
#' 
#' A sequência do _loop_ não é exclusiva para veto
#' 
## ------------------------------------------------------------------------------------------------------------
# set char vec
my_char_vec <- letters[1:5]

# loop it!
for (i_char in my_char_vec){
  message(paste('The value of i_char is', i_char))
}

#' 
#' O mesmo é válido para listas:
#' 
## ------------------------------------------------------------------------------------------------------------
# set list
my_l <- list(x = 1:5,
             y = c('abc','dfg'),
             z = factor('A','B','C','D'))

# loop list
for (i_l in my_l){
  
  message(paste0('The class of i_l is ', class(i_l), '. '), 
          appendLF = FALSE)
  message(paste0('The number of elements is ', length(i_l), '.'))
  
}

#' 
#' Destaca-se que o iterador não precisa necessari
#' 
## ------------------------------------------------------------------------------------------------------------
# set vec and iterators
my_vec <- seq(1:5)
my_x <- 5
my_z <- 10

for (i in my_vec){
  # iterate "manually"
  my_x <- my_x + 1
  my_z <- my_z + 2
  
  message('Value of i = ', i,
          ' | Value of my_x = ', my_x,
          ' | Value of my_z = ', my_z)
}

#' 
#' O uso de _loops_ encadeados, isto é, um _loop_ 
#' 
## ------------------------------------------------------------------------------------------------------------
# set matrix
my_mat <- matrix(1:9, nrow = 3)

# loop all values of matrix
for (i in seq(1, nrow(my_mat))){
  for (j in seq(1, ncol(my_mat))){
    message(paste0('Element [', i, ', ', j, '] = ', my_mat[i, j]))
  }
}

#' 
#' Vamos partir agora para um exemplo mais complex
#' 
## ------------------------------------------------------------------------------------------------------------
library(tibble)
library(readr)

# set number of files to create
n_files <- 10

# set first part of saved files
pattern_name <- 'myfiles_'

# set dir
out_dir <- 'many_datafiles/'

# test if out_dir exists, if not, creates it
if (!dir.exists(out_dir)){
  dir.create(out_dir)
}

# clean up folder before creating new files
file.remove(list.files(out_dir, full.names = TRUE))

# set vec with filenames
file_names <- paste0(out_dir, pattern_name, seq(1,n_files), '.csv')

# loop it!
for (i_file in file_names){
  # create temp df
  temp_df <- tibble(x = runif(100))
  
  # write it!
  write_csv(x = temp_df, file = i_file)
}

#' 
#' No exemplo anterior, usamos a função `if` em `i
#' 
#' No _loop_, usamos função `runif` para criar 100
#' 
#' Podemos checar os arquivos criados com a função
#' 
## ------------------------------------------------------------------------------------------------------------
# check files
print(list.files(out_dir))

#' 
#' Como esperado, os arquivos criados estão na res
#' 
## ------------------------------------------------------------------------------------------------------------
library(dplyr)
library(readr)

# set empty df
df_agg <- tibble()
for (i_file in file_names){
  # read file
  temp_df <- read_csv(i_file, 
                      col_types = cols(x = col_double()))
  
  # row bind
  df_agg <- bind_rows(df_agg, temp_df)
}

glimpse(df_agg)
summary(df_agg)

#' 
#' No código anterior, observe como agregamos os `
#' 
#' Outro exemplo prático do uso de um _loop_ é o p
#' 
## ---- tidy=FALSE---------------------------------------------------------------------------------------------
library(readr)
library(dplyr)

# read data
my_f <- adfeR::get_data_file('IbovStocks_long.csv')
my_df <- read_csv(my_f, 
                  col_types = cols())

# find unique tickers in column ticker
unique_tickers <- unique(my_df$ticker)

# create empty df
tab_out <- tibble()

# loop tickers
for (i_ticker in unique_tickers){
  
  # create temp df with ticker i_ticker
  temp <- filter(my_df, ticker == i_ticker)
  
  # row bind i_ticker and mean_price
  temp_mean_price <- mean(temp$price.adjusted)
  tab_out <- bind_rows(tab_out,
                       data.frame(ticker = i_ticker,
                                  mean_price = temp_mean_price))
  
}

# print result
print(tab_out[1:10, ])

#' 
#' Note que, no código anterior, utilizamos a funç
#' 
#' 
#' ## Execuções Condicionais (`if`, `else`, `switc
#' 
#' Execuções condicionais permitem tomar decisões 
#' 
## ----eval=FALSE----------------------------------------------------------------------------------------------
## if (cond){
## 
##   CodeIfTRUE...
## 
## } else {
## 
##   CodeIfFALSE...
## 
## }

#' 
#' Onde `cond` é a condição a ser avaliada, tomand
#' 
## ------------------------------------------------------------------------------------------------------------
my_x <- 1:10
my_thresh <- 5

for (i in my_x){
  if (i > my_thresh){
    message('Value of i is ', i, ' - Higher than ', my_thresh)
  } else {
    message('Value of i is ', i, ' - Lower or equal than ', my_thresh)
  }
}

#' 
#' Podemos, também, aplicar mais de uma condição l
#' 
## ------------------------------------------------------------------------------------------------------------
my_x <- 1:10
my_thresh <- 5

for (i in my_x){
  if (i > my_thresh){
    message('Value of i is ', i, ' - Higher than ', my_thresh)
  } else if (i==my_thresh) {
    message('Value of i ', i, ' - equal to ', my_thresh)
  } else {
    message('Value of i ', i, ' - lower than ', my_thresh)
  }
}

#' 
#' Outra possibilidade para o uso de execuções con
#' 
## ------------------------------------------------------------------------------------------------------------
# set vec
my_vec <- c('A', 'D', 'B', 'A', 'C', 'B')

for (i_vec in my_vec){
  if (i_vec == 'A'){
    message('Got an A!')
  } else if (i_vec == 'B') {
    message('Got a B!')
  } else if (i_vec == 'C') {
    message('Got a C!')
  } else if (i_vec == 'D') {
    message('Got a D!')
  }
}

#' 
#' Enquanto o código anterior faria o que precisam
#' 
## ------------------------------------------------------------------------------------------------------------
# set vec
my_vec <- c('A', 'D', 'B', 'A', 'C', 'B')

# using switch
for (i_vec in my_vec){
  msg_out <- switch(i_vec,
                    'A' = 'Got an A!',
                    'B' = 'Got a B!',
                    'C' = 'Got a C!',
                    'D' = 'Got a D!')
  
  message(msg_out)
  
}

#' 
#' O grande benefício no uso de `switch` é a clare
#' 
#' 
#' ## Utilizando as Funções da Família `apply`
#' 
#' O R oferece uma maneira alternativa e funcional
#' 
#' Vale salientar que todo procedimento criado via
#' 
#' 
#' ### Função `lapply`
#' 
#' A função `lapply` toma como entrada uma lista e
#' 
## ------------------------------------------------------------------------------------------------------------
# set list
my_l <- list(vec1 = 1:10,
             vec2 = 2:5,
             vec3 = 10:-20)

# use lapply with mean
my_mean_vec <- lapply(X = my_l, FUN = mean)

# print result
print(my_mean_vec)

#' 
#' O resultado mostra as médias de cada vetor em `
#' 
## ------------------------------------------------------------------------------------------------------------
# set list
my_l <- list(c(1,NA,2), c(2:5,NA), 10:-20)

# use lapply with mean
my_mean_vec <- lapply(X = my_l,
                      FUN = mean,
                      na.rm=TRUE)

# print result
print(my_mean_vec)

#' 
#' Como podemos ver, os argumentos extras em `lapp
#' 
#' O uso de `lapply` é particularmente útil quando
#' 
## ------------------------------------------------------------------------------------------------------------
# function to generate files
creat_rnd_file <- function(name_file, N = 100){
  # Generates a csv file with random content
  #
  # Args:
  # 	name_file - name of csv file (character)
  #	  N - number of rows in random `dataframe` (integer)
  #
  # Returns:
  # 	TRUE, if successful
  
  if (class(name_file)!='character'){
    stop('ERROR: input name_file is not a character')
  }
  
  if ( !(class(N) %in% c('numeric','integer')) ){
    stop('ERROR: input N is not an integer or numeric!')
  }
  
  # create random df
  temp_df <- data.frame(x = runif(N))
  
  # write it!
  write.csv(x = temp_df, file = name_file)
  
  # return list
  l_out <- list(file = name_file,
                sucess = TRUE)
  return(l_out)
}

#' 
#' E utilizá-la juntamente com a função `lapply`:
#' 
## ------------------------------------------------------------------------------------------------------------
# set options
n_files <- 5
pattern_name <- 'myfiles_with_lapply_'
out_dir <- 'many_datafiles/'

# set file names
file_names <- paste0(out_dir,pattern_name, seq(1,n_files), '.csv')

# test if out_dir exists, if not, create it
if (!dir.exists(out_dir)){
  dir.create(out_dir)
}

# clean up folder before creating new files
file.remove(list.files(out_dir, full.names = TRUE))

# use lapply
out_l <- lapply(X = file_names, FUN = creat_rnd_file, N = 100)

# print result
print(out_l)

#' 

#' 
#' O código funcionou corretamente, conforme esper
#' 
#' Uma observação importante aqui é que o retorno 
#' 
#' 
#' ### Função `sapply`
#' 
#' Função `sapply` é semelhante a `lapply`. A gran
#' 
## ------------------------------------------------------------------------------------------------------------
# create list
my_l <- list(1:10, 2:5, 10:-20)

# use sapply
my_mean_vec <- sapply(my_l, mean)

# print result
print(my_mean_vec)

#' 
#' O uso de `sapply` é recomendado quando buscamos
#' 
#' Um aspecto importante da função `sapply` é que 
#' 
## ------------------------------------------------------------------------------------------------------------
# set list
my_l <- list(runif(10), runif(15), rnorm(1000))

my_fct <- function(x){
  # Returns mean and standard deviation of a vector
  #
  # Args:
  #	  x - numerical vector
  #
  # Returns:
  #	  Vector as c(mean(x), sd(x))
  
  if (!(class(x) %in% c('numeric','integer'))){
    stop('ERROR: Class of x is not numeric or integer.')
  }
  
  x <- na.omit(x)
  
  out <- c(Mean  = mean(x),
           StDev = sd(x))
  return(out)
  
}

# use sapply
my_vec <- sapply(my_l, my_fct)

# check result
print(my_vec)

#' 
#' Havendo mais de uma saída da função utilizada c
#' 
#' Um uso prático de `sapply` em pesquisa é a cria
#' 
## ------------------------------------------------------------------------------------------------------------
describe_vec <- function(x){
  # Describe numerical vector with mean and other stats
  #
  # Args:
  #	  x - numerical vector
  #
  # Returns:
  #   A vector with mean, maximum and minimum
  
  # error checking
  if (!(class(x) %in% c('numeric','integer'))){
    stop('ERROR: Class of x is not numeric or integer.')
  }
  
  x <- na.omit(x)
  
  # calc vec
  out <- c(mean_price = mean(x),
           max_price = max(x),
           min_price = min(x))
  
  return(out)
}

#' 
#' Agora, vamos carregar dados do índice Ibovespa 
#' 
#' 
## ------------------------------------------------------------------------------------------------------------
# set file and read it
library(dplyr)
library(readr)

my_f <- adfeR::get_data_file('IbovStocks_long.csv')
my_df <- read_csv(my_f,
                  col_types = cols(price.adjusted = col_double(),
                                   ref.date = col_date(format = ""),
                                   ticker = col_character()))

# use split to split prices by ticker
my_l <- split(x = my_df$price.adjusted, my_df$ticker)

# use sapply
my_tab <- sapply(X = my_l, FUN = describe_vec)

# check result
print(head(t(my_tab)))

#' 
#' Utilizamos a função `split` para separar os dad
#' 
#' 
#' ### Função `tapply`
#' 
#' Função `tapply` é específica para cálculos em g
#' 
## ------------------------------------------------------------------------------------------------------------
# set numeric vec and factor
my_x <- 1:150
my_factor <- factor(c(rep('C',50), rep('B',50), rep('A',50)))

# use tapply
my_mean_vec <- tapply(X = my_x, INDEX = my_factor, FUN = mean)

# print result
print(my_mean_vec)

#' 
#' Observa-se que o resultado é muito próximo do q
#' 
#' Voltando ao exemplo anterior com dados reais, p
#' 
## ------------------------------------------------------------------------------------------------------------
# use tapply for descriptive stats
my_l_out <- tapply(X = my_df$price.adjusted,
                   INDEX = my_df$ticker,
                   FUN = describe_vec)

# print result
print(my_l_out[1:5])

#' 
#' A saída de `tapply` é uma lista contendo os val
#' 
## ------------------------------------------------------------------------------------------------------------
# convert list to `dataframe`
my_tab <- do.call(what = rbind, args = my_l_out)

# print result
print(head(my_tab))

#' 
#' Explicando melhor, a função `do.call` irá, recu
#' 
#' 
#' ### Função `mapply`
#' 
#' Função `mapply` é uma versão multivariada de `l
#' 
#' Suponha que estamos interessados em criar uma l
#' 
## ------------------------------------------------------------------------------------------------------------
# set size
N <- 10

# prealocate list
my_l <- list()

for (i in seq(1,N)){
  my_l[[i]] <- seq(1,i)
}

# print result
print(my_l)

#' 
#' Outra solução, menos verbosa, é usar `mapply`:
#' 
## ------------------------------------------------------------------------------------------------------------
# use mapply for creating list
my_l <- mapply(FUN = seq, rep(1,N), seq(1,N))

print(my_l)

#' 
#' Explicando o resultado, função `mapply` está ch
#' 
#' 
#' ### Função `apply`
#' 
#' Função `apply` é bastante parecida com `sapply`
#' 
## ------------------------------------------------------------------------------------------------------------
# set matrix and print it
my_mat <- matrix(1:15, nrow = 5)
print(my_mat)

# sum rows with apply and print it
sum_rows <- apply(X = my_mat, MARGIN = 1, FUN = sum)
print(sum_rows)

# sum columns with apply and print it
sum_cols <- apply(X = my_mat, MARGIN = 2, FUN = sum)
print(sum_cols)

#' 
#' No exemplo anterior, argumento `MARGIN` definiu
#' 
## ------------------------------------------------------------------------------------------------------------
# print max by row
print(apply(X = my_mat, MARGIN = 1, FUN = max))

# print max by column
print(apply(X = my_mat, MARGIN = 2, FUN = max))

#' 
#' 
#' ## Utilizando Pacote `purrr`
#' 
#' O universo `tidyverse` oferece não somente funç
#' 
#' 
#' ### Função `purrr::map`
#' 
#' Função `purrr::map` e suas derivadas funciona d
#' 
## ------------------------------------------------------------------------------------------------------------
library(purrr)

# set list
my_l <- list(vec1 = 1:10,
             vec2 = 1:50,
             vec3 = 1:5,
             char1 = letters[1:10])

# get length of objects
res_out <- my_l %>%
  map_int(length)

print(res_out)

# find character objets
res_out <- my_l %>%
  map_lgl(is.character)

print(res_out)


#' 
#' Outro ponto interessante nas funções do `purrr`
#' 
## ------------------------------------------------------------------------------------------------------------
# set list
my_l <- list(vec1 = c(elem1 = 10, elem2 = 20, elem3 = 5),
             char1 = c(elem1 = 40, elem2 = 50, elem3 = 15))

# get second element of each element in list, by position
res_out <- my_l %>% map(2)
print(res_out)

# get third element of each element in list, by name
res_out <- my_l %>% map('elem3')
print(res_out)

#' 
#' Essa funcionalidade é bastante útil pois em mui
#' 
#' ### Função `purrr::safely`
#' 
#' Indo além, a grande inovação do `purrr` em rela
#' 
#' Função `safely` encapsula outra função e sempre
#' 
## ---- error=TRUE---------------------------------------------------------------------------------------------
library(purrr)

my_fct <- function(x) {
  return(x+1)
}

# ERROR
print(my_fct('a'))

#' 
#' Agora vamos utilizar `safely` para encapsular `
#' 
## ------------------------------------------------------------------------------------------------------------
# with safely
my_fct_safely <- safely(my_fct)

print(my_fct_safely('a'))

#' 
#' Note que o código `print(my_fct_safely('a'))` r
#' 
## ------------------------------------------------------------------------------------------------------------
my_l <- list(1:5,
             'a',
             1:4)

res_out <- my_l %>%
  map(safely(my_fct))

print(res_out)

#' 
#' Podemos facilmente ver que a função teve erro n
#' 
## ------------------------------------------------------------------------------------------------------------
print(res_out %>% map('result'))

#' 
#' Ou apenas as mensagens de erro:
#' 
## ------------------------------------------------------------------------------------------------------------
print(res_out %>% map('error'))

#' 
#' A saída padrão para o caso de erros também pode
#' 
## ------------------------------------------------------------------------------------------------------------
my_l <- list(1,
             'a',
             4)

# NA for errors
res_out <- my_l %>%
  map(safely(my_fct,
             otherwise = NA)) %>%
  map_dbl('result')

# print result
print(res_out)

#' 
#' Outras funções para controle de erros no `purrr
#' 
#' 
#' ### Função `purrr::pmap` 
#' 
#' Função `purrr::pmap` é uma das melhores alterna
#' 
#' Como exemplo, vamos considerar uma função que c
#' 
## ------------------------------------------------------------------------------------------------------------
build_phrase <- function(name_in, fruit_in, verb_in) {
  my_msg <- paste0('My name is ', name_in,
                   ' and I like to eat ', fruit_in,
                   ' while ', verb_in, '.')
  
  return(my_msg)
}

build_phrase('Joe', 'apple', 'studying')

#' 
#' A função `build_phrase` tem três entradas de te
#' 
## ------------------------------------------------------------------------------------------------------------
names_vec <- c('Joe', 'Kate')
fruits_vec <- c('kiwi', 'apple')
verb_vec <- c('rowing', 'studying')

my_phrases <- character()
for (i_name in names_vec) {
  for (i_fruit in fruits_vec) {
    for (i_verb in verb_vec) {
      my_phrases <- c(my_phrases, 
                      build_phrase(i_name, i_fruit, i_verb))
    }
  }
}

print(my_phrases)

#' 
#' Embora o código funcione conforme o esperado, u
#' 
## ------------------------------------------------------------------------------------------------------------
df_grid <- expand.grid(names_vec = names_vec,
                       fruits_vec = fruits_vec,
                       verb_vec = verb_vec)

l_args <- list(name_in = df_grid$names_vec,
               fruit_in = df_grid$fruits_vec,
               verb_in = df_grid$verb_vec)

my_phrases <- purrr::pmap(.l = l_args, 
                          .f = build_phrase)

print(my_phrases)

#' 
#' Observe que os nomes em `l_args` correspondem a
#' 
## ------------------------------------------------------------------------------------------------------------
print(as.character(my_phrases))

#' 
#' Caso necessário, podemos também definir argumen
#' 
## ------------------------------------------------------------------------------------------------------------
l_args <- list(name_in = names_vec,
               fruit_in = 'orange',
               verb_in = 'studying')

my_phrases <- purrr::pmap(.l = l_args, 
                          .f = build_phrase)

print(my_phrases)

#' 
#' Sempre que você tiver uma situação em que um lo
#' 
#' 
#' ## Manipulação de Dados com `dplyr`
#' 
#' No capítulo \@ref(classe-estrutura) aprendemos 
#' 
#' 
#' ### Operações de Grupo com `dplyr`
#' 
#' A primeira funcionalidade do `dplyr` é no proce
#' 
#' Para ilustrar o uso das funções `dply::group_by
#' 
## ------------------------------------------------------------------------------------------------------------
library(readr)
library(dplyr)

# load data
my_f <- '00-text-resources/data/SP500-Stocks-WithRet.rds'
my_df <- readRDS(my_f)

# group data and calculate stats
my_tab <- my_df %>%
  group_by(ticker) %>%
  summarise(mean_price = mean(price.adjusted),
            max_price = max(price.adjusted),
            min_price = min(price.adjusted),
            max_ret = max(ret),
            min_ret = min(ret))

# check result
print(my_tab)

#' 
#' Explicando o código, o primeiro passo no uso de
#' 
#' Utilizar o `dplyr` é altamente recomendado quan
#' 
## ------------------------------------------------------------------------------------------------------------
# set new col week_day
my_df$week_day <- weekdays(my_df$ref.date)

# print it
print(head(my_df$week_day))

my_tab <- my_df %>%
  mutate(week_day = lubridate::wday(ref.date, label = TRUE)) %>%
  group_by(ticker, week_day) %>%
  summarise(mean_price = mean(price.adjusted),
            max_price = max(price.adjusted),
            min_price = min(price.adjusted),
            max_ret = max(ret),
            min_ret = min(ret))

print(my_tab)

#' 
#' E pronto! Agora temos as mesmas estatísticas de
#' 
#' 
#' ### Operações de Grupo Complexas com `dplyr`
#' 
#' O exemplo anterior mostra um caso simples de cá
#' 
#' Pacote `dplyr` também suporta operações mais co
#' 
#' Vejamos o exemplo a seguir, onde usamos os reto
#' 
## ------------------------------------------------------------------------------------------------------------
# vector of returns
ret <- c(0, rnorm(4, sd= 0.05))
print(ret)

# vector of accumulated returns
acum_ret <- cumprod(1+ret)
print(acum_ret)

#' 
#' Agora vamos realizar este cálculo para todas as
#' 
## ------------------------------------------------------------------------------------------------------------
library(dplyr)

# get acum ret of stoks
my_tab <- my_df %>%
  group_by(ticker) %>%
  do(acum_ret = cumprod(1+.$ret)) %>%
  mutate(last.cumret = acum_ret[length(acum_ret)],
         min.cumret = min(acum_ret))

print(head(my_tab))

#' 
#' Note que os elementos da coluna `acum_ret` não 
#' 
#' A maior vantagem de usar operações complexas de
#' 
#' Resumindo, pacote `dplyr` foi uma inovação muit
#' 
#' 
#' ## Exercícios {#exerc-programacao}
#' 
## ---- echo=FALSE, results='asis'-----------------------------------------------------------------------------
f_in <- fs::dir_ls('../02-EOCE-Rmd//Cap08-Programação/', 
                   type = 'file')

build_exercises(f_in, type_doc = my_engine)
