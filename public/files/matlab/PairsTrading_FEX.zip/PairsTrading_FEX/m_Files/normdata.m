% DESCRIPTION:
% 
%   This function is part of pairstrading.m function.

function [New_x]=normdata(x)

[n2]=size(x,2);

for i=1:n2
    ret=[0 ;(x(2:end,i)-x(1:end-1,i))./x(1:end-1,i)];   
    New_x(:,i)=cumprod(1+ret);  % normalizing price series to P(t=0)=1
    
    mean_x=mean(New_x(:,i));
    std_x=std(New_x(:,i));

    New_x(:,i)=(New_x(:,i)-mean_x)/std_x;   % normalizing again

end