%     This function is part of pairstrading.m function. 

function [pairs]=pairs(x)

[n2]=size(x,2);

Qdist=zeros(n2,n2);

for i=1:n2
    for j=1:i-1
        Qdist(i,j)=sum((x(:,i)-x(:,j)).^2);
        Qdist(j,i)=Qdist(i,j);
    end
    Qdist(i,i)=nan;
end

[m,n]=min(Qdist);
pairs(:,1)=n';



