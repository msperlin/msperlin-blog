%  Function to find the profit of Pairs Trading

function [profitOut,portValue,myTrades]=findProfit(x,d,dist,t,myTrades,Capital,C,maxPeriod,pairsVec)

[nr,nc]=size(x);
nTrades=size(myTrades,1);
timeVec=zeros(nTrades,1);

longPos_Buy =zeros(nTrades,1);
shortPos_Buy=zeros(nTrades,1);

longPos_Sell =zeros(nTrades,1);
shortPos_Sell=zeros(nTrades,1);
anyPos=zeros(nr,nc);

%  iterate over the trades and find the bought and sold price for long and
% short positions

for i=1:nTrades
    
    longIdx=myTrades{i}.assetsNumber(myTrades{i}.directionTrade==1);
    shortIdx=myTrades{i}.assetsNumber(myTrades{i}.directionTrade==-1);
    
    timeVec(i,1)=myTrades{i}.obsNumber;
    
    longPos_Buy(i,1)=x(myTrades{i}.obsNumber,longIdx);
    shortPos_Sell(i,1)=x(myTrades{i}.obsNumber,shortIdx);

    myIdx=0;
    while 1 % iterate forward in time until position is closed
        
        myIdx=myIdx+1; 
        
        if (abs(dist(myTrades{i}.obsNumber+myIdx,myTrades{i}.assetsNumber(1)))<t)   % if spread converges, close position
            break;
        end
        
        if ((myIdx+myTrades{i}.obsNumber)==nr)  % if trades passes number of observations, close position
            break;
        end
        
        asset1=myTrades{i}.assetsNumber(1);
        asset2=myTrades{i}.assetsNumber(2);
        myObs=myTrades{i}.obsNumber-d+1+myIdx;
        
        if (pairsVec{myObs}(asset1,1))~=asset2    % if pairs has changed from t to t+1, close position
            break
        end
                           
        if myIdx>(maxPeriod-1)  % if number of holding period is higher than maxPeriod, break
            break;
        end
    end

    anyPos(timeVec(i,1):timeVec(i,1)+myIdx,[longIdx;shortIdx])=1;
    
    longPos_Sell(i,1)=x(myTrades{i}.obsNumber+myIdx,longIdx);
    shortPos_Buy(i,1) =x(myTrades{i}.obsNumber+myIdx,shortIdx);
    
    myTrades{i}.posHold=myIdx-1;
    
    if (myTrades{i}.directionTrade(1)==1)
        myTrades{i}.buyPrices =[longPos_Buy(i,1) shortPos_Buy(i,1)];
        myTrades{i}.sellPrice=[longPos_Sell(i,1) shortPos_Sell(i,1)];
    else
        myTrades{i}.buyPrices =[shortPos_Buy(i,1)  longPos_Buy(i,1)];
        myTrades{i}.sellPrice =[shortPos_Sell(i,1) longPos_Sell(i,1)];
    end
       
end

ProfitLong =Capital.*(longPos_Sell-longPos_Buy)./longPos_Buy-C;
ProfitShort=Capital.*(shortPos_Sell-shortPos_Buy)./shortPos_Sell-C;
ProfitComb=ProfitLong+ProfitShort;

profitOut.totalProfitLong =sum(ProfitLong);
profitOut.totalProfitShort=sum(ProfitShort);
profitOut.totalProfitComb =sum(ProfitComb);

uniqueTime=unique(timeVec);
n=size(uniqueTime,1);

portValue_Trades_Total=zeros(nr-d+1,1);
portValue_Trades_Long=zeros(nr-d+1,1);
portValue_Trades_Short=zeros(nr-d+1,1);
for i=1:n
    
    idx=uniqueTime(i);
    total=sum(ProfitComb((idx)==timeVec));   
    long =sum(ProfitLong((idx)==timeVec));   
    short=sum(ProfitShort((idx)==timeVec));   
    
    portValue_Trades_Total(idx-d+1,1)=total;
    portValue_Trades_Long(idx-d+1,1)=long;
    portValue_Trades_Short(idx-d+1,1)=short;
    
    nTrades(i,1)=idx;
    nTrades(i,2)=(sum(timeVec==idx))*2;
    
end
    
% Passing output to structure

portValue.timeSeriesComb =(cumsum(portValue_Trades_Total));
portValue.timeSeriesLong =(cumsum(portValue_Trades_Long));
portValue.timeSeriesShort=(cumsum(portValue_Trades_Short));

portValue.timeSeriesRetComb =ProfitComb./Capital;   % this assumes that the short positions dont need capital for funding.
                                                    % the only capital needed is for long positions. 
portValue.timeSeriesRetLong =ProfitLong./Capital;
portValue.timeSeriesRetShort=ProfitShort./Capital;

portValue.nDays.trades=size(uniqueTime,1);
portValue.nDays.anyPos=sum(sum(anyPos,2)~=0);

portValue.nTrades=nTrades;
