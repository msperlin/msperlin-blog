% Example Script for Pairs Trading
clear;

addpath('m_Files');

load Example_Data.mat;

x=pricesMat(:,1:10);        % Price Matrix
d=501;              % Starting Date
window=500;         % Size of moving window for defining pairs
t=1.5;              % Threshold value for defining abnormal behavior
ut=5;               % Peridiocity of pairs updates
C=10;               % Trading cost per trade (in units of price (e.g. dollars))
maxPeriod=5;        % maximum periods to hold the positions
Capital=10000;      % Ammount of capital traded in each position taken (same unit as C)

[profitOut,portValue,myTrades]=pairstrading(x,Capital,d,window,t,ut,C,maxPeriod);

rmpath('m_Files');